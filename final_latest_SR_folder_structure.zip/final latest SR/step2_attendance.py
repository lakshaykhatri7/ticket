import os
# ============================================================
#  step2_attendance.py
#  Reads attendance + assignment ratio from ATTENDANCE.xlsx using openpyxl.
#
#  New Excel format supported:
#    Sheet name = Workgroup, e.g. "SAP_MDM - OTH" / "SAP_MDM - MM"
#    Row 1: Employee / Vendor headers
#    Row 2: Assignment Ratio, Employee %, Vendor %
#    Row 4: columns like Name, Alignment, email, date columns OR Status, Solver
#
#  Logic:
#    P = Present
#    Anything else (A/blank/Leave/etc.) = Absent
#    Solver = Y is eligible for assignment. Blank Solver is treated as Y.
# ============================================================

from datetime import datetime
from openpyxl import load_workbook
from config import EXCEL_FILE, WORKGROUP, DEFAULT_EMP_SPLIT, DEFAULT_VEN_SPLIT


def _format_date(value):
    """Convert Excel date / text date into dd-mm-yyyy string."""
    if isinstance(value, datetime):
        return value.strftime("%d-%m-%Y")
    if value is None:
        return ""
    text = str(value).strip()

    # Strip a trailing time component if present (e.g. "02-07-2026 00:00:00").
    if " " in text:
        date_part, _, time_part = text.partition(" ")
        # Only strip if the remainder actually looks like a time (has a colon),
        # to avoid mangling genuinely space-containing text.
        if ":" in time_part:
            text = date_part

    for fmt in ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%Y/%m/%d", "%d-%b-%Y", "%d %b %Y", "%d.%m.%Y"):
        try:
            return datetime.strptime(text, fmt).strftime("%d-%m-%Y")
        except ValueError:
            pass
    return text


def _norm(value):
    return "" if value is None else str(value).strip().lower().replace(" ", "")


def _find_header_row(ws):
    """Find the row containing email + alignment/name headers."""
    for row_no in range(1, min(ws.max_row, 15) + 1):
        values = [_norm(c.value) for c in ws[row_no]]
        if "email" in values and ("alignment" in values or "name" in values):
            return row_no
    return 4


def _col_index(headers, possible_names):
    normalized = {_norm(h): i for i, h in enumerate(headers)}
    for name in possible_names:
        if _norm(name) in normalized:
            return normalized[_norm(name)]
    return None


def _read_ratio(ws):
    """Read Employee/Vendor assignment ratio from row having 'Assignment Ratio'."""
    emp_ratio = DEFAULT_EMP_SPLIT
    ven_ratio = DEFAULT_VEN_SPLIT

    for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 10), values_only=True):
        row_values = [str(v).strip().lower() if v is not None else "" for v in row]
        if any("assignment" in v and "ratio" in v for v in row_values):
            nums = []
            for v in row:
                if isinstance(v, (int, float)):
                    nums.append(float(v))
                elif isinstance(v, str):
                    t = v.strip().replace("%", "")
                    try:
                        nums.append(float(t))
                    except ValueError:
                        pass
            print(f"  [DEBUG] Ratio row found: {row}")
            print(f"  [DEBUG] Numeric values extracted from that row: {nums}")
            if len(nums) >= 2:
                emp_ratio, ven_ratio = nums[0], nums[1]
            else:
                print(f"  [WARNING] Could not find 2 numeric values in the ratio row - "
                      f"falling back to defaults (Emp={DEFAULT_EMP_SPLIT}, Ven={DEFAULT_VEN_SPLIT}).")
            break

    # Accept both 20/80 and 0.2/0.8 style.
    if emp_ratio > 1 or ven_ratio > 1:
        total = emp_ratio + ven_ratio
        if total > 0:
            emp_ratio = emp_ratio / total
            ven_ratio = ven_ratio / total

    return {"Emp": emp_ratio, "Ven": ven_ratio}


def _read_workgroup_sheet(date, sheet_name, excel_path=None):
    """Read one workgroup sheet and return present/absent/raw rows/ratio."""
    try:
        wb = load_workbook(excel_path or EXCEL_FILE, data_only=True)
    except FileNotFoundError:
        print(f"  [ERROR] File not found: {excel_path or EXCEL_FILE}")
        return None

    if sheet_name not in wb.sheetnames:
        print(f"  [ERROR] Sheet '{sheet_name}' not found in {excel_path}.")
        print(f"  Available sheets: {wb.sheetnames}")
        return None

    ws = wb[sheet_name]
    ratio = _read_ratio(ws)

    header_row = _find_header_row(ws)
    headers = [cell.value for cell in ws[header_row]]

    email_col = _col_index(headers, ["email", "email id", "mail"])
    name_col = _col_index(headers, ["name", "person", "executive name"])
    alignment_col = _col_index(headers, ["alignment", "type", "category"])
    solver_col = _col_index(headers, ["solver", "is solver"])
    status_col = _col_index(headers, ["status", "attendance"])

    # ---- DEBUG: show exactly what was detected, so mismatches (wrong
    # header row, wrong column, or date column not matching) are visible
    # instead of silently producing wrong attendance. ----
    print(f"\n  [DEBUG] Sheet used            : '{sheet_name}'")
    print(f"  [DEBUG] Header row detected   : {header_row}")
    print(f"  [DEBUG] Raw header values     : {headers}")
    print(f"  [DEBUG] email_col index       : {email_col} ({headers[email_col] if email_col is not None and email_col < len(headers) else 'N/A'})")
    print(f"  [DEBUG] name_col index        : {name_col} ({headers[name_col] if name_col is not None and name_col < len(headers) else 'N/A'})")
    print(f"  [DEBUG] alignment_col index   : {alignment_col} ({headers[alignment_col] if alignment_col is not None and alignment_col < len(headers) else 'N/A'})")
    print(f"  [DEBUG] solver_col index      : {solver_col} ({headers[solver_col] if solver_col is not None and solver_col < len(headers) else 'N/A'})")
    print(f"  [DEBUG] status_col index      : {status_col} ({headers[status_col] if status_col is not None and status_col < len(headers) else 'N/A'})")

    # Date-wise sheet: find column whose header matches selected date.
    date_col = None
    formatted_headers = []
    for i, h in enumerate(headers):
        fh = _format_date(h)
        formatted_headers.append(fh)
        if fh == date:
            date_col = i
            break

    print(f"  [DEBUG] Looking for date column matching : '{date}'")
    print(f"  [DEBUG] Formatted header values           : {formatted_headers}")
    if date_col is not None:
        print(f"  [DEBUG] MATCHED date_col index : {date_col} ({headers[date_col]})")
    else:
        print(f"  [DEBUG] NO date column matched '{date}' - will fall back to Status column if available.")

    if email_col is None:
        print(f"  [ERROR] 'email' column not found in sheet '{sheet_name}'.")
        return None
    if alignment_col is None:
        print(f"  [ERROR] 'Alignment' column not found in sheet '{sheet_name}'.")
        return None
    if date_col is None and status_col is None:
        print(f"  [ERROR] Neither date column '{date}' nor Status column found in sheet '{sheet_name}'.")
        return None

    people = {"Emp": {}, "Ven": {}}
    duplicate_warnings = []

    for row in ws.iter_rows(min_row=header_row + 1, values_only=True):
        email = row[email_col] if email_col < len(row) else None
        if not email:
            continue

        alignment = row[alignment_col] if alignment_col < len(row) else ""
        role_text = str(alignment or "").strip().lower()
        if role_text.startswith("emp"):
            role = "Emp"
        elif role_text.startswith("ven"):
            role = "Ven"
        else:
            continue

        status_value = row[date_col] if date_col is not None and date_col < len(row) else row[status_col]
        status = str(status_value).strip().upper() if status_value is not None else "A"
        solver_value = row[solver_col] if solver_col is not None and solver_col < len(row) else "Y"
        solver = str(solver_value).strip().upper() if solver_value is not None else "Y"
        name = row[name_col] if name_col is not None and name_col < len(row) else ""
        name = str(name or "").strip()

        email = str(email).strip()

        # ---- IMPORTANT SAFETY CHECK ----
        # Same email used for two different people (in this role, or across
        # Emp/Ven) silently corrupts attendance lookups: only the last row
        # would "win" and earlier people would vanish from presence checks,
        # which can wrongly make a present person look absent and trigger
        # an incorrect reassignment. We warn loudly instead of staying silent.
        existing = people[role].get(email)
        if existing is not None and existing.get("name", "") != name:
            duplicate_warnings.append(
                f"  [DUPLICATE EMAIL WARNING] '{email}' is used for both "
                f"'{existing.get('name','?')}' and '{name}' in role '{role}'. "
                f"Only the LAST row ('{name}') will be used for attendance. "
                f"Please fix this email in ATTENDANCE.xlsx."
            )
        for other_role in ("Emp", "Ven"):
            if other_role != role and email in people[other_role]:
                other_name = people[other_role][email].get("name", "?")
                duplicate_warnings.append(
                    f"  [DUPLICATE EMAIL WARNING] '{email}' is used for "
                    f"'{other_name}' (role {other_role}) AND '{name}' (role {role}). "
                    f"This is almost certainly a data entry mistake -- please "
                    f"fix it in ATTENDANCE.xlsx."
                )

        people[role][email] = {"status": status, "solver": solver, "name": name}

    if duplicate_warnings:
        print("\n  " + "!" * 64)
        print("  WARNING: Duplicate emails found in ATTENDANCE.xlsx")
        print("  " + "!" * 64)
        for w in duplicate_warnings:
            print(w)
        print("  " + "!" * 64 + "\n")

    return {"people": people, "ratio": ratio}


def check_attendance(date, workgroup=None, attend_dir=None):
    """
    Checks attendance for date and workgroup sheet.

    Returns:
        present: {"Emp": [{"name": email, "solver": "Y", "display_name": name}], "Ven": [...]}
        absent : {"Emp": [email,...], "Ven": [...]}
        rows   : {
                  "employee": {email: "P/A"},
                  "vendor": {email: "P/A"},
                  "details": {email: {...}},
                  "ratio": {"Emp": 0.20, "Ven": 0.80},
                  "workgroup": "SAP_MDM - OTH"
                 }
    """

    workgroup = workgroup or WORKGROUP

    print("\n" + "="*65)
    # Build full path to the attendance file
    if attend_dir:
        excel_path = os.path.join(attend_dir, EXCEL_FILE)
    else:
        excel_path = EXCEL_FILE

    print(f"  STEP 2 : Attendance Check  ({excel_path} / {workgroup})")
    print("="*65)

    data = _read_workgroup_sheet(date, workgroup, excel_path=excel_path)
    if data is None:
        return None, None, None

    present = {"Emp": [], "Ven": []}
    absent = {"Emp": [], "Ven": []}
    rows = {"employee": {}, "vendor": {}, "details": {}, "ratio": data["ratio"], "workgroup": workgroup}

    print(f"\n  Date : {date}")
    print(f"  Ratio from Excel : Employee {round(data['ratio']['Emp']*100)}%, Vendor {round(data['ratio']['Ven']*100)}%\n")
    print(f"  {'Email':<42} {'Name':<18} {'Type':<8} {'Solver':<7} Status")
    print(f"  {'-'*90}")

    for role in ["Emp", "Ven"]:
        for email, info in data["people"][role].items():
            status = info["status"]
            solver = info["solver"] or "Y"
            name = info.get("name", "")
            rows["employee" if role == "Emp" else "vendor"][email] = status
            rows["details"][email] = {"role": role, "status": status, "solver": solver, "name": name}

            if status == "P" and solver == "Y":
                present[role].append({"name": email, "solver": "Y", "display_name": name})
                status_text = "Present"
            else:
                absent[role].append(email)
                status_text = "Absent" if status != "P" else "Present but not solver"

            print(f"  {email:<42} {name:<18} {role:<8} {solver:<7} {status_text}")

    print(f"\n  -- SUMMARY ------------------------------------")
    print(f"  Present Employees : {[p['name'] for p in present['Emp']] or 'None'}")
    print(f"  Present Vendors   : {[p['name'] for p in present['Ven']] or 'None'}")
    print(f"  Absent/Not Solver Employees : {absent['Emp'] or 'None'}")
    print(f"  Absent/Not Solver Vendors   : {absent['Ven'] or 'None'}")

    return present, absent, rows


if __name__ == "__main__":
    date = datetime.now().strftime("%d-%m-%Y")
    print(f"  Using today's date : {date}")
    check_attendance(date)

# ============================================================
#  main_sr.py -- Service Request Management -- Full Auto Flow
#
#  Every run creates a new output folder:
#      runs/DDMMYYYY_HHMMSS/
#  All Excel files, JSON files, and the log file for that run
#  are saved inside that folder automatically.
#
#  Logic:
#   1. Fetch service requests from API (SR_GetServiceRequestList)
#   1b. Split fetched tickets into 4 Excel files by status:
#         sr_new_*.xlsx / sr_assigned_*.xlsx / sr_inprogress_*.xlsx / sr_pending_*.xlsx
#   2. Read attendance from ATTENDANCE.xlsx
#   3. New / Pending / In Progress SRs -> split via Employee/Vendor ratio
#      across PRESENT people (each status gets its own split target)
#   4. Already-Assigned SRs:
#        - assignee present -> remain assigned to same person
#        - assignee absent  -> reassign to a present person
#   5. Post only SRs that need assignment/reassignment
#   6. Create final summary report Excel
#
#  Run: python main_sr.py
# ============================================================

import os
from datetime import datetime
from logger import start_logging, stop_logging
from step1_fetch_sr import fetch_service_requests
from step1b_split_by_status import split_tickets_by_status
from step2_attendance import check_attendance
from step3_allocate_sr import allocate_sr_actions
from step4_post_sr import post_sr_actions
from step5_report_sr import create_sr_assignment_report


# ============================================================
#  FOLDER STRUCTURE (created next to the .exe / script)
#
#  AutomaticIservTicketing/
#  ├── Input/
#  │   ├── Extracted Details/    <- JSON + Excel files (not report/attendance)
#  │   │     output_sr.json
#  │   │     sr_all_raw_*.xlsx
#  │   │     sr_*.xlsx
#  │   │     sr_summary_*.xlsx
#  │   │     sr_assignment_result_*.xlsx
#  │   │     sr_new/assigned/inprogress/pending_*.xlsx
#  │   │     DDMMYYYY_HHMMSS.txt  (log file)
#  │   └── Monthly Attendance/   <- ATTENDANCE.xlsx lives here permanently
#  │         ATTENDANCE.xlsx
#  └── Output/                   <- Only the final report
#        sr_assignment_report_*.xlsx
# ============================================================

def _make_folders():
    """
    Creates the AutomaticIservTicketing folder structure next to this
    script / exe and returns the three active paths needed each run:
        extracted_dir  : Input/Extracted Details/
        attendance_dir : Input/Monthly Attendance/
        output_dir     : Output/
    """
    if getattr(__import__("sys"), "frozen", False):
        base = os.path.dirname(os.path.abspath(__import__("sys").executable))
    else:
        base = os.path.dirname(os.path.abspath(__file__))

    root          = os.path.join(base, "AutomaticIservTicketing")
    extracted_dir = os.path.join(root, "Input", "Extracted Details")
    attend_dir    = os.path.join(root, "Input", "Monthly Attendance")
    output_dir    = os.path.join(root, "Output")

    for folder in [extracted_dir, attend_dir, output_dir]:
        os.makedirs(folder, exist_ok=True)

    return extracted_dir, attend_dir, output_dir


def main():
    extracted_dir, attend_dir, output_dir = _make_folders()

    # Log file goes into Extracted Details
    start_logging(out_dir=extracted_dir)

    try:
        print("\n" + "*" * 55)
        print("   SERVICE REQUEST MANAGEMENT SYSTEM -- Full Auto Flow")
        print("*" * 55)
        print(f"\n  Extracted Details : {extracted_dir}")
        print(f"  Monthly Attendance: {attend_dir}")
        print(f"  Output (Report)   : {output_dir}")

        date = datetime.now().strftime("%d-%m-%Y")
        print(f"\n  Using today's date : {date}")

        # STEP 1: Fetch service requests
        # JSON + Excel files -> Extracted Details
        excel_file, sr_numbers, sr_rows = fetch_service_requests(out_dir=extracted_dir)

        if not sr_rows:
            print("\n[WARNING] No service requests fetched. Stopping program.")
            return

        print(f"\n  Total Service Requests (auto-detected) : {len(sr_rows)}")

        # STEP 1b: Split by status Excel files -> Extracted Details
        split_tickets_by_status(sr_rows, out_dir=extracted_dir)

        # STEP 2: Attendance -> read from Monthly Attendance folder
        present, absent, rows = check_attendance(date, attend_dir=attend_dir)

        if present is None:
            print("\n[ERROR] Attendance not found. Stopping program.")
            return

        # STEP 3: Allocate
        # assignment_state_sr.json -> Extracted Details
        actions, kept, skipped = allocate_sr_actions(sr_rows, present, rows, out_dir=extracted_dir)

        post_results = []

        # STEP 4: Post
        # sr_assignment_result_*.xlsx -> Extracted Details
        if not actions:
            print("\nNo SR needs assignment/reassignment. Nothing to post.")
        else:
            confirm = input("\nPost only these required SR updates via API now? (y/n): ").strip().lower()

            if confirm == "y":
                post_results = post_sr_actions(actions, out_dir=extracted_dir)
            else:
                print("\nAPI posting skipped.")

        # STEP 5: Final report Excel -> Output folder
        create_sr_assignment_report(
            sr_rows, actions, kept, skipped, rows, post_results, out_dir=output_dir
        )

        print("\n" + "*" * 55)
        print("   Done!")
        print(f"   Report saved to : {output_dir}")
        print(f"   Files saved to  : {extracted_dir}")
        print("*" * 55)

    finally:
        stop_logging()


if __name__ == "__main__":
    main()

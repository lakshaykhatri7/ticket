# ============================================================
#  step2_attendance.py
#  Reads attendance from ATTENDANCE.xlsx using openpyxl.
#
#  Logic:
#    P = Present
#    Anything else (A/blank/Leave/etc.) = Absent
#    Present people are treated as eligible solvers.
# ============================================================

from datetime import datetime
from openpyxl import load_workbook
from config import EXCEL_FILE


def _format_date(value):
    """Convert Excel date / text date into dd-mm-yyyy string."""
    if isinstance(value, datetime):
        return value.strftime("%d-%m-%Y")

    if value is None:
        return ""

    text = str(value).strip()
    for fmt in ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%Y/%m/%d"):
        try:
            return datetime.strptime(text, fmt).strftime("%d-%m-%Y")
        except ValueError:
            pass
    return text


def _read_sheet_status(date, sheet_name):
    """
    Reads one sheet and returns {person_email/name: P/A status} for the date.
    """
    try:
        wb = load_workbook(EXCEL_FILE, data_only=True)
    except FileNotFoundError:
        print(f"  [ERROR] File not found: {EXCEL_FILE}")
        return None

    if sheet_name not in wb.sheetnames:
        print(f"  [ERROR] Sheet '{sheet_name}' not found in {EXCEL_FILE}.")
        return None

    ws = wb[sheet_name]
    headers = []
    for cell in ws[1]:
        headers.append(str(cell.value).strip() if cell.value is not None else "")

    if len(headers) < 2:
        print(f"  [ERROR] Sheet '{sheet_name}' does not have person columns.")
        return None

    for row in ws.iter_rows(min_row=2, values_only=True):
        row_date = _format_date(row[0])
        if row_date == date:
            statuses = {}
            for i, person in enumerate(headers[1:], start=1):
                if not person:
                    continue
                value = row[i] if i < len(row) else None
                statuses[person] = str(value).strip().upper() if value is not None else "A"
            return statuses

    return None


def check_attendance(date):
    """
    Checks attendance for the given date.

    Returns:
        present: {"Emp": [{"name": email, "solver": "Y"}], "Ven": [...]}
        absent : {"Emp": [email,...], "Ven": [...]}
        rows   : raw status dict for matching names later
    """

    print("\n" + "="*55)
    print("  STEP 2 : Attendance Check  (ATTENDANCE.xlsx)")
    print("="*55)

    emp_status = _read_sheet_status(date, "employee")
    ven_status = _read_sheet_status(date, "vendor")

    if emp_status is None and ven_status is None:
        print(f"  [ERROR] Date '{date}' not found in either sheet (employee/vendor).")
        return None, None, None

    present = {"Emp": [], "Ven": []}
    absent = {"Emp": [], "Ven": []}

    print(f"\n  Date : {date}\n")
    print(f"  {'Email':<45} {'Type':<6} Status")
    print(f"  {'-'*70}")

    for role, statuses in [("Emp", emp_status), ("Ven", ven_status)]:
        if not statuses:
            continue
        for name, status in statuses.items():
            if status == "P":
                present[role].append({"name": name, "solver": "Y"})
                status_text = "Present"
            else:
                absent[role].append(name)
                status_text = "Absent"
            print(f"  {name:<45} {role:<6} {status_text}")

    print(f"\n  -- SUMMARY ------------------------------------")
    print(f"  Present Employees : {[p['name'] for p in present['Emp']] or 'None'}")
    print(f"  Present Vendors   : {[p['name'] for p in present['Ven']] or 'None'}")
    print(f"  Absent Employees  : {absent['Emp'] or 'None'}")
    print(f"  Absent Vendors    : {absent['Ven'] or 'None'}")

    return present, absent, {"employee": emp_status or {}, "vendor": ven_status or {}}


if __name__ == "__main__":
    date = datetime.now().strftime("%d-%m-%Y")
    print(f"  Using today's date : {date}")
    check_attendance(date)

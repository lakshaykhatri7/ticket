Ticket Management System
========================

Run:
  python main.py

Updated Logic
-------------
1. Fetch tickets from API.
2. Read attendance from ATTENDANCE.xlsx using openpyxl.
3. For each ticket:

   A) New / Unassigned ticket
      - Assign to a present person only.
      - New tickets follow 30% Employee and 70% Vendor split.

   B) Already assigned ticket
      - If assigned person is PRESENT in ATTENDANCE.xlsx:
          keep the ticket assigned to the same person.
          no API update is posted for that ticket.
      - If assigned person is ABSENT:
          reassign the ticket to another present person.

4. Post via API only the tickets that need assignment/reassignment.

Attendance File
---------------
ATTENDANCE.xlsx must contain:
  Sheet 1: employee
  Sheet 2: vendor

First column should be Date.
Other columns should be person email IDs / names.
Use P for present. Anything else is treated as absent.

Important Files
---------------
main.py                 Main auto flow
step1_fetch_tickets.py  Fetches tickets from API
step2_attendance.py     Reads attendance from Excel using openpyxl
step3_allocate.py       Applies ticket-by-ticket logic
step4_post_tickets.py   Posts only required updates to API
config.py               API and split settings

Config
------
FETCH_STATUS is blank by default so the API can return both NEW and Assigned tickets.
If your API requires a specific status filter, change FETCH_STATUS in config.py.

EMP_SPLIT = 0.30 means new tickets are split 30% employees and 70% vendors.

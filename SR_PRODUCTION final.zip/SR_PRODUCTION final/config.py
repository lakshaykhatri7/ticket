# ============================================================
#  config.py — PRODUCTION (Incident + SR)
# ============================================================

API_URL   = "http://msilstaging/Webservice/REST/Summit_RESTWCF.svc/RESTService/CommonWS_JsonObjCall"
API_KEY   = "sWkL0CqC1bikNDIJvI66eNxPVBMgNTtlSX31d5kZ4OM="
ORG_ID    = 1
INSTANCE  = "ITD"
WORKGROUP = "SAP_MDM - OTH"

EXCEL_FILE = "ATTENDANCE.xlsx"
EMP_SPLIT  = 0.30        # 30% Employees | 70% Vendors

# ── Incident settings ─────────────────────────────────────────────────────────
INCIDENT_FETCH_SERVICE = "IM_GetIncidentList"
INCIDENT_POST_SERVICE  = "IM_LogOrUpdateIncident"

# ── SR settings ───────────────────────────────────────────────────────────────
SR_FETCH_SERVICE       = "SR_GetServiceRequestList"   # fetch SR list
SR_POST_SERVICE        = "SR_UpdateServiceRequest"    # assign SR to engineer
SR_NEW_STATUS          = "New"
SR_ASSIGNED_STATUS     = "In-Progress"                # SR equivalent of "Assigned"

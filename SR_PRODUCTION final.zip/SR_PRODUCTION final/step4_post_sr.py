# ============================================================
#  step4_post_sr.py
#  Posts SR assignments via SR_UpdateServiceRequest API
#
#  Key differences from Incident:
#    - ServiceName  : SR_UpdateServiceRequest
#    - Field name   : AssignedEngineer  (NOT Assigned_Engineer_Email)
#    - Status       : In-Progress       (NOT Assigned)
#    - Ticket ID    : IncidentTicketID  (int, not string)
# ============================================================

import requests
import pandas as pd
from datetime import datetime
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP, SR_POST_SERVICE


def _post_sr_one(ticket_id, email, mode="New"):
    """
    Calls SR_UpdateServiceRequest API for one SR ticket.
    ticket_id : int or str — the numeric IncidentTicketID
    email     : AssignedEngineer email
    """
    payload = {
        "ServiceName": SR_POST_SERVICE,
        "objCommonParameters": {
            "_ProxyDetails": {
                "AuthType": "APIKEY",
                "APIKey": API_KEY,
                "ProxyID": 0,
                "ReturnType": "JSON"
            },
            "objSRServiceTicket": {
                "IncidentTicketID": int(ticket_id),
                "Org_ID": ORG_ID,
                "Status": "In-Progress",
                "SupportFunction": INSTANCE,
                "WorkGroupName": WORKGROUP,
                "AssignedEngineer": email,
                "InternalLog": f"Auto-assigned ({mode}) to {email} via Python Bot",
                "UserLog": ""
            }
        }
    }
    try:
        resp = requests.post(API_URL, json=payload, timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            # Check for API-level success message
            output_msg = data.get("Output", "")
            if "Successfully" in str(output_msg):
                return {"status_code": 200, "result": "Success"}
            elif data.get("Errors"):
                return {"status_code": 200, "result": f"API Error: {data['Errors']}"}
            return {"status_code": 200, "result": "Success"}
        return {"status_code": resp.status_code, "result": f"Failed_{resp.status_code}"}
    except requests.exceptions.ConnectionError:
        return {"status_code": "N/A", "result": "Connection Error"}
    except Exception as e:
        return {"status_code": "N/A", "result": f"Error: {e}"}


def post_sr_tickets(new_allocation, reassign_map):
    """
    Posts SR assignments to Summit API.

    Args:
        new_allocation (dict) : { email : [sr_ids] }  — new SR 30/70 split
        reassign_map   (dict) : { email : [sr_ids] }  — reassigned SR tickets
    """

    print("\n" + "=" * 70)
    print("  STEP 4 (SR) : Posting Service Requests via API")
    print("=" * 70)

    results = []

    # ── Post NEW SR assignments ───────────────────────────────
    if new_allocation:
        print(f"\n  -- NEW SR Assignments ------------------------------------")
        for email, sr_ids in new_allocation.items():
            for sr_id in sr_ids:
                print(f"  [NEW SR]    SR {str(sr_id):<14} -> {email} ...", end=" ")
                r = _post_sr_one(sr_id, email, mode="New")
                print(r["result"])
                results.append({
                    "SR_ID":           sr_id,
                    "Email":           email,
                    "Type":            "New SR",
                    "Status_Code":     r["status_code"],
                    "Result":          r["result"],
                    "Assigned by Bot": "Yes",
                    "Time":            datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })
    else:
        print("\n  No NEW SR assignments.")

    # ── Post REASSIGNED SR updates ────────────────────────────
    if reassign_map:
        print(f"\n  -- REASSIGNED SR Updates ---------------------------------")
        for email, sr_ids in reassign_map.items():
            for sr_id in sr_ids:
                print(f"  [REASSIGN]  SR {str(sr_id):<14} -> {email} ...", end=" ")
                r = _post_sr_one(sr_id, email, mode="Reassigned")
                print(r["result"])
                results.append({
                    "SR_ID":           sr_id,
                    "Email":           email,
                    "Type":            "Reassigned SR",
                    "Status_Code":     r["status_code"],
                    "Result":          r["result"],
                    "Assigned by Bot": "Yes",
                    "Time":            datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })
    else:
        print("\n  No REASSIGNED SR updates.")

    if not results:
        print("\n  Nothing was posted.")
        return

    # ── Terminal result table ─────────────────────────────────
    print(f"\n  -- FULL SR RESULT TABLE -------------------------------------")
    print(f"  {'SR ID':<14} {'Type':<15} {'Email':<42} Result")
    print(f"  {'-'*85}")
    for r in results:
        print(f"  {str(r['SR_ID']):<14} {r['Type']:<15} {r['Email']:<42} {r['Result']}")

    # ── Save result Excel ─────────────────────────────────────
    ts          = datetime.now().strftime("%d%m%y_%H%M%S")
    result_file = f"sr_assignment_result_{ts}.xlsx"
    pd.DataFrame(results).to_excel(result_file, index=False)
    print(f"\n  SR Assignment result saved -> {result_file}")

    success = sum(1 for r in results if r["Result"] == "Success")
    failed  = len(results) - success
    print(f"\n  -- SR POST SUMMARY ------------------------------------------")
    print(f"  Total Posted : {len(results)}")
    print(f"  Success      : {success}")
    print(f"  Failed       : {failed}")


# ── Standalone test ───────────────────────────────────────────
if __name__ == "__main__":
    sample_new = {
        "Akshita.Bhandari@maruti.co.in":         ["231474", "231475"],
        "JKTECH_Neha.Aswal@maruti.co.in":        ["231476", "231477", "231478"]
    }
    sample_reassign = {
        "Vaibhav.Agarwal@maruti.co.in": ["231490"]
    }
    post_sr_tickets(sample_new, sample_reassign)

# ============================================================
#  step1_fetch_sr.py
#  Fetches SR (Service Request) tickets from Summit API
#
#  NEW SR        -> Status = "New"
#  ASSIGNED SR   -> Status = "In-Progress"
#
#  Returns:
#    new_sr_ids   (list)      : SR IDs with Status = New
#    assigned_df  (DataFrame) : SR rows with Status = In-Progress
# ============================================================

import requests
import json
import pandas as pd
from datetime import datetime
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP, \
                   SR_FETCH_SERVICE, SR_NEW_STATUS, SR_ASSIGNED_STATUS

SR_SUMMARY_COLUMNS = [
    "IncidentTicketID",       # SR ticket ID (numeric)
    "Ticket_No",              # SR display number e.g. SR-231474
    "Logged Time",
    "Status",
    "Symptom",
    "WorkGroupName",
    "AssignedEngineer",       # current assignee email
    "FullCategory",
]


def _call_sr_api(status, page_size=100):
    """Calls Summit API to fetch SR list for a given status."""
    payload = {
        "ServiceName": SR_FETCH_SERVICE,
        "objCommonParameters": {
            "_ProxyDetails": {
                "AuthType": "APIKey",
                "APIKey": API_KEY,
                "ProxyID": 0,
                "ReturnType": "json",
                "OrgID": ORG_ID,
                "TokenID": ""
            },
            "objSRCommonFilter": {
                "WorkgroupName": WORKGROUP,
                "CurrentPageIndex": 0,
                "PageSize": page_size,
                "OrgID": str(ORG_ID),
                "Instance": INSTANCE,
                "Status": status,
                "IsWebServiceRequest": True
            }
        }
    }
    try:
        response = requests.post(API_URL, json=payload, timeout=30)
        if response.status_code != 200:
            print(f"  SR API error ({response.status_code}) for status='{status}'")
            return []
        data = response.json()
        # Try common response keys
        output = data.get("OutputObject", {})
        tickets = (output.get("MyTickets")
                   or output.get("ServiceRequests")
                   or output.get("SRList")
                   or [])
        return tickets
    except requests.exceptions.ConnectionError:
        print(f"  Connection error while fetching SR '{status}' tickets.")
        return []
    except Exception as e:
        print(f"  Unexpected error: {e}")
        return []


def fetch_sr_tickets(page_size=100):
    """
    Fetches New + In-Progress SR tickets from Summit API.

    Returns:
        excel_filename  (str)       : saved Excel file path
        new_sr_ids      (list)      : SR ticket IDs (New)
        assigned_df     (DataFrame) : SR rows (In-Progress) with assignee info
    """

    print("\n" + "=" * 60)
    print("  STEP 1 (SR) : Fetching Service Requests from API")
    print("=" * 60)

    # ── Fetch New SR ──────────────────────────────────────────
    print(f"\n  Fetching NEW SR (Status='{SR_NEW_STATUS}') ...")
    new_raw = _call_sr_api(SR_NEW_STATUS, page_size)
    print(f"  New SR found           : {len(new_raw)}")

    # ── Fetch In-Progress SR ──────────────────────────────────
    print(f"  Fetching IN-PROGRESS SR (Status='{SR_ASSIGNED_STATUS}') ...")
    assigned_raw = _call_sr_api(SR_ASSIGNED_STATUS, page_size)
    print(f"  In-Progress SR found   : {len(assigned_raw)}")

    all_raw = new_raw + assigned_raw

    if not all_raw:
        print("  No SR tickets found.")
        return None, [], pd.DataFrame()

    # ── Save raw JSON ─────────────────────────────────────────
    with open("output.json", "w") as f:
        json.dump({"New": new_raw, "In-Progress": assigned_raw}, f, indent=4)
    print("  Raw JSON saved  -> output.json")

    # ── Build DataFrames ──────────────────────────────────────
    new_df      = pd.DataFrame(new_raw)      if new_raw      else pd.DataFrame()
    assigned_df = pd.DataFrame(assigned_raw) if assigned_raw else pd.DataFrame()
    all_df      = pd.DataFrame(all_raw)

    timestamp = datetime.now().strftime("%d%m%y_%H%M%S")

    # ── Excel #1 : Full data ──────────────────────────────────
    excel_filename = f"sr_tickets_{timestamp}.xlsx"
    all_df.to_excel(excel_filename, index=False)
    print(f"  Full Excel saved     -> {excel_filename}")

    # ── Excel #2 : Summary ────────────────────────────────────
    avail_cols  = [c for c in SR_SUMMARY_COLUMNS if c in all_df.columns]
    missing     = [c for c in SR_SUMMARY_COLUMNS if c not in all_df.columns]
    if missing:
        print(f"  Columns not in response (will be blank): {missing}")
    summary_df = all_df.reindex(columns=SR_SUMMARY_COLUMNS)
    summary_df["Assigned by Bot"] = "Yes"
    summary_file = f"sr_tickets_summary_{timestamp}.xlsx"
    summary_df.to_excel(summary_file, index=False)
    print(f"  Summary Excel saved  -> {summary_file}")

    # ── Print SR table ────────────────────────────────────────
    id_col     = "IncidentTicketID" if "IncidentTicketID" in all_df.columns else all_df.columns[0]
    status_col = "Status"           if "Status"           in all_df.columns else ""
    symptom_col= "Symptom"          if "Symptom"          in all_df.columns else ""
    eng_col    = "AssignedEngineer" if "AssignedEngineer" in all_df.columns else ""

    print(f"\n  {'SR ID':<14} {'Status':<14} {'Symptom':<32} Current Assignee")
    print(f"  {'-'*85}")
    for _, row in all_df.iterrows():
        sr_id    = str(row.get(id_col, "-"))
        status   = str(row.get(status_col, "-"))  if status_col  else "-"
        symptom  = str(row.get(symptom_col, "-")) if symptom_col else "-"
        assignee = str(row.get(eng_col, "-"))     if eng_col     else "-"
        print(f"  {sr_id:<14} {status:<14} {symptom:<32} {assignee}")

    # ── Extract New SR IDs ────────────────────────────────────
    if not new_df.empty:
        id_col_new = "IncidentTicketID" if "IncidentTicketID" in new_df.columns else new_df.columns[0]
        new_sr_ids = new_df[id_col_new].astype(str).tolist()
    else:
        new_sr_ids = []

    return excel_filename, new_sr_ids, assigned_df


# ── Standalone run ────────────────────────────────────────────
if __name__ == "__main__":
    excel_file, new_ids, assigned = fetch_sr_tickets()
    print(f"\n  New SR IDs (first 5)     : {new_ids[:5]}")
    print(f"  In-Progress SR (rows)    : {len(assigned)}")

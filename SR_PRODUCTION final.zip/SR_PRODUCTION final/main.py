# ============================================================
#  main.py — SR Management System [PRODUCTION]
#
#  RULES:
#   NEW SR        -> 30% Employees / 70% Vendors (present only)
#   IN-PROGRESS SR-> Keep if assignee present today & tomorrow
#                    Reassign if absent today -> present person today
#                    Reassign proactively if absent tomorrow
#
#  Run: python main.py
# ============================================================

from datetime import datetime

from step1_fetch_sr    import fetch_sr_tickets
from step2_attendance  import check_attendance, get_next_working_date, build_email_role_map
from step3_allocate_sr import allocate_new_sr, reallocate_inprogress_sr
from step4_post_sr     import post_sr_tickets


def main():
    print("\n" + "*" * 60)
    print("   SR MANAGEMENT SYSTEM  [PRODUCTION]")
    print("   Maruti Summit API  —  SR_UpdateServiceRequest")
    print("*" * 60)

    # ── Date setup ────────────────────────────────────────────
    today    = datetime.now().strftime("%d-%m-%Y")
    tomorrow = get_next_working_date(today)
    print(f"\n  Today    : {today}")
    print(f"  Tomorrow : {tomorrow}")

    # ── STEP 1 : Fetch SR tickets ─────────────────────────────
    excel_file, new_sr_ids, assigned_df = fetch_sr_tickets()

    print(f"\n  New SR found           : {len(new_sr_ids)}")
    print(f"  In-Progress SR found   : {len(assigned_df)}")

    if len(new_sr_ids) == 0 and assigned_df.empty:
        print("\n  No SR tickets found. Stopping.")
        return

    # ── STEP 2 : Today's attendance ───────────────────────────
    present_today, absent_today, _ = check_attendance(today, label="TODAY")
    if present_today is None:
        print(f"\n  Attendance for {today} not found in ATTENDANCE.xlsx.")
        print("  Please add today's date and re-run.")
        return

    # ── STEP 2b : Tomorrow's attendance ──────────────────────
    print(f"\n  Checking tomorrow's attendance ({tomorrow}) ...")
    present_tomorrow, absent_tomorrow, _ = check_attendance(
        tomorrow, label="TOMORROW", verbose=True
    )
    if present_tomorrow is None:
        print(f"  Tomorrow ({tomorrow}) not in file — proactive check skipped.")

    email_role_map = build_email_role_map()

    # ── STEP 3a : NEW SR  (30% Emp / 70% Ven) ────────────────
    new_allocation = {}
    if new_sr_ids:
        new_allocation = allocate_new_sr(present_today, new_sr_ids)
    else:
        print("\n  No NEW SR — skipping Step 3a.")

    # ── STEP 3b : IN-PROGRESS SR re-allocation ────────────────
    keep_map = reassign_map = {}
    if not assigned_df.empty:
        keep_map, reassign_map, _ = reallocate_inprogress_sr(
            assigned_df,
            present_today,    absent_today,
            present_tomorrow, absent_tomorrow,
            email_role_map
        )
    else:
        print("\n  No IN-PROGRESS SR — skipping Step 3b.")

    # ── Pre-post summary ──────────────────────────────────────
    count_new      = sum(len(v) for v in new_allocation.values())
    count_reassign = sum(len(v) for v in reassign_map.values())
    count_keep     = sum(len(v) for v in keep_map.values())

    print("\n" + "=" * 60)
    print("  PRE-POST SUMMARY")
    print("=" * 60)
    print(f"  New SR to assign        : {count_new}")
    print(f"  In-Progress SR — keep   : {count_keep}  (no API call needed)")
    print(f"  In-Progress SR — move   : {count_reassign}  (API update needed)")

    if count_new == 0 and count_reassign == 0:
        print("\n  Nothing to post — all SR are with present people.")
        print("\n" + "*" * 60 + "\n   Done!\n" + "*" * 60)
        return

    confirm = input("\n  Post SR assignments via Maruti API? (y/n): ").strip().lower()

    if confirm == "y":
        post_sr_tickets(new_allocation, reassign_map)
    else:
        print("\n  API posting skipped.")

    print("\n" + "*" * 60)
    print("   Done!")
    print("*" * 60)


if __name__ == "__main__":
    main()

# ============================================================
#  step2_attendance.py
#  Reads attendance from ATTENDANCE.xlsx (2 sheets: employee, vendor)
#
#  check_attendance(date)         -> present/absent for a given date
#  get_next_day_date(date_str)    -> returns next working date string
#  build_email_role_map()         -> { email : "Emp" | "Ven" }
# ============================================================

import pandas as pd
from datetime import datetime, timedelta
from config import EXCEL_FILE


def _read_sheet_status(date_str, sheet_name):
    """Returns {email: 'P'|'A'} for given date from a sheet, or None."""
    try:
        df = pd.read_excel(EXCEL_FILE, sheet_name=sheet_name)
    except FileNotFoundError:
        print(f"  File not found: {EXCEL_FILE}")
        return None
    except ValueError:
        print(f"  Sheet '{sheet_name}' not found in {EXCEL_FILE}.")
        return None

    df.columns = df.columns.str.strip()
    df["Date"] = pd.to_datetime(df["Date"]).dt.strftime("%d-%m-%Y")

    row = df[df["Date"] == date_str]
    if row.empty:
        return None

    row = row.iloc[0]
    person_cols = [c for c in df.columns if c != "Date"]
    return {email: str(row[email]).strip().upper() for email in person_cols}


def build_email_role_map():
    """
    Returns a dict mapping every known email to its role: 'Emp' or 'Ven'.
    Used to determine a ticket's current assignee role.
    """
    role_map = {}
    for sheet, role in [("employee", "Emp"), ("vendor", "Ven")]:
        try:
            df = pd.read_excel(EXCEL_FILE, sheet_name=sheet)
            df.columns = df.columns.str.strip()
            for col in df.columns:
                if col.lower() != "date":
                    role_map[col.strip().lower()] = role
        except Exception:
            pass
    return role_map


def check_attendance(date_str, label="TODAY", verbose=True):
    """
    Checks attendance for employee + vendor sheets on the given date.

    Returns:
        present (dict) : { "Emp": [{email, solver}], "Ven": [...] }
        absent  (dict) : { "Emp": [email,...],        "Ven": [...] }
        raw     (dict) : { "employee": {...}, "vendor": {...} }
    """

    if verbose:
        print("\n" + "=" * 70)
        print(f"  STEP 2 : Attendance Check [{label}]  ({date_str})")
        print("=" * 70)

    emp_status = _read_sheet_status(date_str, "employee")
    ven_status = _read_sheet_status(date_str, "vendor")

    if emp_status is None and ven_status is None:
        if verbose:
            print(f"  Date '{date_str}' not found in attendance file.")
        return None, None, None

    present = {"Emp": [], "Ven": []}
    absent  = {"Emp": [], "Ven": []}

    if verbose:
        print(f"\n  Date : {date_str}\n")
        print(f"  {'Email':<42} {'Type':<6} Status")
        print(f"  {'-'*60}")

    for role, statuses in [("Emp", emp_status), ("Ven", ven_status)]:
        if not statuses:
            continue
        for email, status in statuses.items():
            if status == "P":
                present[role].append({"email": email, "solver": "Y"})
                icon = "Present"
            else:
                absent[role].append(email)
                icon = "Absent "
            if verbose:
                print(f"  {email:<42} {role:<6} {icon}")

    if verbose:
        print(f"\n  -- SUMMARY ----------------------------------------")
        print(f"  Present Employees : {[p['email'] for p in present['Emp']] or 'None'}")
        print(f"  Present Vendors   : {[p['email'] for p in present['Ven']] or 'None'}")
        print(f"  Absent Employees  : {absent['Emp'] or 'None'}")
        print(f"  Absent Vendors    : {absent['Ven'] or 'None'}")

    return present, absent, {"employee": emp_status, "vendor": ven_status}


def get_next_working_date(date_str):
    """Returns the next calendar date as DD-MM-YYYY (skips weekends)."""
    dt = datetime.strptime(date_str, "%d-%m-%Y")
    next_dt = dt + timedelta(days=1)
    # Skip Saturday (5) and Sunday (6)
    while next_dt.weekday() >= 5:
        next_dt += timedelta(days=1)
    return next_dt.strftime("%d-%m-%Y")


# ---- Standalone run ----
if __name__ == "__main__":
    today = datetime.now().strftime("%d-%m-%Y")
    print(f"  Using today's date : {today}")
    present, absent, raw = check_attendance(today)

    tomorrow = get_next_working_date(today)
    print(f"\n  Checking next working day  : {tomorrow}")
    p2, a2, _ = check_attendance(tomorrow, label="TOMORROW")

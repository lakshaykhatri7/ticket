# ============================================================
#  step3_allocate_sr.py
#  Same allocation logic as step3_allocate.py
#  but uses SR-specific field names:
#    - Ticket ID : IncidentTicketID
#    - Assignee  : AssignedEngineer
# ============================================================

import pandas as pd
from config import EMP_SPLIT


# ──────────────────────────────────────────────────────────────
#  1. NEW SR ALLOCATION  (30% Emp / 70% Ven)
# ──────────────────────────────────────────────────────────────

def allocate_new_sr(present, new_sr_ids):
    """
    Splits new SR IDs — 30% to Employees, 70% to Vendors.

    Returns:
        allocation (dict) : { email : [sr_id, ...] }
    """
    total = len(new_sr_ids)

    if total == 0:
        print("\n  No NEW SR tickets to allocate.")
        return {}

    emp_share = round(total * EMP_SPLIT)
    ven_share = total - emp_share

    print("\n" + "=" * 60)
    print("  STEP 3a (SR) : NEW SR Allocation  (Emp 30% | Ven 70%)")
    print("=" * 60)
    print(f"\n  Total New SR     : {total}")
    print(f"  Employee Share   : {emp_share}  (30%)")
    print(f"  Vendor Share     : {ven_share}  (70%)")

    sr_pool    = list(new_sr_ids)
    allocation = {}
    idx        = 0

    for role, share in [("Emp", emp_share), ("Ven", ven_share)]:
        solvers = [p["email"] for p in present[role] if p["solver"] == "Y"]
        label   = "Employees" if role == "Emp" else "Vendors"

        print(f"\n  -- {label} ({role}) --------------------")
        print(f"  Share : {share} SR | Solvers Present : {len(solvers)}")

        if not solvers:
            print(f"  No solver present — skipping {share} SR tickets.")
            idx += share
            continue

        for i, email in enumerate(solvers):
            count  = share // len(solvers) + (1 if i < share % len(solvers) else 0)
            chunk  = sr_pool[idx: idx + count]
            idx   += count
            allocation[email] = allocation.get(email, []) + chunk
            print(f"  {email:<44} -> {count:>3} SR : {chunk}")

    print(f"\n  -- NEW SR ALLOCATION SUMMARY ----------------")
    for email, slist in allocation.items():
        print(f"  {email:<44} : {len(slist)} SR")

    return allocation


# ──────────────────────────────────────────────────────────────
#  2. IN-PROGRESS SR RE-ALLOCATION
# ──────────────────────────────────────────────────────────────

def _get_present_pool(present):
    pool  = [p["email"] for p in present["Emp"] if p["solver"] == "Y"]
    pool += [p["email"] for p in present["Ven"] if p["solver"] == "Y"]
    return pool


def _pick_next(pool, last_index):
    if not pool:
        return None, last_index
    idx = (last_index + 1) % len(pool)
    return pool[idx], idx


def reallocate_inprogress_sr(assigned_df, present_today, absent_today,
                              present_tomorrow, absent_tomorrow, email_role_map):
    """
    Re-checks each In-Progress SR:
      - Assignee present today + tomorrow  -> keep
      - Assignee present today, absent tomorrow -> reassign to someone present tomorrow
      - Assignee absent today              -> reassign to someone present today

    SR uses field 'AssignedEngineer' (not 'Assigned_Engineer_Email').

    Returns:
        keep_map     (dict) : { email : [sr_ids] }
        reassign_map (dict) : { new_email : [sr_ids] }
        reassign_log (list) : human-readable log
    """

    print("\n" + "=" * 70)
    print("  STEP 3b (SR) : In-Progress SR Re-allocation Check")
    print("=" * 70)

    if assigned_df.empty:
        print("  No In-Progress SR found.")
        return {}, {}, []

    # Present email sets
    today_present = set()
    for role in ("Emp", "Ven"):
        for p in present_today[role]:
            today_present.add(p["email"].lower())

    tomorrow_present = set()
    if present_tomorrow:
        for role in ("Emp", "Ven"):
            for p in present_tomorrow[role]:
                tomorrow_present.add(p["email"].lower())

    today_pool    = _get_present_pool(present_today)
    tomorrow_pool = _get_present_pool(present_tomorrow) if present_tomorrow else []

    rr_today    = -1
    rr_tomorrow = -1

    keep_map     = {}
    reassign_map = {}
    reassign_log = []

    # SR uses IncidentTicketID as the ticket ID field
    id_col       = "IncidentTicketID" if "IncidentTicketID" in assigned_df.columns \
                   else assigned_df.columns[0]
    # SR uses AssignedEngineer (not Assigned_Engineer_Email)
    assignee_col = "AssignedEngineer" if "AssignedEngineer" in assigned_df.columns else None

    print(f"\n  Checking {len(assigned_df)} In-Progress SR ticket(s) ...\n")
    print(f"  {'SR ID':<14} {'Current Assignee':<40} Action")
    print(f"  {'-'*80}")

    for _, row in assigned_df.iterrows():
        sr_id = str(row[id_col])

        # Resolve assignee email
        assignee_email = None
        if assignee_col and pd.notna(row.get(assignee_col)):
            assignee_email = str(row[assignee_col]).strip()

        if not assignee_email:
            new_email, rr_today = _pick_next(today_pool, rr_today)
            if new_email:
                reassign_map.setdefault(new_email, []).append(sr_id)
                reassign_log.append({
                    "SR_ID": sr_id, "Old Assignee": "Unknown",
                    "New Assignee": new_email,
                    "Reason": "Assignee unknown — reassigned to present person"
                })
                print(f"  {sr_id:<14} {'Unknown':<40} Reassigned -> {new_email}")
            else:
                print(f"  {sr_id:<14} {'Unknown':<40} NO ONE PRESENT — skipped")
            continue

        assignee_lower      = assignee_email.lower()
        present_today_flag  = assignee_lower in today_present
        present_tomorrow_flag = assignee_lower in tomorrow_present if tomorrow_present else True

        if present_today_flag and present_tomorrow_flag:
            keep_map.setdefault(assignee_email, []).append(sr_id)
            print(f"  {sr_id:<14} {assignee_email:<40} Keep (present today & tomorrow)")

        elif present_today_flag and not present_tomorrow_flag:
            new_email, rr_tomorrow = _pick_next(tomorrow_pool, rr_tomorrow)
            if new_email and new_email.lower() != assignee_lower:
                reassign_map.setdefault(new_email, []).append(sr_id)
                reassign_log.append({
                    "SR_ID": sr_id, "Old Assignee": assignee_email,
                    "New Assignee": new_email,
                    "Reason": "Assignee absent tomorrow — reassigned proactively"
                })
                print(f"  {sr_id:<14} {assignee_email:<40} Reassigned -> {new_email}  (absent tomorrow)")
            else:
                keep_map.setdefault(assignee_email, []).append(sr_id)
                print(f"  {sr_id:<14} {assignee_email:<40} Keep (no alt for tomorrow)")

        else:
            new_email, rr_today = _pick_next(today_pool, rr_today)
            if new_email:
                reassign_map.setdefault(new_email, []).append(sr_id)
                reassign_log.append({
                    "SR_ID": sr_id, "Old Assignee": assignee_email,
                    "New Assignee": new_email,
                    "Reason": "Assignee absent today — reassigned to present person"
                })
                print(f"  {sr_id:<14} {assignee_email:<40} Reassigned -> {new_email}  (absent today)")
            else:
                print(f"  {sr_id:<14} {assignee_email:<40} NO ONE PRESENT — skipped")

    total_keep     = sum(len(v) for v in keep_map.values())
    total_reassign = sum(len(v) for v in reassign_map.values())

    print(f"\n  -- SR RE-ALLOCATION SUMMARY -------------------------")
    print(f"  SR kept (no change)  : {total_keep}")
    print(f"  SR reassigned        : {total_reassign}")
    if reassign_log:
        print(f"\n  Reassignment details:")
        for r in reassign_log:
            print(f"    SR {r['SR_ID']}: {r['Old Assignee']} -> {r['New Assignee']}")
            print(f"      Reason: {r['Reason']}")

    return keep_map, reassign_map, reassign_log

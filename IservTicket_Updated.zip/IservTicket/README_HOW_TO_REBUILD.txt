HOW THE SHARED API CONFIG NOW WORKS
====================================

api_config.xlsx (in this IservTicket folder) now controls the API_URL and
API_KEY for BOTH tools:
  - NewTo AssignBot.exe        (built from Source_NewToAssignBot)
  - AllTicketAssignment.exe    (built from Source_AllTicketAssignment)

It has one sheet named "Config" with two columns:
  Key       | Value
  API_URL   | http://...
  API_KEY   | xxxxx

Just edit the values in this Excel file and save it. Both exe's will pick
up the new values automatically the next time they run -- no rebuild
needed for that.

If api_config.xlsx is ever missing, renamed, moved, unreadable, or missing
a value for API_URL or API_KEY, both tools will now STOP immediately and
show a clear error (a popup message box, plus the same message printed to
the console) instead of silently continuing with old values. This makes
sure a bad/missing config is never used by accident.

IMPORTANT: api_config.xlsx must stay in the SAME FOLDER as the two exe's.


WHY I COULDN'T JUST HAND YOU NEW .EXE FILES DIRECTLY
======================================================
I built and tested this in a Linux environment, and Windows .exe files
can only be built (compiled) on Windows with PyInstaller -- they can't be
cross-compiled from Linux. Your original exe's were built on a Windows
machine (I can see 3.13 pycache files and Windows-style spec files from
your project), so the rebuild has to happen there too.

The good news: I've already made all the code changes. You just need to
run ONE command per project to rebuild the exe. It takes a minute.


HOW TO REBUILD BOTH EXE'S ON WINDOWS
======================================
1. Make sure Python and these packages are installed on the Windows machine
   that originally built these exe's:
       pip install pyinstaller openpyxl requests

2. Open Command Prompt / PowerShell.

3. Rebuild "NewTo AssignBot.exe":
       cd path\to\Source_NewToAssignBot
       pyinstaller main_sr.spec

   The new exe will appear in:
       Source_NewToAssignBot\dist\main_sr.exe
   Rename it to "NewTo AssignBot.exe" (or just keep using main_sr.exe --
   both are fine, just make sure whichever name you use matches how you
   launch it).

4. Rebuild "AllTicketAssignment.exe":
       cd path\to\Source_AllTicketAssignment
       pyinstaller main_sr.spec

   The new exe will appear in:
       Source_AllTicketAssignment\dist\main_sr.exe
   Rename it to "AllTicketAssignment.exe".

5. Copy both renamed exe's into this IservTicket folder, next to
   api_config.xlsx, replacing the old exe's.

6. Done. From now on, to change the API URL or API Key, just edit
   api_config.xlsx -- no more rebuilding needed for config changes.


WHAT I CHANGED IN THE CODE
============================
Only config.py in each project was changed. It now:
  - Looks for api_config.xlsx in the same folder as the running exe
  - Reads API_URL and API_KEY from the "Config" sheet
  - If the file is missing, can't be opened, or a value is blank, it
    shows an error popup + console message and stops the program
    (it no longer silently falls back to old hardcoded values)

I also added 'openpyxl' and 'et_xmlfile' to hiddenimports in each
main_sr.spec file, since openpyxl is loaded dynamically and PyInstaller
can otherwise miss bundling it.

No other files (step1_fetch_sr.py, step4_post_sr.py, etc.) needed changes
since they already just import API_URL / API_KEY from config.py.

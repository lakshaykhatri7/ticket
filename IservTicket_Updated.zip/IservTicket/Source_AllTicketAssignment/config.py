# ============================================================
#  config.py -- All settings in one place
# ============================================================
import os
import sys

# --- Read API settings from shared Excel file (api_config.xlsx) ---
# The Excel file must sit in the SAME FOLDER as this exe (or script).
# Sheet: "Config", Column A = Key, Column B = Value
#   API_URL | http://...
#   API_KEY | xxxxx
#
# If the Excel file is missing, unreadable, or missing a value, the tool
# stops immediately and shows an error instead of silently continuing.


def _get_base_dir():
    """Folder the exe (or script) is running from."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def _fail(message):
    """Show the error clearly (console + popup) and stop the program."""
    full_message = (
        "CONFIG ERROR\n"
        "============\n"
        f"{message}\n\n"
        "Fix api_config.xlsx and run the tool again."
    )
    print(full_message, file=sys.stderr)
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Config Error", full_message)
        root.destroy()
    except Exception:
        # If a popup can't be shown (e.g. no display), the console
        # message above is still there.
        pass
    sys.exit(1)


def _load_api_settings():
    base_dir = _get_base_dir()
    excel_path = os.path.join(base_dir, "api_config.xlsx")

    if not os.path.isfile(excel_path):
        _fail(f"api_config.xlsx was not found in:\n{base_dir}")

    try:
        from openpyxl import load_workbook
        wb = load_workbook(excel_path, data_only=True)
    except Exception as e:
        _fail(f"api_config.xlsx could not be read/opened.\nDetails: {e}")

    ws = wb["Config"] if "Config" in wb.sheetnames else wb.active
    values = {}
    for row in ws.iter_rows(min_row=2, max_col=2, values_only=True):
        if not row or row[0] is None:
            continue
        key = str(row[0]).strip()
        val = "" if row[1] is None else str(row[1]).strip()
        values[key] = val

    api_url = values.get("API_URL", "").strip()
    api_key = values.get("API_KEY", "").strip()

    missing = [name for name, val in (("API_URL", api_url), ("API_KEY", api_key)) if not val]
    if missing:
        _fail(
            "api_config.xlsx is missing a value for: " + ", ".join(missing) +
            "\nMake sure the 'Config' sheet has API_URL and API_KEY filled in column B."
        )

    return api_url, api_key


API_URL, API_KEY = _load_api_settings()
ORG_ID  = 1
INSTANCE = "ITD"

# --- Workgroup & Assignment ---
# This MUST match one sheet name in ATTENDANCE.xlsx, for example:
#   SAP_MDM - OTH
#   SAP_MDM - MM
WORKGROUP       = "SAP_MDM - OTH"
# Blank means fetch all statuses so NEW + Assigned tickets can be checked.
FETCH_STATUS    = ""

# --- Excel / Data File ---
# Attendance file naming convention: "<MonthName> Attendance.xlsx"
# e.g.  "July Attendance.xlsx"  /  "August Attendance.xlsx"
#
# The code automatically picks the file matching the current month.
# You do NOT need to change anything here when you add a new month's file --
# just drop the new file (e.g. "August Attendance.xlsx") in this folder
# and the code will pick it up automatically when August starts.
#
# EXCEL_FILE is no longer set here -- see step2_attendance.py -> _find_attendance_file()

# --- Defaults only if Excel ratio is missing ---
DEFAULT_EMP_SPLIT = 0.30
DEFAULT_VEN_SPLIT = 0.70

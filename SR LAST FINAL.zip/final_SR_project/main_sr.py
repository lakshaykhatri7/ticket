# ============================================================
#  main_sr.py -- Service Request Management -- Full Auto Flow
#
#  Every run creates a new output folder:
#      runs/DDMMYYYY_HHMMSS/
#  All Excel files, JSON files, and the log file for that run
#  are saved inside that folder automatically.
#
#  Logic:
#   1. Fetch service requests from API (SR_GetServiceRequestList)
#   1b. Split fetched tickets into 4 Excel files by status:
#         sr_new_*.xlsx / sr_assigned_*.xlsx / sr_inprogress_*.xlsx / sr_pending_*.xlsx
#   2. Read attendance from ATTENDANCE.xlsx
#   3. New / Pending / In Progress SRs -> split via Employee/Vendor ratio
#      across PRESENT people (each status gets its own split target)
#   4. Already-Assigned SRs:
#        - assignee present -> remain assigned to same person
#        - assignee absent  -> reassign to a present person
#   5. Post only SRs that need assignment/reassignment
#   6. Create final summary report Excel
#
#  Run: python main_sr.py
# ============================================================

import os
from datetime import datetime
from logger import start_logging, stop_logging
from step1_fetch_sr import fetch_service_requests
from step1b_split_by_status import split_tickets_by_status
from step2_attendance import check_attendance
from step3_allocate_sr import allocate_sr_actions
from step4_post_sr import post_sr_actions
from step5_report_sr import create_sr_assignment_report


def _make_run_folder():
    """
    Creates output/runs/DDMMYYYY_HHMMSS/ next to this script and returns its path.
    All output files for this run (Excel, JSON, log) go there.
    """
    timestamp = datetime.now().strftime("%d%m%Y_%H%M%S")
    base = os.path.dirname(os.path.abspath(__file__))
    folder = os.path.join(base, "output", "runs", timestamp)
    os.makedirs(folder, exist_ok=True)
    return folder


def main():
    out_dir = _make_run_folder()

    # Log file goes into the run folder too
    start_logging(out_dir=out_dir)

    try:
        print("\n" + "*" * 55)
        print("   SERVICE REQUEST MANAGEMENT SYSTEM -- Full Auto Flow")
        print("*" * 55)
        print(f"\n  Output folder : {out_dir}")

        date = datetime.now().strftime("%d-%m-%Y")
        print(f"  Using today's date : {date}")

        # STEP 1: Fetch service requests
        excel_file, sr_numbers, sr_rows = fetch_service_requests(out_dir=out_dir)

        if not sr_rows:
            print("\n[WARNING] No service requests fetched. Stopping program.")
            return

        print(f"\n  Total Service Requests (auto-detected) : {len(sr_rows)}")

        # STEP 1b: Split fetched tickets into 4 status-wise Excel files
        # (New only / Assigned only / In Progress only / Pending only)
        split_tickets_by_status(sr_rows, out_dir=out_dir)

        # STEP 2: Attendance (shared logic/file with the Incident flow)
        present, absent, rows = check_attendance(date)

        if present is None:
            print("\n[ERROR] Attendance not found. Stopping program.")
            return

        # STEP 3: Apply user logic SR-by-SR
        actions, kept, skipped = allocate_sr_actions(sr_rows, present, rows, out_dir=out_dir)

        post_results = []

        # STEP 4: Post only required SRs
        if not actions:
            print("\nNo SR needs assignment/reassignment. Nothing to post.")
        else:
            confirm = input("\nPost only these required SR updates via API now? (y/n): ").strip().lower()

            if confirm == "y":
                post_results = post_sr_actions(actions, out_dir=out_dir)
            else:
                print("\nAPI posting skipped.")

        # STEP 5: Final Excel report for every fetched SR
        create_sr_assignment_report(
            sr_rows, actions, kept, skipped, rows, post_results, out_dir=out_dir
        )

        print("\n" + "*" * 55)
        print("   Done!")
        print(f"   All files saved to: {out_dir}")
        print("*" * 55)

    finally:
        stop_logging()


if __name__ == "__main__":
    main()

# ============================================================
#  main_sr.py -- Service Request Management -- Full Auto Flow
#
#  Fixed folder layout (no more per-run "runs/DDMMYYYY_HHMMSS" folder):
#
#      automatic iserv ticketing/
#          input/
#              extracted details/   -> all JSON files + all Excel files
#                                       EXCEPT the report and the
#                                       attendance workbook
#              monthly attendance/  -> ATTENDANCE.xlsx (place it here)
#          output/
#              -> only the final sr_assignment_report_*.xlsx file
#
#  Logic:
#   1. Fetch service requests from API (SR_GetServiceRequestList)
#   1b. Split fetched tickets into 4 Excel files by status:
#         sr_new_*.xlsx / sr_assigned_*.xlsx / sr_inprogress_*.xlsx / sr_pending_*.xlsx
#   2. Read attendance from ATTENDANCE.xlsx
#   3. New / Pending / In Progress SRs -> split via Employee/Vendor ratio
#      across PRESENT people (each status gets its own split target)
#   4. Already-Assigned SRs:
#        - assignee present -> remain assigned to same person
#        - assignee absent  -> reassign to a present person
#   5. Post only SRs that need assignment/reassignment
#   6. Create final summary report Excel
#
#  Run: python main_sr.py
# ============================================================

import os
from datetime import datetime
from logger import start_logging, stop_logging
from step1_fetch_sr import fetch_service_requests
from step1b_split_by_status import split_tickets_by_status
from step2_attendance import check_attendance
from step3_allocate_sr import allocate_sr_actions
from step4_post_sr import post_sr_actions
from step5_report_sr import create_sr_assignment_report


def _get_folders():
    """
    Ensures the fixed folder layout exists and returns
    (extracted_dir, attendance_dir, output_dir).

    Layout (scripts live OUTSIDE this folder, in their own "scripts" folder;
    "automatic iserv ticketing" contains ONLY input/ and output/):

        scripts/                        <- this file lives here
        automatic iserv ticketing/
            input/
                extracted details/
                monthly attendance/
            output/
    """
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(scripts_dir)
    ticketing_dir = os.path.join(project_root, "AUTOMATICISERVTICKETING")

    extracted_dir = os.path.join(ticketing_dir, "input", "extracted details")
    attendance_dir = os.path.join(ticketing_dir, "input", "monthly attendance")
    output_dir = os.path.join(ticketing_dir, "output")

    os.makedirs(extracted_dir, exist_ok=True)
    os.makedirs(attendance_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)

    return extracted_dir, attendance_dir, output_dir


def main():
    extracted_dir, attendance_dir, output_dir = _get_folders()

    # Log file goes into the "extracted details" input folder along with
    # every other JSON/Excel file this run produces (except the report).
    start_logging(out_dir=extracted_dir)

    try:
        print("\n" + "*" * 55)
        print("   SERVICE REQUEST MANAGEMENT SYSTEM -- Full Auto Flow")
        print("*" * 55)
        print(f"\n  Input  (extracted details) folder : {extracted_dir}")
        print(f"  Input  (monthly attendance) folder : {attendance_dir}")
        print(f"  Output (report)             folder : {output_dir}")

        date = datetime.now().strftime("%d-%m-%Y")
        print(f"  Using today's date : {date}")

        # STEP 1: Fetch service requests -> JSON + Excel go to "extracted details"
        excel_file, sr_numbers, sr_rows = fetch_service_requests(out_dir=extracted_dir)

        if not sr_rows:
            print("\n[WARNING] No service requests fetched. Stopping program.")
            return

        print(f"\n  Total Service Requests (auto-detected) : {len(sr_rows)}")

        # STEP 1b: Split fetched tickets into 4 status-wise Excel files
        # (New only / Assigned only / In Progress only / Pending only)
        split_tickets_by_status(sr_rows, out_dir=extracted_dir)

        # STEP 2: Attendance -- reads ATTENDANCE.xlsx from "monthly attendance"
        # (path is resolved via config.EXCEL_FILE)
        present, absent, rows = check_attendance(date)

        if present is None:
            print("\n[ERROR] Attendance not found. Stopping program.")
            return

        # STEP 3: Apply user logic SR-by-SR
        actions, kept, skipped = allocate_sr_actions(sr_rows, present, rows, out_dir=extracted_dir)

        post_results = []

        # STEP 4: Post only required SRs -> result Excel goes to "extracted details"
        if not actions:
            print("\nNo SR needs assignment/reassignment. Nothing to post.")
        else:
            confirm = input("\nPost only these required SR updates via API now? (y/n): ").strip().lower()

            if confirm == "y":
                post_results = post_sr_actions(actions, out_dir=extracted_dir)
            else:
                print("\nAPI posting skipped.")

        # STEP 5: Final Excel report -> goes ONLY to the "output" folder
        create_sr_assignment_report(
            sr_rows, actions, kept, skipped, rows, post_results,
            out_dir=extracted_dir, report_dir=output_dir,
        )

        print("\n" + "*" * 55)
        print("   Done!")
        print(f"   Extracted details saved to : {extracted_dir}")
        print(f"   Final report saved to      : {output_dir}")
        print("*" * 55)

    finally:
        stop_logging()


if __name__ == "__main__":
    main()

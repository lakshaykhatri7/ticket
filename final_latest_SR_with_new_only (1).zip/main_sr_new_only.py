# ============================================================
#  main_sr_new_only.py
#  Fetches ONLY "New" Service Requests and assigns them.
#
#  Difference from main_sr.py (full flow):
#    - API is called with Status="New" so ONLY new unassigned
#      SRs are fetched. No Assigned / Pending / In-Progress
#      tickets are touched at all.
#    - All New SRs are split via the Employee/Vendor ratio
#      (read from ATTENDANCE.xlsx row 2) across present
#      Solver=Y people.
#    - Everything else (run folder, attendance, posting, report,
#      logging) works exactly the same as main_sr.py.
#
#  Run: python main_sr_new_only.py
# ============================================================

import os
from datetime import datetime

from logger import start_logging, stop_logging
from step1_fetch_sr import fetch_service_requests
from step2_attendance import check_attendance
from step3_allocate_sr import allocate_sr_actions
from step4_post_sr import post_sr_actions
from step5_report_sr import create_sr_assignment_report


def _make_run_folder():
    """
    Creates runs/new_only_DDMMYYYY_HHMMSS/ next to this script.
    Prefixed with 'new_only_' so runs from this script are clearly
    separate from the full-flow runs.
    """
    timestamp = datetime.now().strftime("%d%m%Y_%H%M%S")
    base = os.path.dirname(os.path.abspath(__file__))
    folder = os.path.join(base, "runs", f"new_only_{timestamp}")
    os.makedirs(folder, exist_ok=True)
    return folder


def main():
    out_dir = _make_run_folder()
    start_logging(out_dir=out_dir)

    try:
        print("\n" + "*" * 55)
        print("   SR ASSIGNMENT -- NEW TICKETS ONLY")
        print("*" * 55)
        print(f"\n  Output folder : {out_dir}")

        date = datetime.now().strftime("%d-%m-%Y")
        print(f"  Using today's date : {date}")

        # ----------------------------------------------------------
        # STEP 1 : Fetch ONLY New SRs from the API
        # ----------------------------------------------------------
        # We temporarily override FETCH_STATUS to "New" so the API
        # returns only unassigned New tickets, regardless of what
        # config.py has set for the full flow.
        import config
        _original_status = config.FETCH_STATUS
        config.FETCH_STATUS = "New"

        try:
            excel_file, sr_numbers, sr_rows = fetch_service_requests(out_dir=out_dir)
        finally:
            config.FETCH_STATUS = _original_status   # always restore

        if not sr_rows:
            print("\n  [WARNING] No New service requests found. Nothing to assign.")
            return

        # Quick sanity check -- confirm everything fetched really is New
        non_new = [r for r in sr_rows if str(r.get("Status", "")).strip().lower() != "new"]
        if non_new:
            print(f"\n  [WARNING] {len(non_new)} non-New SR(s) slipped through the API filter.")
            print("            Filtering them out client-side.")
            sr_rows = [r for r in sr_rows if r not in non_new]

        print(f"\n  New SRs to assign : {len(sr_rows)}")

        # ----------------------------------------------------------
        # STEP 2 : Read today's attendance
        # ----------------------------------------------------------
        present, absent, rows = check_attendance(date)

        if present is None:
            print("\n  [ERROR] Attendance not found. Stopping.")
            return

        # ----------------------------------------------------------
        # STEP 3 : Allocate -- all tickets are New so every one
        #          goes through the Employee/Vendor split.
        #          Existing step3 handles this correctly already:
        #          New tickets -> split via ratio, Solver=Y only.
        # ----------------------------------------------------------
        actions, kept, skipped = allocate_sr_actions(
            sr_rows, present, rows, out_dir=out_dir
        )

        # ----------------------------------------------------------
        # STEP 4 : Post
        # ----------------------------------------------------------
        post_results = []

        if not actions:
            print("\n  No actions to post (no present solvers, or all skipped).")
        else:
            print(f"\n  SRs to assign : {len(actions)}")
            for a in actions:
                print(f"    {a.get('sr_no')} -> {a.get('email')}  ({a.get('reason','')})")

            confirm = input("\n  Post these SR assignments via API now? (y/n): ").strip().lower()

            if confirm == "y":
                post_results = post_sr_actions(actions, out_dir=out_dir)
            else:
                print("\n  API posting skipped.")

        # ----------------------------------------------------------
        # STEP 5 : Report
        # ----------------------------------------------------------
        create_sr_assignment_report(
            sr_rows, actions, kept, skipped, rows, post_results, out_dir=out_dir
        )

        print("\n" + "*" * 55)
        print("   Done!")
        print(f"   All files saved to: {out_dir}")
        print("*" * 55)

    finally:
        stop_logging()


if __name__ == "__main__":
    main()

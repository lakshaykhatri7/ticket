# ============================================================
#  step3_allocate.py
#  Decides who gets each ticket, based on the ticket's Status.
#
#  NO "Solver" CONCEPT -- everyone marked Present (P) today is
#  eligible to receive tickets. Whoever is present gets tickets;
#  if absent, the ticket goes to someone else who is present.
#
#  Rule:
#    Status = "New"
#       -> goes into the Employee/Vendor split using the ratio read
#          from row 2 of the roster sheet (e.g. 20% Employee / 80%
#          Vendor), handed out ROUND-ROBIN (one ticket at a time,
#          cycling through the Present people) within each role.
#
#    Status = "Assigned"
#       -> stays with the person it's already assigned to
#          (matched by "Executive Name" against the emails in
#          the roster sheet), IF that person is Present today.
#       -> if that person is Absent today, the ticket is handed
#          to the NEXT Present person in the SAME role, round-robin
#          style (Employee stays Employee, Vendor stays Vendor).
#
#    Any other / unrecognised Status
#       -> skipped, printed clearly as a warning so it can be
#          checked manually.
# ============================================================

from config import ROSTER_FILE


def _normalize_name(text):
    """
    Turns an email's local-part or an 'Executive Name' string into a
    normalized, order-independent set of words, so the two can be
    matched even if formatted differently
    (e.g. email 'JKTECH_Neha.Aswal' vs ticket name 'Neha Aswal').
    """
    text = str(text).strip()
    if "_" in text:
        # drop a vendor-company prefix, e.g. JKTECH_ / DTL_ / MYSOFTLABS_
        text = text.split("_")[-1]
    text = text.replace(".", " ").replace("_", " ")
    words = [w.lower() for w in text.split() if w]
    return tuple(sorted(words))


def _build_name_lookup(all_people):
    """
    Builds { normalized_name : {"email", "role", "present"} }
    using the FULL roster (present + absent people) from step2, so an
    'Executive Name' on a ticket can be matched to a roster email no
    matter whether that person is present today or not.

    Two keys are registered per person, since "Executive Name" on a
    ticket might be just a first name (matches the roster's "Name"
    column, e.g. "Raj") or a fuller name (matches the email's
    local-part, e.g. "raj.patil" -> "Raj Patil"):
      - normalized "Name" column value
      - normalized email local-part (text before the @)
    """
    lookup = {}
    for p in all_people or []:
        entry = {
            "email": p["email"],
            "role": p["role"],
            "present": p["status"] == "P",
        }

        if p.get("name"):
            lookup[_normalize_name(p["name"])] = entry

        email_key = _normalize_name(p["email"].split("@")[0])
        lookup.setdefault(email_key, entry)

    return lookup


# ────────────────────────────────────────────────────────────────
#  ROUND-ROBIN distribution
# ────────────────────────────────────────────────────────────────
class RoundRobin:
    """
    Cycles through a list of emails, one ticket at a time.
    """
    def __init__(self, people):
        self.people = list(people)
        self.idx = 0

    def next(self):
        if not self.people:
            return None
        email = self.people[self.idx % len(self.people)]
        self.idx += 1
        return email


def _hand_out_round_robin(ticket_pool, people, final_assignment, label):
    """
    Distributes ticket_pool ONE TICKET AT A TIME, cycling through
    `people` in round-robin order, and records the exact ticket
    numbers each person gets into final_assignment.
    """
    if not ticket_pool:
        return
    if not people:
        print(f"  No Present {label} -- {len(ticket_pool)} ticket(s) skipped: {ticket_pool}")
        return

    rr = RoundRobin(people)
    assigned_log = {}

    for ticket_no in ticket_pool:
        email = rr.next()
        final_assignment.setdefault(email, []).append(ticket_no)
        assigned_log.setdefault(email, []).append(ticket_no)

    for email, tickets in assigned_log.items():
        print(f"  {email:<38} <- {tickets}")


def allocate_tickets(ticket_info, present, all_people, ratio):
    """
    Args:
        ticket_info (dict): { ticket_no : {"Status":.., "Executive Name":..} }
                             -- from step1
        present (dict)    : { "Emp":[{email,name}], "Ven":[...] }
                             -- from step2 (Present people only, TODAY)
        all_people (list) : [{"email","name","role","status"}, ...]
                             -- from step2, FULL roster (present + absent)
        ratio (dict)      : { "Emp": <int>, "Ven": <int> } -- e.g. {"Emp":20,"Ven":80}
                             -- read from row 2 of the roster sheet by step2

    No Solver filter -- EVERY Present person is eligible to receive
    tickets.

    Distribution within each role is ROUND-ROBIN: tickets are handed
    out one at a time, cycling through that role's Present people.

    Returns:
        final_assignment (dict): { email : [ticket_no, ticket_no, ...] }
    """

    print("\n" + "="*55)
    print("  STEP 3 : Ticket Allocation (Round-Robin)")
    print("="*55)

    name_lookup = _build_name_lookup(all_people)

    new_tickets        = []              # Status == New
    direct_assign      = {}              # ticket_no -> email (Assigned + Present)
    reassign_pool       = {"Emp": [], "Ven": []}   # Assigned + Absent
    unmatched_tickets   = []             # Assigned, but name didn't match anyone
    skipped_tickets     = []             # any other/unknown status

    for ticket_no, info in ticket_info.items():
        status = str(info.get("Status", "")).strip().lower()
        exec_name = info.get("Executive Name", "")

        if status == "new":
            new_tickets.append(ticket_no)

        elif status == "assigned":
            match = name_lookup.get(_normalize_name(exec_name))

            if not match:
                unmatched_tickets.append(ticket_no)
                print(f"  [WARN] Ticket {ticket_no}: assigned executive "
                      f"'{exec_name}' not found in {ROSTER_FILE} -- skipped.")
                continue

            if match["present"]:
                direct_assign[ticket_no] = match["email"]
            else:
                # Absent today -- reassign within same role
                reassign_pool[match["role"]].append(ticket_no)

        else:
            skipped_tickets.append(ticket_no)
            print(f"  [WARN] Ticket {ticket_no}: unrecognised Status "
                  f"'{info.get('Status')}' -- skipped.")

    final_assignment = {}

    # ---- 1) Already-Assigned tickets, person Present -> stays put ----
    print(f"\n  -- Assigned tickets, person Present (stays as-is) --------")
    if direct_assign:
        for ticket_no, email in direct_assign.items():
            final_assignment.setdefault(email, []).append(ticket_no)
            print(f"  Ticket {ticket_no:<10} -> stays with {email}")
    else:
        print("  None")

    # ---- 2) Already-Assigned tickets, person Absent -> reassign, same role ----
    #          -> ROUND-ROBIN among present people in that role
    print(f"\n  -- Assigned tickets, needing reassignment (round-robin, same role) --")
    any_reassigned = False
    for role, tickets in reassign_pool.items():
        if not tickets:
            continue
        any_reassigned = True
        label = "Employees" if role == "Emp" else "Vendors"
        present_people = [p["email"] for p in present[role]]
        print(f"  {label} : {tickets}")
        _hand_out_round_robin(tickets, present_people, final_assignment, label)
    if not any_reassigned:
        print("  None")

    # ---- 3) New tickets -> Employee/Vendor split, ratio from roster sheet ----
    #          -> within each role, ROUND-ROBIN among present people
    total_new = len(new_tickets)
    emp_total = round(total_new * ratio["Emp"] / 100)
    ven_total = total_new - emp_total

    print(f"\n  -- New tickets : {ratio['Emp']}/{ratio['Ven']} split (Emp {ratio['Emp']}% | Ven {ratio['Ven']}%) --")
    print(f"  Total New Tickets : {total_new}")
    print(f"  Employee Share    : {emp_total}")
    print(f"  Vendor Share      : {ven_total}")

    pool = list(new_tickets)
    idx = 0
    for role, share in [("Emp", emp_total), ("Ven", ven_total)]:
        label = "Employees" if role == "Emp" else "Vendors"
        chunk = pool[idx: idx + share]
        idx += share
        present_people = [p["email"] for p in present[role]]
        print(f"\n  -- {label} (round-robin) --")
        _hand_out_round_robin(chunk, present_people, final_assignment, label)

    # ---- FINAL SUMMARY ----
    print(f"\n  -- FINAL ALLOCATION --------------------------")
    if final_assignment:
        for email, tickets in final_assignment.items():
            print(f"  {email:<38} : {len(tickets)} ticket(s) {tickets}")
    else:
        print("  Nobody received any tickets.")

    if unmatched_tickets:
        print(f"\n  Unmatched (Executive Name not found in {ROSTER_FILE}) : {unmatched_tickets}")
    if skipped_tickets:
        print(f"  Skipped (unrecognised Status)                            : {skipped_tickets}")

    return final_assignment


# ---- Standalone run ----
if __name__ == "__main__":
    # Test data, matching the shapes step2_attendance.py now produces
    sample_ticket_info = {
        "653501": {"Status": "New",      "Executive Name": ""},
        "653502": {"Status": "New",      "Executive Name": ""},
        "653503": {"Status": "New",      "Executive Name": ""},
        "653504": {"Status": "Assigned", "Executive Name": "Raj"},       # present
        "653505": {"Status": "Assigned", "Executive Name": "Zafar"},     # absent -> reassigned
        "653506": {"Status": "New",      "Executive Name": ""},
    }
    sample_present = {
        "Emp": [{"email": "anupam.jha@maruti.co.in", "name": "Anupam"},
                {"email": "shibasish.kar@maruti.co.in", "name": "Shibasish"}],
        "Ven": [{"email": "raj.patil@kpmg.com", "name": "Raj"},
                {"email": "rahil.rathi@kpmg.com", "name": "Rahil"}]
    }
    sample_all_people = [
        {"email": "anupam.jha@maruti.co.in", "name": "Anupam", "role": "Emp", "status": "P"},
        {"email": "shibasish.kar@maruti.co.in", "name": "Shibasish", "role": "Emp", "status": "P"},
        {"email": "raj.patil@kpmg.com", "name": "Raj", "role": "Ven", "status": "P"},
        {"email": "rahil.rathi@kpmg.com", "name": "Rahil", "role": "Ven", "status": "P"},
        {"email": "zafar.mohammad@kpmg.com", "name": "Zafar", "role": "Ven", "status": "A"},
    ]
    sample_ratio = {"Emp": 20, "Ven": 80}

    allocate_tickets(sample_ticket_info, sample_present, sample_all_people, sample_ratio)

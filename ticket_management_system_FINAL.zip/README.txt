============================================================
  TICKET MANAGEMENT SYSTEM -- Project Guide (v3)
============================================================

-- PROJECT FILES -----------------------------------------

  config.py              -> Change all settings here
  main.py                -> Run the full flow (run this one)

  step1_fetch_tickets.py -> Fetch tickets from API -> save 2 Excel + JSON
  step2_attendance.py    -> Reads TODAY's attendance from sample_roster.xlsx
                             (date-wise columns OR legacy Status column,
                             auto-detected per sheet)
  step3_allocate.py      -> Decides who gets each ticket (see RULES below)
                             ROUND-ROBIN distribution within each role
  step4_post_tickets.py  -> Assigns tickets via API

  guessno.py              -> 4-Digit Guessing Game (bonus, unrelated)

-- NO "SOLVER" CONCEPT ----------------------------------------

  There is NO Solver flag anymore. Whoever is marked Present (P)
  for TODAY is eligible to receive tickets. If that person is
  Absent (A) on any given day, their ticket is reassigned
  (round-robin) to someone else who IS present that day, in the
  same role (Employee/Vendor).

-- SETUP ---------------------------------------------------

  1. Install Python (3.8+)
  2. Install libraries:
       pip install requests pandas openpyxl

  3. Open config.py and set these fields:
       API_URL      -> server address
       API_KEY      -> your API key
       WORKGROUP    -> must match BOTH the API's workgroup name AND
                       a sheet name inside ROSTER_FILE
       ROSTER_FILE  -> "sample_roster.xlsx" (or your own roster file)

-- ROSTER FILE FORMAT (sample_roster.xlsx) ------------------

  ONE SHEET PER WORKGROUP. The sheet name must exactly match the
  workgroup name (e.g. "SAP_MDM - OTH", "SAP_MDM - MM").

  TWO layouts are supported, auto-detected per sheet:

  ── FORMAT A : date-wise columns (one column per calendar day) ──

    Row 1:  (blank)          | Employee | Vendor
    Row 2:  Assignment Ratio |   20     |   80
    Row 3:  (blank row)
    Row 4:  Name | Alignment | email | 01-Jun-26 | 02-Jun-26 | ...
    Row 5+: Rahil | Vendor  | rahil.rathi@kpmg.com | P | P | A | ...

    The system automatically finds TODAY's date column and reads
    that day's P/A. The file is filled in MANUALLY -- each day a
    new date column is added (or the existing column for today is
    filled in) with P/A for every person.

    IMPORTANT: If today's date column does not exist in the sheet,
    the program stops with a clear error telling you to add it.

  ── FORMAT B : legacy single Status column (today only) ──

    Row 1:  (blank)          | Employee | Vendor
    Row 2:  Assignment Ratio |   20     |   80
    Row 3:  (blank row)
    Row 4:  email | Alignment | Status | Name
    Row 5+: person@x.com | Employee | P | First Name

    Status is overwritten manually each morning to reflect "today".

  Column meanings (both formats):
    email      -> the person's email (used for ticket assignment)
    Alignment  -> "Employee" or "Vendor"
    Name       -> used to match a ticket's "Executive Name" field
                  back to this person for reassignment
    P / A      -> Present / Absent for that day

  The Assignment Ratio in row 2 is read LIVE from each sheet, so
  different workgroups can have different splits (the sample file
  has 20/80 for "SAP_MDM - OTH" and 30/70 for "SAP_MDM - MM").

-- HOW TO RUN ------------------------------------------------

  Run the whole system at once:
    python main.py

  Run steps individually:
    python step1_fetch_tickets.py
    python step2_attendance.py
    python step3_allocate.py
    python step4_post_tickets.py

  Game:
    python guessno.py

-- OUTPUT FILES -----------------------------------------------

  tickets_ddmmyy_hhmmss.xlsx           -> Step 1: full API data
  tickets_summary_ddmmyy_hhmmss.xlsx   -> Step 1: Incident ID, Logged Time,
                                          Status, Symptom, Workgroup Name,
                                          Executive Name, FullCategory,
                                          Assigned by Bot
  output.json                           -> Step 1: Raw JSON response
  assignment_result_ddmmyy_hhmmss.xlsx -> Step 4: Ticket_No, Email,
                                          Status_Code, Result,
                                          Assigned by Bot, Time

-- RULES (step3_allocate.py) ------------------------------------

  Ticket Status = "New":
    -> Split between Employees and Vendors using the ratio from
       row 2 of the roster sheet (e.g. 20% Employee / 80% Vendor).
    -> Distributed ROUND-ROBIN (one ticket at a time, cycling
       through that role's Present people) -- not a fixed equal
       block. E.g. with 2 vendors and 3 tickets:
         Ticket 1 -> Vendor A
         Ticket 2 -> Vendor B
         Ticket 3 -> Vendor A
    -> EVERY Present person is eligible (no Solver filter).

  Ticket Status = "Assigned":
    -> If the currently-assigned person (matched by "Executive Name"
       against the roster) is Present TODAY, the ticket stays with
       them.
    -> Otherwise (Absent today), the ticket is reassigned
       ROUND-ROBIN to another Present person in the SAME role
       (Employee stays Employee, Vendor stays Vendor).

  Any other Status:
    -> Skipped and printed as a warning, for manual review.

  The Employee/Vendor split RATIO always comes from row 2 of the
  roster Excel sheet -- nowhere else. There is no fallback ratio in
  config.py; if the ratio cells are missing/invalid the program stops
  with a clear error so it can be fixed in the Excel file.

============================================================

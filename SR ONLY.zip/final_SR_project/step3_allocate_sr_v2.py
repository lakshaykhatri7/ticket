# ============================================================
#  step3_allocate_sr_v2.py
#  SCRIPT 2 - Simplified SR allocation logic.
#
#  Unlike step3_allocate_sr.py (which splits New / Pending /
#  In Progress / Assigned ALL via the Employee/Vendor ratio),
#  this version ONLY touches NEW / unassigned SRs:
#
#    1. If SR is NEW / unassigned -> assign via Employee/Vendor
#       split (using the ratio from the attendance Excel).
#    2. Every other status (Pending, In Progress, Assigned,
#       Resolved, Closed, etc.) is left COMPLETELY untouched -
#       no reassignment, no keep/absent checks, nothing. They
#       are only counted for visibility in the printed summary.
#    3. IDEMPOTENCY RULE: once a New SR has been assigned by the
#       bot in a previous run (tracked in assignment_state_sr.json),
#       it is left COMPLETELY untouched in future runs (not
#       recounted, not reassigned), even if the API still shows
#       it as New (status hasn't updated yet on the source system).
# ============================================================

from config import DEFAULT_EMP_SPLIT
import json
import os

ASSIGNMENT_STATE_FILE = "assignment_state_sr.json"


def _state_file_path(out_dir=""):
    """Returns the full path to assignment_state_sr.json, inside out_dir if provided."""
    if out_dir:
        return os.path.join(out_dir, ASSIGNMENT_STATE_FILE)
    return ASSIGNMENT_STATE_FILE


def _load_assignment_state(out_dir=""):
    """Local idempotency cache: remembers successful SR assignments from previous runs."""
    path = _state_file_path(out_dir)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _state_assignee(sr_no, state):
    item = (state or {}).get(str(sr_no), {})
    if isinstance(item, dict):
        return _clean(item.get("email"))
    return _clean(item)


# NOTE: Confirm the actual key names returned by SR_GetServiceRequestList once you
# have inspected a live response (see output_sr.json from step1_fetch_sr.py) and
# adjust these lists if needed. Kept broad on purpose so common variants match.
SR_ID_KEYS = ["SR ID", "SR_No", "SR No", "ServiceRequestID", "Service Request ID", "SRNo", "ID"]
ASSIGNEE_KEYS = ["Executive Email", "Assigned_Engineer_Email", "Executive Name", "Assigned Engineer", "Assignee", "Owner"]
STATUS_KEYS = ["Status", "SR Status", "Ticket Status"]


def _clean(value):
    return "" if value is None else str(value).strip()


def _norm(value):
    return _clean(value).lower().replace(" ", "")


def _get(sr, keys):
    for key in keys:
        if key in sr and _clean(sr.get(key)):
            return _clean(sr.get(key))
    return ""


def _sr_no(sr):
    return _get(sr, SR_ID_KEYS)


def _assignee(sr):
    return _get(sr, ASSIGNEE_KEYS)


def _status(sr):
    return _get(sr, STATUS_KEYS)


def _status_norm(sr):
    """Normalize SR status for reliable comparisons."""
    return _norm(_status(sr)).replace("-", "")


def _is_in_progress(sr):
    return _status_norm(sr) in {"inprogress", "inprogess"}


def _is_pending(sr):
    status = _status_norm(sr)
    return status == "pending" or status.startswith("pending")


def _is_new_sr(sr, cached_assignee=""):
    """An SR is treated as new (-> assign via split) when EITHER:
      (a) Status is explicitly "New" (primary signal), OR
      (b) there is no assignee in API and no assignee in local state, and the
          status isn't one of the "already handled" states (fallback safety
          net for SRs that have no status or an unexpected status value).

    Do NOT treat Status=Open alone as unassigned/new, since many systems keep
    an SR "Open" even after assignment - only "New" is treated as the new-SR
    signal on its own.
    """
    status = _status_norm(sr)

    if status == "new" or status.startswith("new"):
        return True

    assignee = _assignee(sr) or cached_assignee
    if assignee:
        return False

    if status in {"assigned", "resolved", "closed"}:
        return False

    if status in {"pending", "inprogress", "inprogess"}:
        return False

    return True


def _person_pool(present):
    return {
        "Emp": [p["name"] for p in present.get("Emp", []) if p.get("solver") == "Y"],
        "Ven": [p["name"] for p in present.get("Ven", []) if p.get("solver") == "Y"],
    }


DISTRIBUTION_STATE_FILE = "distribution_state_sr.json"


def _distribution_state_path(out_dir=""):
    if out_dir:
        return os.path.join(out_dir, DISTRIBUTION_STATE_FILE)
    return DISTRIBUTION_STATE_FILE


def _load_distribution_state(out_dir=""):
    """Persistent per-person running assignment counts, used to keep the
    fair-share picker balanced ACROSS runs (not just within one run).
    """
    path = _distribution_state_path(out_dir)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_distribution_state(counts, out_dir=""):
    path = _distribution_state_path(out_dir)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(counts, f, indent=2)
    except Exception as e:
        print(f"  [WARNING] Could not save {DISTRIBUTION_STATE_FILE}: {e}")


def _make_fair_picker(all_candidates, saved_counts=None):
    """One SHARED picker for Emp / Ven / combined fallback pools.

    Tracks ONE running count per person, shared by every pool. Every pick
    goes to whoever (within the eligible subset for that call) currently
    has the fewest total assignments. Ties break by original attendance-list
    order, so results stay deterministic and reproducible.
    """
    counts = {}
    for person in all_candidates:
        key = _norm(person)
        counts[key] = (saved_counts or {}).get(key, 0)

    def pick(pool, exclude=""):
        available = [c for c in pool if _norm(c) != _norm(exclude)]
        if not available:
            return ""
        chosen = min(available, key=lambda c: counts.get(_norm(c), 0))
        counts[_norm(chosen)] = counts.get(_norm(chosen), 0) + 1
        return chosen

    return pick, counts


def allocate_sr_actions(sr_list, present, rows, out_dir=""):
    """
    SCRIPT 2: Only NEW / unassigned SRs are (re)assigned, split via the
    Employee/Vendor ratio from the attendance Excel. Every other status
    is left completely untouched.

    Returns only the SRs that must be posted to the API.

    Output list item:
      {"sr_no": "...", "email": "...", "reason": "..."}
    """

    print("\n" + "=" * 70)
    print("  STEP 3 (v2) : Service Request Decision Logic - NEW ONLY")
    print("=" * 70)

    state = _load_assignment_state(out_dir=out_dir)

    pools = _person_pool(present)
    saved_counts = _load_distribution_state(out_dir=out_dir)
    _pick, _counts = _make_fair_picker(pools["Emp"] + pools["Ven"], saved_counts=saved_counts)

    def pick_emp():
        return _pick(pools["Emp"])

    def pick_ven():
        return _pick(pools["Ven"])

    def pick_any():
        return _pick(pools["Emp"] + pools["Ven"])

    actions = []
    kept = []
    skipped = []

    if sr_list:
        sample = sr_list[0]
        matched_status_key = next((k for k in STATUS_KEYS if k in sample), None)
        matched_assignee_key = next((k for k in ASSIGNEE_KEYS if k in sample), None)
        print(f"\n  [DEBUG] Status field matched   : {matched_status_key!r} (tried {STATUS_KEYS})")
        print(f"  [DEBUG] Assignee field matched : {matched_assignee_key!r} (tried {ASSIGNEE_KEYS})")
        if not matched_status_key or not matched_assignee_key:
            print(f"  [DEBUG] Raw keys available on first SR record: {list(sample.keys())}")

    # ---- Build the NEW pool only. Everything else is just counted. ----
    new_bucket = []
    untouched_counts = {"Pending": 0, "In Progress": 0, "Other": 0}

    for sr in sr_list:
        sno = _sr_no(sr)
        cached = _state_assignee(sno, state) if sno else ""
        already_handled = bool(sno) and str(sno) in state

        if _is_pending(sr):
            untouched_counts["Pending"] += 1
        elif _is_in_progress(sr):
            untouched_counts["In Progress"] += 1
        elif _is_new_sr(sr, cached):
            if already_handled:
                # Already handled by the bot in a previous run - leave untouched.
                continue
            new_bucket.append(sr)
        else:
            untouched_counts["Other"] += 1

    ratio = (rows or {}).get("ratio", {})
    emp_split = ratio.get("Emp", DEFAULT_EMP_SPLIT)
    ven_split = ratio.get("Ven", 1 - emp_split)

    target_emp = round(len(new_bucket) * emp_split)
    emp_done = 0
    ven_done = 0

    print(f"\n  Total fetched SRs       : {len(sr_list)}")
    print(f"  Ratio used from Excel   : Emp {round(emp_split*100)}%, Ven {round(ven_split*100)}%")
    print(f"  Previous bot assignments loaded: {len(state)}")
    print(f"\n  New          count: {len(new_bucket):<4} -> Split target: Emp {target_emp}, Ven {len(new_bucket) - target_emp}")
    print(f"  Pending      count: {untouched_counts['Pending']:<4} -> (untouched by this script)")
    print(f"  In Progress  count: {untouched_counts['In Progress']:<4} -> (untouched by this script)")
    print(f"  Other/Assigned count: {untouched_counts['Other']:<4} -> (untouched by this script)")

    for sr in new_bucket:
        sr_no = _sr_no(sr)
        if not sr_no:
            skipped.append({"sr_no": "", "reason": "SR number missing"})
            continue

        if emp_done < target_emp:
            email = pick_emp() or pick_any()
            emp_done += 1
            role = "Emp"
        else:
            email = pick_ven() or pick_any()
            ven_done += 1
            role = "Ven"

        if email:
            actions.append({
                "sr_no": sr_no,
                "email": email,
                "reason": f"New -> assigned via split ({role})",
                "status": "New",
            })
        else:
            skipped.append({"sr_no": sr_no, "reason": "No present person available for New SR"})

    print(f"\n  -- WILL BE ASSIGNED ---------------")
    if actions:
        for item in actions:
            print(f"  {item['sr_no']:<15} -> {item['email']:<45} {item['reason']}")
    else:
        print("  None")

    if skipped:
        print(f"\n  -- SKIPPED -------------------------------------")
        for item in skipped:
            print(f"  {item['sr_no'] or 'UNKNOWN':<15} {item['reason']}")

    print(f"\n  -- ASSIGNMENT COUNTS THIS RUN (fair-share, persisted) ------")
    for person in pools["Emp"] + pools["Ven"]:
        key = _norm(person)
        print(f"  {person:<45} total so far: {_counts.get(key, 0)}")

    _save_distribution_state(_counts, out_dir=out_dir)

    return actions, kept, skipped


if __name__ == "__main__":
    sample_present = {
        "Emp": [{"name": "rahul@maruti.co.in", "solver": "Y"}],
        "Ven": [{"name": "neha@maruti.co.in", "solver": "Y"}],
    }
    sample_rows = {
        "employee": {"rahul@maruti.co.in": "P", "amit@maruti.co.in": "A"},
        "vendor": {"neha@maruti.co.in": "P"},
    }
    sample_sr_list = [
        {"SR ID": "SR001", "Status": "Assigned", "Executive Name": "rahul@maruti.co.in"},
        {"SR ID": "SR002", "Status": "Assigned", "Executive Name": "amit@maruti.co.in"},
        {"SR ID": "SR003", "Status": "New", "Executive Name": ""},
        {"SR ID": "SR004", "Status": "New", "Executive Name": ""},
        {"SR ID": "SR005", "Status": "Pending", "Executive Name": "amit@maruti.co.in"},
        {"SR ID": "SR006", "Status": "In Progress", "Executive Name": "rahul@maruti.co.in"},
    ]
    allocate_sr_actions(sample_sr_list, sample_present, sample_rows)

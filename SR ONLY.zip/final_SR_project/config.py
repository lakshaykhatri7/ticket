# ============================================================
#  config.py -- All settings in one place
# ============================================================

# --- API Settings ---
API_URL = "http://msilstaging/Webservice/REST/Summit_RESTWCF.svc/RESTService/CommonWS_JsonObjCall"
API_KEY = "sWkL0CqC1bikNDIJvI66eNxPVBMgNTtlSX31d5kZ4OM="
ORG_ID  = 1
INSTANCE = "ITD"

# --- Workgroup & Assignment ---
# This MUST match one sheet name in ATTENDANCE.xlsx, for example:
#   SAP_MDM - OTH
#   SAP_MDM - MM
WORKGROUP       = "SAP_MDM - OTH"
# Blank means fetch all statuses so NEW + Assigned tickets can be checked.
FETCH_STATUS    = ""

# --- Excel / Data File ---
# Attendance file naming convention: "<MonthName> Attendance.xlsx"
# e.g.  "July Attendance.xlsx"  /  "August Attendance.xlsx"
#
# The code automatically picks the file matching the current month.
# You do NOT need to change anything here when you add a new month's file --
# just drop the new file (e.g. "August Attendance.xlsx") in this folder
# and the code will pick it up automatically when August starts.
#
# EXCEL_FILE is no longer set here -- see step2_attendance.py -> _find_attendance_file()

# --- Defaults only if Excel ratio is missing ---
DEFAULT_EMP_SPLIT = 0.30
DEFAULT_VEN_SPLIT = 0.70

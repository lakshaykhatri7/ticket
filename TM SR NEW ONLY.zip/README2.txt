Script 2 — New Tickets Only
========================================================================

Run:
  python main_new_only.py

This is a SEPARATE, standalone project from Script 1 (TM2_SR_project.zip).
It does NOT read or write Script 1's files.

What it does:
  1. Fetches ALL tickets from the API (SR_GetServiceRequestList), saves
     sr_all_raw_*.xlsx (unfiltered, all workgroups).
  2. Filters down to OUR workgroup only (client-side filter) - saves
     sr_*.xlsx (full data, our workgroup) and sr_summary_*.xlsx (only the
     necessary columns, AND only New-status tickets).
  3. Reads attendance from ATTENDANCE.xlsx.
  4. ONLY assigns tickets with Status = "New" to a present person, using
     the Employee/Vendor split ratio from ATTENDANCE.xlsx.
     - Pending, In Progress, Assigned, Resolved, Closed, or any other
       status: COMPLETELY UNTOUCHED. Not even checked for attendance.
       No API call is made for them.
  5. Posts only the New-ticket assignments to the API.

============================================================
ALL OUTPUT FILES GO INTO ONE FOLDER: "Output"
============================================================
Every Excel file, the raw JSON response, the log file (.txt), and the
local state cache (assignment_state_new_only.json) are all saved inside
an "Output" folder created automatically next to the .exe (or next to
the .py files, if run as plain Python) - NOT scattered in the main folder.

Output/
  sr_all_raw_<timestamp>.xlsx        <- everything the API returned (unfiltered)
  sr_<timestamp>.xlsx                <- full data, our workgroup only
  sr_summary_<timestamp>.xlsx        <- necessary columns only, New tickets only
  output_sr.json                     <- raw API JSON response
  new_ticket_result_<timestamp>.xlsx <- result of posting New ticket assignments
  assignment_state_new_only.json     <- local cache to avoid re-posting the same ticket
  <DDMMYYYY_HHMMSS>.txt               <- full console log of that run

This is handled by paths.py - every other script imports get_output_folder()
/ output_path() from it, so the folder logic lives in one place.

Files:
- config.py                    Shared settings (reused from script 1)
- ATTENDANCE.xlsx              Same attendance file
- paths.py                     Decides/creates the shared Output folder
- logger.py                    Tees all print() output into a log file inside Output/
- step1_fetch_sr.py            Fetch + workgroup filter + New-only summary Excel
- step2_attendance.py          Attendance/ratio logic (identical to script 1)
- step3_allocate_new_only.py   NEW-ONLY allocation logic (simplified)
- step4_post_new_only.py       Posts only New ticket assignments
- main_new_only.py              Full flow orchestration (with logging + Output folder)

============================================================
IMPORTANT — SR ASSIGN/UPDATE PAYLOAD STILL BEING VALIDATED
============================================================
step4_post_new_only.py currently sends a best-guess "assign SR" payload
(ServiceName: "SR_LogOrUpdateServiceRequest"). Testing via Postman showed
the API returns HTTP 200 but does not actually update the ticket, and an
"invalid urgency name" error was seen on one attempt - meaning some
required fields (e.g. Urgency) are still missing/incorrect. This is being
iterated on with real Postman testing. Once a fully working payload is
confirmed, step4_post_new_only.py (and step4_post_sr.py in Script 1) will
be updated to match exactly.

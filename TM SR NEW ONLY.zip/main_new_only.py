# ============================================================
#  main_new_only.py -- SCRIPT 2 -- New Tickets Only, Full Flow
#
#  Flow:
#   1. Fetch ALL tickets from API (SR_GetServiceRequestList)
#   2. Filter down to OUR workgroup only (client-side, same as script 1)
#   3. Read attendance from ATTENDANCE.xlsx
#   4. Assign ONLY "New" status tickets to a present person, per the
#      Employee/Vendor split. Everything else (Pending, In Progress,
#      Assigned, Resolved, Closed, etc.) is left completely untouched.
#   5. Post only the New-ticket assignments.
#
#  Run: python main_new_only.py
# ============================================================

from datetime import datetime
from logger import start_logging, stop_logging
from step1_fetch_sr import fetch_service_requests
from step2_attendance import check_attendance
from step3_allocate_new_only import allocate_new_tickets
from step4_post_new_only import post_new_ticket_actions


def main():
    start_logging()  # everything printed from here on is also saved to a DDMMYYYY_HHMMSS.txt log file

    try:
        print("\n" + "*" * 55)
        print("   SCRIPT 2 -- New Tickets Only -- Full Flow")
        print("*" * 55)

        date = datetime.now().strftime("%d-%m-%Y")
        print(f"\n  Using today's date : {date}")

        # STEP 1+2: Fetch all tickets, then filter to our workgroup
        # (this already saves sr_all_raw_*.xlsx + sr_*.xlsx / sr_summary_*.xlsx)
        excel_file, sr_numbers, sr_rows = fetch_service_requests()

        if not sr_rows:
            print("\n[WARNING] No service requests fetched for our workgroup. Stopping program.")
            return

        print(f"\n  Total Service Requests (our workgroup) : {len(sr_rows)}")

        # STEP 3: Attendance (shared logic/file)
        present, absent, rows = check_attendance(date)

        if present is None:
            print("\n[ERROR] Attendance not found. Stopping program.")
            return

        # STEP 4: Only New tickets -> assign via split
        actions, skipped = allocate_new_tickets(sr_rows, present, rows)

        if not actions:
            print("\nNo New tickets need assignment. Nothing to post.")
            return

        confirm = input("\nPost these New ticket assignments via API now? (y/n): ").strip().lower()

        if confirm == "y":
            post_new_ticket_actions(actions)
        else:
            print("\nAPI posting skipped.")

        print("\n" + "*" * 55)
        print("   Done!")
        print("*" * 55)

    finally:
        stop_logging()


if __name__ == "__main__":
    main()

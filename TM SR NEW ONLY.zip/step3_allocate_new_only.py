# ============================================================
#  step3_allocate_new_only.py
#  SCRIPT 2 - simplified allocation logic.
#
#  Unlike script 1 (step3_allocate_sr.py), this script ONLY handles
#  NEW tickets:
#    - Status = "New"  -> assign to a present person, per the
#      Employee / Vendor split ratio from ATTENDANCE.xlsx.
#    - Any other status (Pending, In Progress, Assigned, Resolved,
#      Closed, etc.) -> NOT touched at all, not even checked for
#      attendance. They are simply skipped/left alone.
# ============================================================

from config import DEFAULT_EMP_SPLIT
from paths import output_path
import json
import os

ASSIGNMENT_STATE_FILE = output_path("assignment_state_new_only.json")


def _load_assignment_state():
    """Local idempotency cache so the same New ticket isn't re-posted every
    run if the API's status hasn't flipped from "New" yet.

    Kept in its OWN file (assignment_state_new_only.json), separate from
    script 1's assignment_state_sr.json, so the two never collide.
    """
    if not os.path.exists(ASSIGNMENT_STATE_FILE):
        return {}
    try:
        with open(ASSIGNMENT_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


# NOTE: same field-name guesses as script 1. Confirm against output_sr.json
# and update here if the real API uses different names.
SR_ID_KEYS = ["SR ID", "SR_No", "SR No", "ServiceRequestID", "Service Request ID", "SRNo", "ID"]
ASSIGNEE_KEYS = ["Executive Email", "Assigned_Engineer_Email", "Executive Name", "Assigned Engineer", "Assignee", "Owner"]
STATUS_KEYS = ["Status", "SR Status", "Ticket Status"]


def _clean(value):
    return "" if value is None else str(value).strip()


def _norm(value):
    return _clean(value).lower().replace(" ", "")


def _get(sr, keys):
    for key in keys:
        if key in sr and _clean(sr.get(key)):
            return _clean(sr.get(key))
    return ""


def _sr_no(sr):
    return _get(sr, SR_ID_KEYS)


def _status(sr):
    return _get(sr, STATUS_KEYS)


def _status_norm(sr):
    return _norm(_status(sr)).replace("-", "")


def _is_new(sr):
    """Only Status = "New" (or values like "New Request") counts. Nothing else."""
    status = _status_norm(sr)
    return status == "new" or status.startswith("new")


def _person_pool(present):
    return {
        "Emp": [p["name"] for p in present.get("Emp", []) if p.get("solver") == "Y"],
        "Ven": [p["name"] for p in present.get("Ven", []) if p.get("solver") == "Y"],
    }


def _make_round_robin_selector(candidates):
    state = {"i": 0}

    def pick(exclude=""):
        available = [c for c in candidates if _norm(c) != _norm(exclude)]
        if not available:
            return ""
        chosen = available[state["i"] % len(available)]
        state["i"] += 1
        return chosen

    return pick


def allocate_new_tickets(sr_list, present, rows):
    """
    ONLY processes SRs with Status = "New". Everything else is skipped
    untouched (no attendance check, no reassignment, no API call).

    Returns:
      actions -> list of {"sr_no", "email", "reason"} for New tickets to post
      skipped -> list of {"sr_no", "reason"} - includes both non-New tickets
                 (informational only) and New tickets that couldn't be
                 assigned (e.g. no one present)
    """

    print("\n" + "=" * 70)
    print("  STEP 3 (Script 2) : New-Ticket-Only Allocation Logic")
    print("=" * 70)

    state = _load_assignment_state()

    pools = _person_pool(present)
    pick_emp = _make_round_robin_selector(pools["Emp"])
    pick_ven = _make_round_robin_selector(pools["Ven"])
    pick_any = _make_round_robin_selector(pools["Emp"] + pools["Ven"])

    # ---- DEBUG: confirm field names are matching the real API response ----
    if sr_list:
        sample = sr_list[0]
        matched_status_key = next((k for k in STATUS_KEYS if k in sample), None)
        print(f"\n  [DEBUG] Status field matched : {matched_status_key!r} (tried {STATUS_KEYS})")
        if not matched_status_key:
            print(f"  [DEBUG] Raw keys available on first SR record: {list(sample.keys())}")
        raw_statuses = sorted({_clean(sr.get(matched_status_key, "")) or "(blank)" for sr in sr_list}) if matched_status_key else []
        print(f"  [DEBUG] Distinct raw status values seen : {raw_statuses}")

    new_srs = [sr for sr in sr_list if _is_new(sr)]
    not_new_count = len(sr_list) - len(new_srs)

    ratio = (rows or {}).get("ratio", {})
    emp_split = ratio.get("Emp", DEFAULT_EMP_SPLIT)
    ven_split = ratio.get("Ven", 1 - emp_split)
    emp_target = round(len(new_srs) * emp_split)
    emp_done = 0
    ven_done = 0

    print(f"\n  Total fetched SRs (our workgroup) : {len(sr_list)}")
    print(f"  New tickets                        : {len(new_srs)}")
    print(f"  Ignored (not New - untouched)      : {not_new_count}")
    print(f"  Ratio used from Excel              : Emp {round(emp_split*100)}%, Ven {round(ven_split*100)}%")
    print(f"  Split target for New tickets       : Emp {emp_target}, Ven {len(new_srs) - emp_target}")

    actions = []
    skipped = []

    for sr in sr_list:
        sr_no = _sr_no(sr)

        if not _is_new(sr):
            # Not a New ticket -> completely untouched, just informational.
            continue

        if not sr_no:
            skipped.append({"sr_no": "", "reason": "SR number missing on a New ticket"})
            continue

        if str(sr_no) in state:
            skipped.append({"sr_no": sr_no, "reason": "Already assigned by this bot in a previous run (cached)"})
            continue

        if emp_done < emp_target:
            email = pick_emp() or pick_any()
            emp_done += 1
            role = "Emp"
        else:
            email = pick_ven() or pick_any()
            ven_done += 1
            role = "Ven"

        if email:
            actions.append({"sr_no": sr_no, "email": email, "reason": f"New ticket -> {role}"})
        else:
            skipped.append({"sr_no": sr_no, "reason": "No present person available for this New ticket"})

    print(f"\n  -- NEW TICKETS TO BE ASSIGNED ------------------")
    if actions:
        for item in actions:
            print(f"  {item['sr_no']:<15} -> {item['email']:<45} {item['reason']}")
    else:
        print("  None")

    if skipped:
        print(f"\n  -- SKIPPED (New but could not assign) ----------")
        for item in skipped:
            print(f"  {item['sr_no'] or 'UNKNOWN':<15} {item['reason']}")

    return actions, skipped


if __name__ == "__main__":
    sample_present = {
        "Emp": [{"name": "rahul@maruti.co.in", "solver": "Y"}],
        "Ven": [{"name": "neha@maruti.co.in", "solver": "Y"}],
    }
    sample_rows = {
        "employee": {"rahul@maruti.co.in": "P", "amit@maruti.co.in": "A"},
        "vendor": {"neha@maruti.co.in": "P"},
    }
    sample_sr_list = [
        {"SR ID": "SR001", "Status": "Assigned", "Executive Name": "rahul@maruti.co.in"},
        {"SR ID": "SR002", "Status": "Pending", "Executive Name": "amit@maruti.co.in"},
        {"SR ID": "SR003", "Status": "New", "Executive Name": ""},
        {"SR ID": "SR004", "Status": "New", "Executive Name": ""},
        {"SR ID": "SR005", "Status": "In Progress", "Executive Name": "rahul@maruti.co.in"},
    ]
    allocate_new_tickets(sample_sr_list, sample_present, sample_rows)

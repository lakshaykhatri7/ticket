# ============================================================
#  paths.py
#  Shared helper - decides WHERE all output files go, so every
#  Excel file, the raw JSON, and the log file all land in ONE
#  single folder, instead of being scattered in the same folder
#  as the .exe.
#
#  Output folder location : <exe_folder>/Output
#  (created automatically the first time it's needed)
#
#  USAGE (from any script that saves a file):
#
#      from paths import get_output_folder, output_path
#      folder = get_output_folder()                 # just the folder path
#      file_path = output_path("sr_summary.xlsx")    # folder + filename, ready to use
# ============================================================

import os
import sys

_OUTPUT_FOLDER_NAME = "Output"


def _app_folder():
    """
    Returns the folder the .exe (or .py script) is running from.

    - When bundled as a PyInstaller .exe, sys.executable points at the
      .exe itself, so Output/ is created right next to it.
    - When run as a plain .py file, falls back to this script's folder.
    """
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def get_output_folder():
    """Returns the full path to the Output folder, creating it if needed."""
    folder = os.path.join(_app_folder(), _OUTPUT_FOLDER_NAME)
    os.makedirs(folder, exist_ok=True)
    return folder


def output_path(filename):
    """Convenience: returns Output/<filename>, creating the Output folder if needed."""
    return os.path.join(get_output_folder(), filename)


# ---- Standalone test ----
if __name__ == "__main__":
    folder = get_output_folder()
    print(f"Output folder : {folder}")
    print(f"Example path  : {output_path('sr_summary_test.xlsx')}")

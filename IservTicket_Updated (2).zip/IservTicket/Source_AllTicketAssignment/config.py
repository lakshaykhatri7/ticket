# ============================================================
#  config.py -- All settings in one place
# ============================================================
import os
import sys

# --- Read settings from shared Excel file (api_config.xlsx) ---
# The Excel file must sit in the SAME FOLDER as this exe (or script).
# Sheet: "Config", Column A = Key, Column B = Value
#   API_URL      | http://...
#   API_KEY      | xxxxx
#   SMTP_HOST    | mail.yourcompany.com
#   SMTP_PORT    | 25
#   SMTP_USERNAME| (leave blank if server needs no login)
#   SMTP_PASSWORD| (leave blank if server needs no login)
#   FROM_EMAIL   | reports@yourcompany.com
#   TO_EMAIL     | person1@x.com, person2@x.com
#   CC_EMAIL     | person3@x.com
#   BCC_EMAIL    | person4@x.com
#
# API_URL / API_KEY are REQUIRED -- missing/blank stops the program with
# an error popup.
#
# Email settings are OPTIONAL -- if SMTP_HOST or TO_EMAIL is blank, the
# ticket-fetch/assign/post work still runs normally, the email step is
# just skipped with a warning printed (no popup, no crash).


def _get_base_dir():
    """Folder the exe (or script) is running from."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def _fail(message):
    """Show the error clearly (console + popup) and stop the program."""
    full_message = (
        "CONFIG ERROR\n"
        "============\n"
        f"{message}\n\n"
        "Fix api_config.xlsx and run the tool again."
    )
    print(full_message, file=sys.stderr)
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Config Error", full_message)
        root.destroy()
    except Exception:
        pass
    sys.exit(1)


def _load_all_settings():
    base_dir = _get_base_dir()
    excel_path = os.path.join(base_dir, "api_config.xlsx")

    if not os.path.isfile(excel_path):
        _fail(f"api_config.xlsx was not found in:\n{base_dir}")

    try:
        from openpyxl import load_workbook
        wb = load_workbook(excel_path, data_only=True)
    except Exception as e:
        _fail(f"api_config.xlsx could not be read/opened.\nDetails: {e}")

    ws = wb["Config"] if "Config" in wb.sheetnames else wb.active
    values = {}
    for row in ws.iter_rows(min_row=2, max_col=2, values_only=True):
        if not row or row[0] is None:
            continue
        key = str(row[0]).strip()
        val = "" if row[1] is None else str(row[1]).strip()
        values[key] = val

    # ---- Required: API ----
    api_url = values.get("API_URL", "").strip()
    api_key = values.get("API_KEY", "").strip()
    missing = [n for n, v in (("API_URL", api_url), ("API_KEY", api_key)) if not v]
    if missing:
        _fail(
            "api_config.xlsx is missing a value for: " + ", ".join(missing) +
            "\nMake sure the 'Config' sheet has API_URL and API_KEY filled in column B."
        )

    # ---- Optional: Auto Posting ----
    auto_posting_raw = values.get("AUTO POSTING STATUS", values.get("AUTO_POSTING_STATUS", "")).strip()
    AUTO_POSTING = auto_posting_raw.upper() == "Y"

    # ---- Optional: Email ----
    smtp_host      = values.get("SMTP_HOST", "").strip()
    smtp_port_raw  = values.get("SMTP_PORT", "").strip()
    smtp_username  = values.get("SMTP_USERNAME", "").strip()
    smtp_password  = values.get("SMTP_PASSWORD", "").strip()
    from_email     = values.get("FROM_EMAIL", "").strip()
    to_email_raw   = values.get("TO_EMAIL", "").strip()
    cc_email_raw   = values.get("CC_EMAIL", "").strip()
    bcc_email_raw  = values.get("BCC_EMAIL", "").strip()

    try:
        smtp_port = int(smtp_port_raw) if smtp_port_raw else 25
    except ValueError:
        print(f"  [WARNING] SMTP_PORT '{smtp_port_raw}' is not a number, using 25 instead.")
        smtp_port = 25

    def _split_emails(raw):
        return [e.strip() for e in raw.split(",") if e.strip()]

    email_settings = {
        "SMTP_HOST": smtp_host,
        "SMTP_PORT": smtp_port,
        "SMTP_USERNAME": smtp_username,
        "SMTP_PASSWORD": smtp_password,
        "FROM_EMAIL": from_email,
        "TO_EMAIL": _split_emails(to_email_raw),
        "CC_EMAIL": _split_emails(cc_email_raw),
        "BCC_EMAIL": _split_emails(bcc_email_raw),
    }

    return api_url, api_key, email_settings, AUTO_POSTING


API_URL, API_KEY, EMAIL_SETTINGS, AUTO_POSTING = _load_all_settings()
ORG_ID  = 1
INSTANCE = "ITD"

# --- Workgroup & Assignment ---
# This MUST match one sheet name in ATTENDANCE.xlsx, for example:
#   SAP_MDM - OTH
#   SAP_MDM - MM
WORKGROUP       = "SAP_MDM - OTH"
# Blank means fetch all statuses so NEW + Assigned tickets can be checked.
FETCH_STATUS    = ""

# --- Excel / Data File ---
# Attendance file naming convention: "<MonthName> Attendance.xlsx"
# e.g.  "July Attendance.xlsx"  /  "August Attendance.xlsx"
#
# The code automatically picks the file matching the current month.
# You do NOT need to change anything here when you add a new month's file --
# just drop the new file (e.g. "August Attendance.xlsx") in this folder
# and the code will pick it up automatically when August starts.
#
# EXCEL_FILE is no longer set here -- see step2_attendance.py -> _find_attendance_file()

# --- Defaults only if Excel ratio is missing ---
DEFAULT_EMP_SPLIT = 0.30
DEFAULT_VEN_SPLIT = 0.70

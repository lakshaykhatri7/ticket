# ============================================================
#  main_sr.py -- Service Request Management -- Full Auto Flow
#
#  Folder structure (inside AutomaticIservTicketing/):
#
#    Input/
#      Monthly Attendence/    <- attendance files go here
#      Extracted Details/     <- all Excel + JSON files saved here
#                                (one subfolder per run: DDMMYYYY_HHMMSS)
#    Output/                  <- final report Excel saved here
#
#  Logic:
#   1. Fetch service requests from API (SR_GetServiceRequestList)
#   1b. Split fetched tickets into 4 Excel files by status
#   2. Read attendance from Input/Monthly Attendence/
#   3. New / Pending / In Progress SRs -> split via Employee/Vendor ratio
#   4. Already-Assigned SRs:
#        - assignee present -> remain as-is
#        - assignee absent  -> reassign to a present person
#   5. Post only SRs that need assignment/reassignment
#   6. Create final summary report -> saved to Output/
#
#  Run: python main_sr.py
# ============================================================

import os
from datetime import datetime
from logger import start_logging, stop_logging
from step1_fetch_sr import fetch_service_requests
from step1b_split_by_status import split_tickets_by_status
from step2_attendance import check_attendance
from step3_allocate_sr import allocate_sr_actions
from step4_post_sr import post_sr_actions
from step5_report_sr import create_sr_assignment_report
from step6_email_report import send_report_email
from config import AUTO_POSTING


def _make_folders():
    timestamp = datetime.now().strftime("%d%m%Y_%H%M%S")

    import sys
    if getattr(sys, "frozen", False):
        # Running as a .exe (PyInstaller) -- use the folder where the .exe sits,
        # NOT sys.executable's temp extraction folder (__file__ would point there
        # and get deleted when the exe closes, silently losing all output).
        base = os.path.dirname(os.path.abspath(sys.executable))
    else:
        base = os.path.dirname(os.path.abspath(__file__))

    ait  = os.path.join(base, "AutomaticIservTicketing")

    date_folder = datetime.now().strftime("%d%m%Y")

    extracted_dir = os.path.join(ait, "Input", "Extracted Details", "All Tickets", date_folder, timestamp)
    report_dir    = os.path.join(ait, "Output", "All Tickets", date_folder)

    os.makedirs(extracted_dir, exist_ok=True)
    os.makedirs(report_dir,    exist_ok=True)

    return extracted_dir, report_dir


def main():
    extracted_dir, report_dir = _make_folders()

    # Log file goes into Extracted Details run folder
    start_logging(out_dir=extracted_dir)

    try:
        print("\n" + "*" * 55)
        print("   SERVICE REQUEST MANAGEMENT SYSTEM -- Full Auto Flow")
        print("*" * 55)
        print(f"\n  Extracted Details : {extracted_dir}")
        print(f"  Report Output     : {report_dir}")

        date = datetime.now().strftime("%d-%m-%Y")
        print(f"  Using today's date : {date}")

        # STEP 1: Fetch service requests -> Excel + JSON -> Extracted Details
        excel_file, sr_numbers, sr_rows = fetch_service_requests(out_dir=extracted_dir)

        if not sr_rows:
            print("\n[WARNING] No service requests fetched. Stopping program.")
            return

        print(f"\n  Total Service Requests (auto-detected) : {len(sr_rows)}")

        # STEP 1b: Split into 4 status-wise Excel files -> Extracted Details
        split_tickets_by_status(sr_rows, out_dir=extracted_dir)

        # STEP 2: Attendance
        present, absent, rows = check_attendance(date)

        if present is None:
            print("\n[ERROR] Attendance not found. Stopping program.")
            return

        # STEP 3: Allocation logic
        actions, kept, skipped = allocate_sr_actions(
            sr_rows, present, rows, out_dir=extracted_dir
        )

        post_results = []

        # STEP 4: Post only required SRs
        if not actions:
            print("\nNo SR needs assignment/reassignment. Nothing to post.")
        else:
            if AUTO_POSTING:
                print("\nAUTO POSTING STATUS = Y -> posting SR updates via API automatically (no confirmation).")
                post_results = post_sr_actions(actions, out_dir=extracted_dir)
            else:
                confirm = input("\nPost only these required SR updates via API now? (y/n): ").strip().lower()

                if confirm == "y":
                    post_results = post_sr_actions(actions, out_dir=extracted_dir)
                else:
                    print("\nAPI posting skipped.")

        # STEP 5: Final report -> Output/
        report_file = create_sr_assignment_report(
            sr_rows, actions, kept, skipped, rows, post_results,
            out_dir=report_dir
        )

        # STEP 6: Email the report automatically (no prompt)
        send_report_email(report_file)

        print("\n" + "*" * 55)
        print("   Done!")
        print(f"   Excel/JSON files : {extracted_dir}")
        print(f"   Report           : {report_dir}")
        print("*" * 55)

    finally:
        stop_logging()


if __name__ == "__main__":
    main()

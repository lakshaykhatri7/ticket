# ============================================================
#  step2_attendance.py
#  Reads attendance from ATTENDANCE.xlsx -- 2 sheets:
#    "employee" -> Date | <employee email columns, P/A>
#    "vendor"   -> Date | <vendor email columns, P/A>
#
#  NOTE: The "Solver/Not" column no longer exists. Everyone who
#  is Present is treated as a solver (everyone present gets
#  tickets) -- this decision was confirmed with the user.
# ============================================================

import pandas as pd
from datetime import datetime
from config import EXCEL_FILE


def _read_sheet_status(date, sheet_name):
    """
    Reads one sheet (employee/vendor), finds the row for the given date,
    and returns a dict of each person's P/A status.
    Returns None if the date, sheet, or file is not found.
    """
    try:
        df = pd.read_excel(EXCEL_FILE, sheet_name=sheet_name)
    except FileNotFoundError:
        print(f"  [ERROR] File not found: {EXCEL_FILE}")
        return None
    except ValueError:
        print(f"  [ERROR] Sheet '{sheet_name}' not found in {EXCEL_FILE}.")
        return None

    df.columns = df.columns.str.strip()
    df["Date"] = pd.to_datetime(df["Date"]).dt.strftime("%d-%m-%Y")

    row = df[df["Date"] == date]
    if row.empty:
        return None

    row = row.iloc[0]
    person_cols = [c for c in df.columns if c != "Date"]

    return {name: str(row[name]).strip().upper() for name in person_cols}


def check_attendance(date):
    """
    Checks attendance for the given date (employee + vendor sheets).

    Returns:
        present (dict) : { "Emp": [{name, solver}], "Ven": [...] }
        absent  (dict) : { "Emp": [name,...],        "Ven": [...] }
        rows    (dict or None) : { "employee": {...}, "vendor": {...} } raw status
    """

    print("\n" + "="*55)
    print("  STEP 2 : Attendance Check  (ATTENDANCE.xlsx)")
    print("="*55)

    emp_status = _read_sheet_status(date, "employee")
    ven_status = _read_sheet_status(date, "vendor")

    if emp_status is None and ven_status is None:
        print(f"  [ERROR] Date '{date}' not found in either sheet (employee/vendor).")
        return None, None, None

    present = {"Emp": [], "Ven": []}
    absent  = {"Emp": [], "Ven": []}

    # ---- Table Header ----
    print(f"\n  Date : {date}\n")
    print(f"  {'Email':<35} {'Type':<6} Status")
    print(f"  {'-'*55}")

    for role, statuses in [("Emp", emp_status), ("Ven", ven_status)]:
        if not statuses:
            continue
        for name, status in statuses.items():
            if status == "P":
                # No Solver/Not column -- present = solver
                present[role].append({"name": name, "solver": "Y"})
                icon = "Present"
            else:
                absent[role].append(name)
                icon = "Absent "
            print(f"  {name:<35} {role:<6} {icon}")

    # ---- Summary ----
    print(f"\n  -- SUMMARY ------------------------------------")
    print(f"  Present Employees : {[p['name'] for p in present['Emp']] or 'None'}")
    print(f"  Present Vendors   : {[p['name'] for p in present['Ven']] or 'None'}")
    print(f"  Absent Employees  : {absent['Emp'] or 'None'}")
    print(f"  Absent Vendors    : {absent['Ven'] or 'None'}")

    return present, absent, {"employee": emp_status, "vendor": ven_status}


# ---- Standalone run ----
if __name__ == "__main__":
    # Manual date input removed -- automatically uses today's date
    date = datetime.now().strftime("%d-%m-%Y")
    print(f"  Using today's date : {date}")
    present, absent, row = check_attendance(date)

============================================================
  TICKET MANAGEMENT SYSTEM -- Project Guide
============================================================

-- PROJECT FILES -----------------------------------------

  config.py              -> Change all settings here
  main.py                -> Run the full flow (run this one)

  step1_fetch_tickets.py -> Fetch tickets from API -> save 2 Excel + JSON
  step2_attendance.py    -> Present / Absent from ATTENDANCE.xlsx
  step3_allocate.py      -> 30-70 split, only present people get tickets
  step4_post_tickets.py  -> Assign tickets via API

  guessno.py              -> 4-Digit Guessing Game (bonus!)

-- SETUP ---------------------------------------------------

  1. Install Python (3.8+)
  2. Install libraries:
       pip install requests pandas openpyxl

  3. Open config.py and set these fields:
       API_URL       -> server address
       API_KEY       -> your API key
       EXCEL_FILE    -> "ATTENDANCE.xlsx"
       TOTAL_TICKETS -> fallback only for standalone step3 testing
                        (main.py flow does not use this -- total
                        tickets there is auto-detected from the
                        count returned by the API)
       EMP_SPLIT     -> 0.30 (Employee 30% | Vendor 70%)

-- ATTENDANCE FILE FORMAT (ATTENDANCE.xlsx) ----------------

  Must have 2 sheets:

    Sheet "employee":
      Date       | Excel date format
      <Email1>   | P (Present) or A (Absent)
      <Email2>   | P or A
      ... (one column per employee email)

    Sheet "vendor":
      Date       | Excel date format
      <Email1>   | P or A
      <Email2>   | P or A
      ... (one column per vendor email)

  NOTE: The Solver/Not column no longer exists. Anyone who is
  Present is treated as a solver -- everyone present gets tickets.

-- HOW TO RUN ------------------------------------------------

  Run the whole system at once:
    python main.py

  Run steps individually:
    python step1_fetch_tickets.py
    python step2_attendance.py
    python step3_allocate.py
    python step4_post_tickets.py

  Game:
    python guessno.py

  NOTE: You do not need to enter the date manually -- main.py
  and standalone step2_attendance.py both automatically use
  today's date (system date).

-- OUTPUT FILES -----------------------------------------------

  tickets_ddmmyy_hhmmss.xlsx           -> Step 1: full API data
  tickets_summary_ddmmyy_hhmmss.xlsx   -> Step 1: Incident ID, Logged Time,
                                          Status, Symptom, Workgroup Name,
                                          Executive Name, FullCategory,
                                          Assigned by Bot
  output.json                           -> Step 1: Raw JSON response
  assignment_result_ddmmyy_hhmmss.xlsx -> Step 4: Ticket_No, Email,
                                          Status_Code, Result,
                                          Assigned by Bot, Time

-- RULES --------------------------------------------------------

  - Employees  -> 30% of tickets
  - Vendors    -> 70% of tickets
  - Only Present people get tickets (everyone present is a solver)
  - Remaining tickets are distributed equally
  - Every output Excel has an "Assigned by Bot" column

============================================================

# ============================================================
#  config.py -- All settings in one place
#  Only change things here, leave the other files alone
# ============================================================

# --- API Settings ---
API_URL = "http://msilstaging/Webservice/REST/Summit_RESTWCF.svc/RESTService/CommonWS_JsonObjCall"
API_KEY = "sWkL0CqC1bikNDIJvI66eNxPVBMgNTtlSX31d5kZ4OM="
ORG_ID  = 1
INSTANCE = "ITD"

# --- Workgroup & Assignment ---
WORKGROUP       = "SAP_MDM - OTH"
# NOTE: Fixed ASSIGNED_EMAIL removed -- each ticket allocation now
# sets "Assigned_Engineer_Email" directly from the ATTENDANCE.xlsx
# column headers (which are now email IDs) in step4_post_tickets.py.

# --- Excel / Data File ---
# ATTENDANCE.xlsx has 2 sheets: "employee" and "vendor"
EXCEL_FILE = "ATTENDANCE.xlsx"

# --- Ticket Split ---
TOTAL_TICKETS = 16
EMP_SPLIT     = 0.30   # 30% employees, 70% vendors

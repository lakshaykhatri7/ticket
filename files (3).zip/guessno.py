# ============================================================
#  guessno.py — 4-Digit Number Guessing Game
#  Computer ek secret 4-digit code banata hai
#  Tum guess karo, hint milega kaun se digits sahi hain
# ============================================================

import random


def play_game():
    # ---- Secret code generate karo ----
    secret_code = str(random.randint(1000, 9999))

    print("\n" + "★"*40)
    print("   🔐 4-Digit Number Guessing Game")
    print("   Secret 4-digit code guess karo!")
    print("★"*40)

    attempts = 0

    while True:
        guess = input("\nEnter a 4-digit number: ").strip()

        # ---- Validation ----
        if len(guess) != 4 or not guess.isdigit():
            print("❌ Please enter exactly 4 digits.")
            continue

        attempts += 1

        # ---- Win condition ----
        if guess == secret_code:
            print(f"\n🎉 Sahi jawab! Code tha : {secret_code}")
            print(f"   Total Attempts : {attempts}")
            break

        # ---- Hint: kaun se digits sahi hain ----
        correct_digits = [d for d in set(guess) if d in secret_code]

        if correct_digits:
            print(f"✅ Sahi digit(s) hain : {', '.join(correct_digits)}")
        else:
            print("❌ Koi bhi digit sahi nahi.")

        print(f"   (Attempts so far: {attempts})")

    # ---- Play again? ----
    again = input("\nDobara khelna hai? (y/n): ").strip().lower()
    if again == "y":
        play_game()
    else:
        print("\nGame khatam. Goodbye! 👋")


if __name__ == "__main__":
    play_game()

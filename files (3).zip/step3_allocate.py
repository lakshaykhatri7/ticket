# ============================================================
#  step3_allocate.py
#  Gives tickets to Present + Solver people in a 30-70 split
#
#  Rule:
#    Employees  -> 30% of total tickets
#    Vendors    -> 70% of total tickets
#    Only Solver=Y people get tickets
#    Remaining tickets are distributed equally
# ============================================================

from config import TOTAL_TICKETS, EMP_SPLIT


def allocate_tickets(present, total_tickets=None):
    """
    Allocates tickets.

    Args:
        present (dict): from step2, {Emp:[{name,solver}], Ven:[...]}
        total_tickets (int): override, or taken from config

    Returns:
        allocation (dict): { person_email : ticket_count }
    """

    if total_tickets is None:
        total_tickets = TOTAL_TICKETS

    emp_total = round(total_tickets * EMP_SPLIT)
    ven_total = total_tickets - emp_total

    print("\n" + "="*55)
    print("  STEP 3 : Ticket Allocation  (Emp 30% | Ven 70%)")
    print("="*55)
    print(f"\n  Total Tickets    : {total_tickets}")
    print(f"  Employee Share   : {emp_total}  (30%)")
    print(f"  Vendor Share     : {ven_total}  (70%)")

    allocation = {}   # { email : ticket_count }

    for role, share in [("Emp", emp_total), ("Ven", ven_total)]:

        # Only Solver=Y and Present people
        solvers = [p["name"] for p in present[role] if p["solver"] == "Y"]

        print(f"\n  -- {role} ({'Employees' if role=='Emp' else 'Vendors'}) -----------------")
        print(f"  Share : {share} tickets")

        if not solvers:
            print(f"  [WARNING] No solver present -- tickets skipped.")
            continue

        print(f"  Solvers Present : {solvers}")
        print()

        for i, name in enumerate(solvers):
            # Equal split + remainder goes to the first few, one at a time
            t = share // len(solvers) + (1 if i < share % len(solvers) else 0)
            allocation[name] = t
            print(f"  {name:<35} -> {t:>3} tickets")

    print(f"\n  -- FINAL ALLOCATION ----------------------------")
    for name, count in allocation.items():
        print(f"  {name:<35} : {count} tickets")

    return allocation


# ---- Standalone run ----
if __name__ == "__main__":
    # Test data
    sample_present = {
        "Emp": [{"name": "jyoti@maruti.co.in",    "solver": "Y"},
                {"name": "aarushi@maruti.co.in",  "solver": "N"}],
        "Ven": [{"name": "akshita@maruti.co.in",  "solver": "Y"},
                {"name": "robin@maruti.co.in",    "solver": "Y"}]
    }
    allocate_tickets(sample_present)

# ============================================================
#  step3_allocate.py
#  Splits tickets 30-70 among present + solver people
#
#  Rule:
#    Employees  -> 30% of total tickets
#    Vendors    -> 70% of total tickets
#    Only Present people get tickets (everyone present = solver)
#    Remaining tickets are split equally
# ============================================================

from config import TOTAL_TICKETS, EMP_SPLIT


def allocate_tickets(present, total_tickets=None):
    """
    Allocates tickets.

    Args:
        present (dict): from step2 -> {Emp:[{email,solver}], Ven:[...]}
        total_tickets (int): override, otherwise taken from config

    Returns:
        allocation (dict): { email : ticket_count }
    """

    if total_tickets is None:
        total_tickets = TOTAL_TICKETS

    emp_total = round(total_tickets * EMP_SPLIT)
    ven_total = total_tickets - emp_total

    print("\n" + "="*55)
    print("  STEP 3 : Ticket Allocation  (Emp 30% | Ven 70%)")
    print("="*55)
    print(f"\n  Total Tickets    : {total_tickets}")
    print(f"  Employee Share   : {emp_total}  (30%)")
    print(f"  Vendor Share     : {ven_total}  (70%)")

    allocation = {}   # { email : ticket_count }

    for role, share in [("Emp", emp_total), ("Ven", ven_total)]:

        # Only present solvers (everyone present counts)
        solvers = [p["email"] for p in present[role] if p["solver"] == "Y"]

        print(f"\n  -- {role} ({'Employees' if role=='Emp' else 'Vendors'}) --------------------")
        print(f"  Share : {share} tickets")

        if not solvers:
            print(f"  No solver present -- skipping these tickets.")
            continue

        print(f"  Solvers Present : {solvers}")
        print()

        for i, email in enumerate(solvers):
            # Equal split + remainder goes to the first ones, one by one
            t = share // len(solvers) + (1 if i < share % len(solvers) else 0)
            allocation[email] = t
            print(f"  {email:<38} -> {t:>3} tickets")

    print(f"\n  -- FINAL ALLOCATION --------------------------")
    for email, count in allocation.items():
        print(f"  {email:<38} : {count} tickets")

    return allocation


# ---- Standalone run ----
if __name__ == "__main__":
    # Test data
    sample_present = {
        "Emp": [{"email": "vaibhav.agarwal@maruti.co.in", "solver": "Y"},
                {"email": "akshita.bhandari@maruti.co.in", "solver": "Y"}],
        "Ven": [{"email": "jktech_neha.aswal@maruti.co.in", "solver": "Y"},
                {"email": "dtl_ayushkumar.choubey@maruti.co.in", "solver": "Y"}]
    }
    allocate_tickets(sample_present)

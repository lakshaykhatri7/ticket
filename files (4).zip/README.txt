============================================================
  TICKET MANAGEMENT SYSTEM - Project Guide
============================================================

-- PROJECT FILES ------------------------------------------

  config.py              -> Change all settings here
  main.py                -> Runs the full flow (run this one)

  step1_fetch_tickets.py -> Fetches tickets from API -> saves 2 Excel + JSON
  step2_attendance.py    -> Present / Absent from ATTENDANCE.xlsx
  step3_allocate.py      -> 30-70 split, tickets only to present people
  step4_post_tickets.py  -> Assigns tickets via API (by email)

  guessno.py              -> 4-Digit Guessing Game (bonus!)

-- SETUP ----------------------------------------------------

  1. Install Python (3.8+)
  2. Install libraries:
       pip install requests pandas openpyxl

  3. Open config.py and set:
       API_URL       -> server address
       API_KEY       -> your API key
       EXCEL_FILE    -> "ATTENDANCE.xlsx"
       TOTAL_TICKETS -> only used as a fallback for standalone step3
                         testing (the main.py flow auto-detects total
                         tickets from how many the API actually returned)
       EMP_SPLIT     -> 0.30 (Employee 30% | Vendor 70%)

  NOTE: There is no fixed "ASSIGNED_EMAIL" setting anymore. Each
  ticket is assigned to the actual email of the person it was
  allocated to (taken directly from ATTENDANCE.xlsx column headers).

-- ATTENDANCE FILE FORMAT (ATTENDANCE.xlsx) -----------------

  Must have 2 sheets:

    Sheet "employee":
      Date           | Excel date format
      <email1>       | P (Present) or A (Absent)
      <email2>       | P or A
      ... (one column per employee, header = their email)

    Sheet "vendor":
      Date           | Excel date format
      <email1>       | P or A
      <email2>       | P or A
      ... (one column per vendor, header = their email)

  Column headers must be the person's actual, complete email
  address (e.g. name.surname@maruti.co.in) -- this is what gets
  sent to the API as "Assigned_Engineer_Email" when a ticket is
  posted, so a typo or incomplete email will cause that person's
  assignment to fail.

  NOTE: There is no "Solver/Not" column anymore. Anyone marked
  Present is treated as a solver -- everyone present gets tickets.

-- HOW TO RUN -------------------------------------------------

  Run the whole system at once:
    python main.py

  Run steps individually:
    python step1_fetch_tickets.py
    python step2_attendance.py
    python step3_allocate.py
    python step4_post_tickets.py

  Game:
    python guessno.py

  NOTE: No date needs to be typed in -- main.py and standalone
  step2_attendance.py both automatically use today's system date.

-- OUTPUT FILES -----------------------------------------------

  tickets_ddmmyy_hhmmss.xlsx           -> Step 1: full API data
  tickets_summary_ddmmyy_hhmmss.xlsx   -> Step 1: Incident ID, Logged Time,
                                          Status, Symptom, Workgroup Name,
                                          Executive Name, FullCategory,
                                          Assigned by Bot
  output.json                           -> Step 1: raw JSON response
  assignment_result_ddmmyy_hhmmss.xlsx -> Step 4: Ticket_No, Email,
                                          Status_Code, Result,
                                          Assigned by Bot, Time

-- RULES --------------------------------------------------------

  - Employees -> 30% of tickets
  - Vendors   -> 70% of tickets
  - Only people marked Present get tickets (everyone present = solver)
  - Remaining tickets are split equally among present people
  - Every output Excel includes an "Assigned by Bot" column
  - All terminal output is in English

============================================================

# ============================================================
#  step4_post_tickets.py
#  Assigns allocated tickets via API to each person's email
#  (Assigned_Engineer_Email is taken from the ATTENDANCE.xlsx
#   column header for each person -- no fixed config email is used)
#  Every result is shown in both the terminal and Excel.
#  Output: assignment_result_ddmmyy_hhmmss.xlsx
# ============================================================

import requests
import pandas as pd
from datetime import datetime
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP


def post_tickets(allocation, ticket_numbers):
    """
    Assigns each present solver (identified by email) their allocated
    tickets via the API.

    Args:
        allocation     (dict): { email : ticket_count }
        ticket_numbers (list): ticket numbers from step1
    """

    print("\n" + "="*70)
    print("  STEP 4 : Posting Tickets via API (by email)")
    print("="*70)

    if not allocation:
        print("  Allocation is empty. Nothing to post.")
        return

    if not ticket_numbers:
        print("  No ticket numbers found. Check Step 1.")
        return

    # ---- Distribute tickets among emails (round-robin style) ----
    ticket_pool  = list(ticket_numbers)
    assign_map   = {}   # { email : [ticket_no, ...] }
    idx = 0

    for email, count in allocation.items():
        chunk = ticket_pool[idx : idx + count]
        assign_map[email] = chunk
        idx += count

        if idx >= len(ticket_pool):
            print(f"  Ran out of tickets in the pool. Remaining will be skipped.")
            break

    print(f"\n  Assignment Plan:")
    print(f"  {'Email':<38} Tickets")
    print(f"  {'-'*60}")
    for email, tlist in assign_map.items():
        print(f"  {email:<38} {tlist}")

    # ---- API Calls ----
    results = []

    for email, tickets in assign_map.items():
        for ticket_no in tickets:

            print(f"\n  Posting Ticket {ticket_no} -> {email} ...")

            payload = {
                "ServiceName": "IM_LogOrUpdateIncident",
                "objCommonParameters": {
                    "_ProxyDetails": {
                        "AuthType": "APIKEY",
                        "APIKey": API_KEY,
                        "ProxyID": 0,
                        "ReturnType": "JSON",
                        "OrgID": ORG_ID
                    },
                    "incidentParamsJSON": {
                        "IncidentContainerJsonObj": {
                            "Updater": "Executive",
                            "Ticket": {
                                "IsFromWebService": True,
                                "Ticket_No": ticket_no,
                                "Sup_Function": INSTANCE,
                                "Status": "Assigned",
                                "Assigned_WorkGroup_Name": WORKGROUP,
                                "Medium": "API",
                                "Source": "API Call",
                                "Assigned_Engineer_Email": email,
                                "PageName": "LogTicket"
                            },
                            "TicketInformation": {
                                "Information": f"Auto-assigned to {email} via Python"
                            },
                            "CustomFields": []
                        }
                    },
                    "RequestType": "RemoteCall"
                }
            }

            try:
                resp = requests.post(API_URL, json=payload, timeout=30)

                if resp.status_code == 200:
                    print(f"  Success - Ticket {ticket_no} assigned to {email}.")
                    result_status = "Success"
                else:
                    print(f"  Failed ({resp.status_code}) - Ticket {ticket_no}")
                    result_status = f"Failed_{resp.status_code}"

                results.append({
                    "Ticket_No"        : ticket_no,
                    "Email"            : email,
                    "Status_Code"      : resp.status_code,
                    "Result"           : result_status,
                    "Assigned by Bot"  : "Yes",
                    "Time"             : datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })

            except requests.exceptions.ConnectionError:
                print(f"  Connection error - Ticket {ticket_no}")
                results.append({
                    "Ticket_No"        : ticket_no,
                    "Email"            : email,
                    "Status_Code"      : "N/A",
                    "Result"           : "Connection Error",
                    "Assigned by Bot"  : "Yes",
                    "Time"             : datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })

            except Exception as e:
                print(f"  Error: {e}")
                results.append({
                    "Ticket_No"        : ticket_no,
                    "Email"            : email,
                    "Status_Code"      : "N/A",
                    "Result"           : f"Error: {str(e)}",
                    "Assigned by Bot"  : "Yes",
                    "Time"             : datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })

    # ---- Show the full result table in the terminal ----
    if results:
        print(f"\n  -- FULL RESULT TABLE (terminal) --------------------------------")
        print(f"  {'Ticket No':<12} {'Email':<38} {'Result'}")
        print(f"  {'-'*75}")
        for r in results:
            print(f"  {str(r['Ticket_No']):<12} {r['Email']:<38} {r['Result']}")

        # ---- Save result to Excel ----
        ts          = datetime.now().strftime("%d%m%y_%H%M%S")
        result_file = f"assignment_result_{ts}.xlsx"
        pd.DataFrame(results).to_excel(result_file, index=False)
        print(f"\n  Assignment result saved -> {result_file}")

        # ---- Summary print ----
        success = sum(1 for r in results if r["Result"] == "Success")
        failed  = len(results) - success
        print(f"\n  -- POST SUMMARY ---------------------------------")
        print(f"  Total Posted : {len(results)}")
        print(f"  Success      : {success}")
        print(f"  Failed       : {failed}")


# ---- Standalone run ----
if __name__ == "__main__":
    # Test data
    sample_allocation = {
        "akshita.bhandari@maruti.co.in": 3,
        "jktech_neha.aswal@maruti.co.in": 5
    }
    sample_tickets = ["653501", "653502", "653503", "653504", "653505",
                       "653506", "653507", "653508"]
    post_tickets(sample_allocation, sample_tickets)

# ============================================================
#  main.py — Ticket Management System — Full Auto Flow
#
#  Steps:
#   1. Fetch ticket list from API   -> save Excel + JSON
#   2. Check attendance             -> split Present / Absent
#   3. Split tickets 70-30          -> only to present people
#   4. Assign via API               -> save result to Excel
#
#  Run: python main.py
# ============================================================

from datetime import datetime
from step1_fetch_tickets import fetch_tickets
from step2_attendance    import check_attendance
from step3_allocate      import allocate_tickets
from step4_post_tickets  import post_tickets


def main():
    print("\n" + "*"*55)
    print("   TICKET MANAGEMENT SYSTEM - Full Auto Flow")
    print("*"*55)

    # -- Date (automatic - uses today's date, manual input removed) --
    date = datetime.now().strftime("%d-%m-%Y")
    print(f"\n  Using today's date : {date}")

    # -- STEP 1: API Fetch --------------------------------------
    excel_file, ticket_numbers = fetch_tickets()

    # -- Total tickets (automatic - count of tickets fetched from API) --
    total_tickets = len(ticket_numbers)
    print(f"\n  Total Tickets (auto-detected) : {total_tickets}")

    # -- STEP 2: Attendance ---------------------------------------
    present, absent, row = check_attendance(date)

    if present is None:
        print("\nAttendance not found. Stopping program.")
        return

    # -- STEP 3: Allocation -----------------------------------------
    allocation = allocate_tickets(present, total_tickets)

    if not allocation:
        print("\nNo one received any tickets. Stopping program.")
        return

    # -- STEP 4: Post via API -----------------------------------------
    confirm = input("\nAssign tickets via API? (y/n): ").strip().lower()

    if confirm == "y":
        post_tickets(allocation, ticket_numbers)
    else:
        print("\nAPI posting skipped.")

    print("\n" + "*"*55)
    print("   Done!")
    print("*"*55)


if __name__ == "__main__":
    main()

# ============================================================
#  step1_fetch_tickets.py
#  Fetches the ticket list from the API and saves it to Excel + JSON
#  Output : tickets_ddmmyy_hhmmss.xlsx          -> full data
#            tickets_summary_ddmmyy_hhmmss.xlsx  -> selected columns only
#            output.json                          -> raw JSON response
# ============================================================

import requests
import json
import pandas as pd
from datetime import datetime
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP

# Only these columns are needed in the summary excel (in this order)
SUMMARY_COLUMNS = [
    "Incident ID",
    "Logged Time",
    "Status",
    "Symptom",
    "Workgroup Name",
    "Executive Name",
    "FullCategory",
]


def fetch_tickets(page_size=100):
    """
    Calls the API to get assigned tickets.
    Returns: (excel_filename, ticket_number_list)
    """

    print("\n" + "="*55)
    print("  STEP 1 : Fetching Ticket List from API")
    print("="*55)

    payload = {
        "ServiceName": "IM_GetIncidentList",
        "objCommonParameters": {
            "_ProxyDetails": {
                "AuthType": "APIKey",
                "APIKey": API_KEY,
                "ProxyID": 0,
                "ReturnType": "json",
                "OrgID": ORG_ID,
                "TokenID": ""
            },
            "objIncidentCommonFilter": {
                "WorkgroupName": WORKGROUP,
                "CurrentPageIndex": 0,
                "PageSize": page_size,
                "OrgID": str(ORG_ID),
                "Instance": INSTANCE,
                "Status": "Assigned",
                "IsWebServiceRequest": True
            }
        }
    }

    try:
        print("  Calling API...")
        response = requests.post(API_URL, json=payload, timeout=30)
        print(f"  Status Code : {response.status_code}")

        # ---- Failure check ----
        if response.status_code != 200:
            print("  API did not return 200. Response:")
            print("    ", response.text[:300])
            return None, []

        data = response.json()

        # ---- Raw JSON save ----
        with open("output.json", "w") as f:
            json.dump(data, f, indent=4)
        print("  Raw JSON saved  -> output.json")

        # ---- Extract tickets ----
        tickets = data.get("OutputObject", {}).get("MyTickets", [])

        if not tickets:
            print("  No tickets found in the response.")
            return None, []

        print(f"  Total Tickets found : {len(tickets)}")

        # ---- JSON -> DataFrame ----
        df = pd.DataFrame(tickets)
        timestamp = datetime.now().strftime("%d%m%y_%H%M%S")

        # ---- Excel #1 : Full data ----
        excel_filename = f"tickets_{timestamp}.xlsx"
        df.to_excel(excel_filename, index=False)
        print(f"  Full Excel saved     -> {excel_filename}")

        # ---- Excel #2 : Summary (selected columns only) ----
        missing_cols = [c for c in SUMMARY_COLUMNS if c not in df.columns]
        if missing_cols:
            print(f"  These columns were not found in the response (will stay blank): {missing_cols}")

        summary_df = df.reindex(columns=SUMMARY_COLUMNS)
        summary_df["Assigned by Bot"] = "Yes"
        summary_filename = f"tickets_summary_{timestamp}.xlsx"
        summary_df.to_excel(summary_filename, index=False)
        print(f"  Summary Excel saved  -> {summary_filename}")

        # ---- Ticket numbers list ----
        if "Incident ID" in df.columns:
            ticket_numbers = df["Incident ID"].astype(str).tolist()
        else:
            ticket_numbers = []
            print("  'Incident ID' column not found in DataFrame.")

        return excel_filename, ticket_numbers

    except requests.exceptions.ConnectionError:
        print("  Could not connect to the server. Check network/URL.")
        return None, []
    except Exception as e:
        print(f"  Unexpected error: {e}")
        return None, []


# ---- Standalone run ----
if __name__ == "__main__":
    excel_file, tickets = fetch_tickets()
    if tickets:
        print(f"\n  Ticket Numbers : {tickets[:5]} ... (total {len(tickets)})")

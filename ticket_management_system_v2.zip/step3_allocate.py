# ============================================================
#  step3_allocate.py
#  Decides who gets each ticket, based on the ticket's Status.
#
#  Rule:
#    Status = "New"
#       -> goes into the Employee/Vendor split using the ratio read
#          from row 2 of the roster sheet (e.g. 20% Employee / 80%
#          Vendor), shared equally among the Present + Solver=Y
#          people in each role.
#
#    Status = "Assigned"
#       -> stays with the person it's already assigned to
#          (matched by "Executive Name" against the emails in
#          the roster sheet), IF that person is Present today AND
#          is a Solver.
#       -> if that person is Absent today, the ticket is handed
#          to another Present person in the SAME role
#          (Employee stays Employee, Vendor stays Vendor),
#          split equally among them.
#
#    Any other / unrecognised Status
#       -> skipped, printed clearly as a warning so it can be
#          checked manually.
# ============================================================

from config import ROSTER_FILE


def _normalize_name(text):
    """
    Turns an email's local-part or an 'Executive Name' string into a
    normalized, order-independent set of words, so the two can be
    matched even if formatted differently
    (e.g. email 'JKTECH_Neha.Aswal' vs ticket name 'Neha Aswal').
    """
    text = str(text).strip()
    if "_" in text:
        # drop a vendor-company prefix, e.g. JKTECH_ / DTL_ / MYSOFTLABS_
        text = text.split("_")[-1]
    text = text.replace(".", " ").replace("_", " ")
    words = [w.lower() for w in text.split() if w]
    return tuple(sorted(words))


def _build_name_lookup(all_people):
    """
    Builds { normalized_name : {"email", "role", "present", "solver"} }
    using the FULL roster (present + absent people) from step2, so an
    'Executive Name' on a ticket can be matched to a roster email no
    matter whether that person is present today or not.

    Two keys are registered per person, since "Executive Name" on a
    ticket might be just a first name (matches the roster's "Name"
    column, e.g. "Raj") or a fuller name (matches the email's
    local-part, e.g. "raj.patil" -> "Raj Patil"):
      - normalized "Name" column value
      - normalized email local-part (text before the @)
    """
    lookup = {}
    for p in all_people or []:
        entry = {
            "email": p["email"],
            "role": p["role"],
            "present": p["status"] == "P",
            "solver": p["solver"] == "Y",
        }

        if p.get("name"):
            lookup[_normalize_name(p["name"])] = entry

        email_key = _normalize_name(p["email"].split("@")[0])
        lookup.setdefault(email_key, entry)

    return lookup


def _split_equally(people, share):
    """
    Equal split of `share` items among `people` (list of emails).
    Remainder is handed out to the first ones, one by one.
    Returns { email : count }.
    """
    result = {}
    if not people or share <= 0:
        return result
    for i, email in enumerate(people):
        result[email] = share // len(people) + (1 if i < share % len(people) else 0)
    return result


def _hand_out(ticket_pool, people, final_assignment, label):
    """
    Splits ticket_pool equally among people and records the exact
    ticket numbers each person gets into final_assignment.
    """
    if not ticket_pool:
        return
    if not people:
        print(f"  No Present {label} -- {len(ticket_pool)} ticket(s) skipped: {ticket_pool}")
        return

    counts = _split_equally(people, len(ticket_pool))
    idx = 0
    for email, count in counts.items():
        chunk = ticket_pool[idx: idx + count]
        idx += count
        if not chunk:
            continue
        final_assignment.setdefault(email, []).extend(chunk)
        print(f"  {email:<38} <- {chunk}")


def allocate_tickets(ticket_info, present, all_people, ratio):
    """
    Args:
        ticket_info (dict): { ticket_no : {"Status":.., "Executive Name":..} }
                             -- from step1
        present (dict)    : { "Emp":[{email,name,solver}], "Ven":[...] }
                             -- from step2 (Present people only, any solver value)
        all_people (list) : [{"email","name","role","status","solver"}, ...]
                             -- from step2, FULL roster (present + absent)
        ratio (dict)      : { "Emp": <int>, "Ven": <int> } -- e.g. {"Emp":20,"Ven":80}
                             -- read from row 2 of the roster sheet by step2

    Only Solver == "Y" people ever receive a ticket. A Present person
    with Solver == "N" is logged but skipped entirely (not used for new
    tickets, and not used as a reassignment target either).

    Returns:
        final_assignment (dict): { email : [ticket_no, ticket_no, ...] }
    """

    print("\n" + "="*55)
    print("  STEP 3 : Ticket Allocation")
    print("="*55)

    name_lookup = _build_name_lookup(all_people)

    new_tickets        = []              # Status == New
    direct_assign      = {}              # ticket_no -> email (Assigned + Present)
    reassign_pool       = {"Emp": [], "Ven": []}   # Assigned + Absent
    unmatched_tickets   = []             # Assigned, but name didn't match anyone
    skipped_tickets     = []             # any other/unknown status

    for ticket_no, info in ticket_info.items():
        status = str(info.get("Status", "")).strip().lower()
        exec_name = info.get("Executive Name", "")

        if status == "new":
            new_tickets.append(ticket_no)

        elif status == "assigned":
            match = name_lookup.get(_normalize_name(exec_name))

            if not match:
                unmatched_tickets.append(ticket_no)
                print(f"  [WARN] Ticket {ticket_no}: assigned executive "
                      f"'{exec_name}' not found in {ROSTER_FILE} -- skipped.")
                continue

            if match["present"] and match["solver"]:
                direct_assign[ticket_no] = match["email"]
            else:
                # Absent, OR present but Solver=N -- reassign within same role
                reassign_pool[match["role"]].append(ticket_no)

        else:
            skipped_tickets.append(ticket_no)
            print(f"  [WARN] Ticket {ticket_no}: unrecognised Status "
                  f"'{info.get('Status')}' -- skipped.")

    final_assignment = {}

    # ---- 1) Already-Assigned tickets, person Present -> stays put ----
    print(f"\n  -- Assigned tickets, person Present (stays as-is) --------")
    if direct_assign:
        for ticket_no, email in direct_assign.items():
            final_assignment.setdefault(email, []).append(ticket_no)
            print(f"  Ticket {ticket_no:<10} -> stays with {email}")
    else:
        print("  None")

    # ---- 2) Already-Assigned tickets, person Absent or non-solver -> reassign, same role ----
    print(f"\n  -- Assigned tickets, needing reassignment (same role) --")
    any_reassigned = False
    for role, tickets in reassign_pool.items():
        if not tickets:
            continue
        any_reassigned = True
        label = "Employees" if role == "Emp" else "Vendors"
        present_solvers = [p["email"] for p in present[role] if p["solver"] == "Y"]
        print(f"  {label} : {tickets}")
        _hand_out(tickets, present_solvers, final_assignment, label)
    if not any_reassigned:
        print("  None")

    # ---- 3) New tickets -> Employee/Vendor split, ratio from roster sheet ----
    total_new = len(new_tickets)
    emp_total = round(total_new * ratio["Emp"] / 100)
    ven_total = total_new - emp_total

    print(f"\n  -- New tickets : {ratio['Emp']}/{ratio['Ven']} split (Emp {ratio['Emp']}% | Ven {ratio['Ven']}%) --")
    print(f"  Total New Tickets : {total_new}")
    print(f"  Employee Share    : {emp_total}")
    print(f"  Vendor Share      : {ven_total}")

    pool = list(new_tickets)
    idx = 0
    for role, share in [("Emp", emp_total), ("Ven", ven_total)]:
        label = "Employees" if role == "Emp" else "Vendors"
        chunk = pool[idx: idx + share]
        idx += share
        present_people = [p["email"] for p in present[role] if p["solver"] == "Y"]
        print(f"\n  -- {label} --")
        _hand_out(chunk, present_people, final_assignment, label)

    # ---- FINAL SUMMARY ----
    print(f"\n  -- FINAL ALLOCATION --------------------------")
    if final_assignment:
        for email, tickets in final_assignment.items():
            print(f"  {email:<38} : {len(tickets)} ticket(s) {tickets}")
    else:
        print("  Nobody received any tickets.")

    if unmatched_tickets:
        print(f"\n  Unmatched (Executive Name not found in {ROSTER_FILE}) : {unmatched_tickets}")
    if skipped_tickets:
        print(f"  Skipped (unrecognised Status)                            : {skipped_tickets}")

    return final_assignment


# ---- Standalone run ----
if __name__ == "__main__":
    # Test data, matching the shapes step2_attendance.py now produces
    sample_ticket_info = {
        "653501": {"Status": "New",      "Executive Name": ""},
        "653502": {"Status": "New",      "Executive Name": ""},
        "653503": {"Status": "New",      "Executive Name": ""},
        "653504": {"Status": "Assigned", "Executive Name": "Raj"},       # present, solver
        "653505": {"Status": "Assigned", "Executive Name": "Zafar"},     # absent -> reassigned
        "653506": {"Status": "New",      "Executive Name": ""},
    }
    sample_present = {
        "Emp": [{"email": "anupam.jha@maruti.co.in", "name": "Anupam", "solver": "Y"},
                {"email": "shibasish.kar@maruti.co.in", "name": "Shibasish", "solver": "Y"}],
        "Ven": [{"email": "raj.patil@kpmg.com", "name": "Raj", "solver": "Y"},
                {"email": "rahil.rathi@kpmg.com", "name": "Rahil", "solver": "Y"}]
    }
    sample_all_people = [
        {"email": "anupam.jha@maruti.co.in", "name": "Anupam", "role": "Emp", "status": "P", "solver": "Y"},
        {"email": "shibasish.kar@maruti.co.in", "name": "Shibasish", "role": "Emp", "status": "P", "solver": "Y"},
        {"email": "raj.patil@kpmg.com", "name": "Raj", "role": "Ven", "status": "P", "solver": "Y"},
        {"email": "rahil.rathi@kpmg.com", "name": "Rahil", "role": "Ven", "status": "P", "solver": "Y"},
        {"email": "zafar.mohammad@kpmg.com", "name": "Zafar", "role": "Ven", "status": "A", "solver": "Y"},
    ]
    sample_ratio = {"Emp": 20, "Ven": 80}

    allocate_tickets(sample_ticket_info, sample_present, sample_all_people, sample_ratio)

# ============================================================
#  step2_attendance.py
#  Reads today's roster + attendance straight from the roster
#  Excel file (e.g. sample_roster.xlsx) using openpyxl.
#
#  FILE LAYOUT (one sheet per workgroup, sheet name == workgroup
#  name, e.g. "SAP_MDM - OTH"):
#
#      Row 1:            | Employee | Vendor |
#      Row 2: Assignment Ratio | 20  |  80   |
#      Row 3: (blank)
#      Row 4: email | Alignment | Status | Solver | Name
#      Row 5+: one row per person
#
#  - "Alignment"  : "Employee" or "Vendor"
#  - "Status"     : "P" (present today) or "A" (absent today)
#  - "Solver"     : "Y" / "N" -- only Y people can receive tickets
#  - The sheet is for TODAY only -- whoever updates the file each
#    morning edits the Status column in place. There is no date
#    column / history; "today" just means "whatever this sheet
#    currently says".
# ============================================================

import openpyxl
from config import ROSTER_FILE


def _read_workgroup_sheet(workgroup):
    """
    Reads the roster sheet for one workgroup using openpyxl.

    Returns:
        ratio (dict)  : {"Emp": <int>, "Ven": <int>} -- assignment ratio
                         read from row 2 of the sheet (e.g. 20/80).
        people (list) : [{"email", "name", "role", "status", "solver"}, ...]
                         one entry per row in the roster.

        Returns (None, None) if the file or the sheet is not found.
    """
    try:
        wb = openpyxl.load_workbook(ROSTER_FILE, data_only=True)
    except FileNotFoundError:
        print(f"  [ERROR] File not found: {ROSTER_FILE}")
        return None, None

    if workgroup not in wb.sheetnames:
        print(f"  [ERROR] Sheet '{workgroup}' not found in {ROSTER_FILE}.")
        print(f"  Sheets available: {wb.sheetnames}")
        return None, None

    ws = wb[workgroup]

    # ---- Row 2: Assignment Ratio (B2 = Employee %, C2 = Vendor %) ----
    ratio_row = next(ws.iter_rows(min_row=2, max_row=2, values_only=True))
    try:
        emp_ratio = int(ratio_row[1])
        ven_ratio = int(ratio_row[2])
    except (TypeError, ValueError, IndexError):
        print(f"  [ERROR] Could not read Assignment Ratio from row 2 of sheet '{workgroup}'.")
        return None, None

    # ---- Row 4: headers, Row 5+: people ----
    header_row = next(ws.iter_rows(min_row=4, max_row=4, values_only=True))
    headers = [str(h).strip() if h else "" for h in header_row]

    try:
        col = {name: headers.index(name) for name in ["email", "Alignment", "Status", "Solver", "Name"]}
    except ValueError as e:
        print(f"  [ERROR] Roster sheet '{workgroup}' is missing an expected column: {e}")
        return None, None

    people = []
    for row in ws.iter_rows(min_row=5, max_row=ws.max_row, values_only=True):
        if row[col["email"]] is None:
            continue  # skip blank rows

        email = str(row[col["email"]]).strip()
        alignment = str(row[col["Alignment"]] or "").strip()
        status = str(row[col["Status"]] or "").strip().upper()
        solver = str(row[col["Solver"]] or "").strip().upper()
        name = str(row[col["Name"]] or "").strip()

        role = "Emp" if alignment.lower() == "employee" else "Ven"

        people.append({
            "email": email,
            "name": name,
            "role": role,
            "status": status,   # "P" or "A"
            "solver": solver,   # "Y" or "N"
        })

    return {"Emp": emp_ratio, "Ven": ven_ratio}, people


def check_attendance(workgroup):
    """
    Reads today's roster for the given workgroup.

    Returns:
        present (dict) : { "Emp": [{email,name,solver}], "Ven": [...] }
                          -- only Status == "P" people, both Solver Y and N
                             (step3 filters Solver itself, since a Present
                             non-solver may still matter for reassignment logic).
        absent  (dict) : { "Emp": [email,...], "Ven": [...] }
        ratio   (dict or None) : { "Emp": <int>, "Ven": <int> }
        all_people (list or None) : full raw roster (for name-matching in step3)
    """

    print("\n" + "="*70)
    print(f"  STEP 2 : Attendance Check  ({ROSTER_FILE} -> sheet '{workgroup}')")
    print("="*70)

    ratio, people = _read_workgroup_sheet(workgroup)

    if people is None:
        return None, None, None, None

    present = {"Emp": [], "Ven": []}
    absent  = {"Emp": [], "Ven": []}

    print(f"\n  Assignment Ratio  : Employee {ratio['Emp']}% | Vendor {ratio['Ven']}%\n")
    print(f"  {'Email':<32} {'Name':<14} {'Role':<6} {'Status':<8} Solver")
    print(f"  {'-'*75}")

    for p in people:
        role_label = "Emp" if p["role"] == "Emp" else "Ven"
        status_label = "Present" if p["status"] == "P" else "Absent "
        print(f"  {p['email']:<32} {p['name']:<14} {role_label:<6} {status_label:<8} {p['solver']}")

        if p["status"] == "P":
            present[p["role"]].append({"email": p["email"], "name": p["name"], "solver": p["solver"]})
        else:
            absent[p["role"]].append(p["email"])

    # ---- Summary ----
    print(f"\n  -- SUMMARY ------------------------------------------------")
    present_emp_solvers = [p["email"] for p in present["Emp"] if p["solver"] == "Y"]
    present_ven_solvers = [p["email"] for p in present["Ven"] if p["solver"] == "Y"]
    print(f"  Present Employees (Solver=Y) : {present_emp_solvers or 'None'}")
    print(f"  Present Vendors   (Solver=Y) : {present_ven_solvers or 'None'}")
    print(f"  Absent Employees             : {absent['Emp'] or 'None'}")
    print(f"  Absent Vendors                : {absent['Ven'] or 'None'}")

    non_solver_present = [p["email"] for role in present.values() for p in role if p["solver"] != "Y"]
    if non_solver_present:
        print(f"  Present but Solver=N (skipped) : {non_solver_present}")

    return present, absent, ratio, people


# ---- Standalone run ----
if __name__ == "__main__":
    from config import WORKGROUP
    print(f"  Using workgroup : {WORKGROUP}")
    present, absent, ratio, people = check_attendance(WORKGROUP)

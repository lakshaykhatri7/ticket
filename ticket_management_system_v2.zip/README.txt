============================================================
  TICKET MANAGEMENT SYSTEM -- Project Guide
============================================================

-- PROJECT FILES -----------------------------------------

  config.py              -> Change all settings here
  main.py                -> Run the full flow (run this one)

  step1_fetch_tickets.py -> Fetch tickets from API -> save 2 Excel + JSON
  step2_attendance.py    -> Reads today's roster from sample_roster.xlsx
                             (openpyxl) -- attendance, Solver flag, and
                             the Employee/Vendor assignment ratio
  step3_allocate.py      -> Decides who gets each ticket (see RULES below)
  step4_post_tickets.py  -> Assigns tickets via API

  guessno.py              -> 4-Digit Guessing Game (bonus, unrelated)

-- SETUP ---------------------------------------------------

  1. Install Python (3.8+)
  2. Install libraries:
       pip install requests pandas openpyxl

  3. Open config.py and set these fields:
       API_URL      -> server address
       API_KEY      -> your API key
       WORKGROUP    -> must match BOTH the API's workgroup name AND
                       a sheet name inside ROSTER_FILE
       ROSTER_FILE  -> "sample_roster.xlsx" (or your own roster file)

-- ROSTER FILE FORMAT (sample_roster.xlsx) ------------------

  ONE SHEET PER WORKGROUP. The sheet name must exactly match the
  workgroup name (e.g. "SAP_MDM - OTH", "SAP_MDM - MM").

  Each sheet looks like this:

    Row 1:  (blank)          | Employee | Vendor  | (blank) | (blank)
    Row 2:  Assignment Ratio |   20     |   80    | (blank) | (blank)
    Row 3:  (blank row)
    Row 4:  email            | Alignment| Status  | Solver  | Name
    Row 5+: person1@x.com    | Employee | P       | Y       | First Name
            person2@y.com    | Vendor   | A       | Y       | First Name
            ...

  Column meanings:
    email      -> the person's email (used for ticket assignment)
    Alignment  -> "Employee" or "Vendor"
    Status     -> "P" (Present today) or "A" (Absent today)
    Solver     -> "Y" or "N" -- ONLY Solver=Y people can receive
                  tickets, even if they are marked Present
    Name       -> first name, used to match a ticket's "Executive
                  Name" field back to this person for reassignment

  IMPORTANT: This file is updated MANUALLY every day. There is no
  date column or history -- whoever maintains the file edits the
  Status (and Solver, if needed) column in place each morning, and
  the sheet always represents "today" only.

  The Assignment Ratio in row 2 is also read live from the sheet,
  so different workgroups (sheets) can have different splits (the
  sample file has 20/80 for "SAP_MDM - OTH" and 30/70 for
  "SAP_MDM - MM").

-- HOW TO RUN ------------------------------------------------

  Run the whole system at once:
    python main.py

  Run steps individually:
    python step1_fetch_tickets.py
    python step2_attendance.py
    python step3_allocate.py
    python step4_post_tickets.py

  Game:
    python guessno.py

-- OUTPUT FILES -----------------------------------------------

  tickets_ddmmyy_hhmmss.xlsx           -> Step 1: full API data
  tickets_summary_ddmmyy_hhmmss.xlsx   -> Step 1: Incident ID, Logged Time,
                                          Status, Symptom, Workgroup Name,
                                          Executive Name, FullCategory,
                                          Assigned by Bot
  output.json                           -> Step 1: Raw JSON response
  assignment_result_ddmmyy_hhmmss.xlsx -> Step 4: Ticket_No, Email,
                                          Status_Code, Result,
                                          Assigned by Bot, Time

-- RULES (step3_allocate.py) ------------------------------------

  Ticket Status = "New":
    -> Split between Employees and Vendors using the ratio from
       row 2 of the roster sheet (e.g. 20% Employee / 80% Vendor).
    -> Shared equally among that role's Present + Solver=Y people.
    -> Only Solver=Y people ever receive a ticket.

  Ticket Status = "Assigned":
    -> If the currently-assigned person (matched by "Executive Name"
       against the roster) is Present AND Solver=Y today, the ticket
       stays with them.
    -> Otherwise (they're Absent, OR Present but Solver=N), the
       ticket is reassigned to another Present + Solver=Y person in
       the SAME role (Employee stays Employee, Vendor stays Vendor).

  Any other Status:
    -> Skipped and printed as a warning, for manual review.

  A "Present but Solver=N" person is logged in Step 2's summary but
  never receives a ticket and is never used as a reassignment target.

============================================================

# ============================================================
#  main.py -- Ticket Management System -- Full Auto Flow
#
#  Steps:
#   1. Fetch ticket list from API   -> save Excel + JSON
#   2. Check attendance/roster      -> read sample_roster.xlsx
#                                       (today's Status + Solver,
#                                        per workgroup sheet)
#   3. Allocate tickets:
#        Status "New"      -> Employee/Vendor split using the
#                              ratio from row 2 of the roster sheet
#        Status "Assigned" -> stays with current person if
#                              Present + Solver=Y, else reassigned
#                              within the same role
#   4. Assign via API               -> save result to Excel
#
#  Run: python main.py
# ============================================================

from step1_fetch_tickets import fetch_tickets
from step2_attendance    import check_attendance
from step3_allocate      import allocate_tickets
from step4_post_tickets  import post_tickets
from config              import WORKGROUP


def main():
    print("\n" + "*"*55)
    print("   TICKET MANAGEMENT SYSTEM - Full Auto Flow")
    print("*"*55)

    print(f"\n  Workgroup : {WORKGROUP}")

    # -- STEP 1: API Fetch --------------------------------------
    excel_file, ticket_numbers, ticket_info = fetch_tickets()
    print(f"\n  Total Tickets (auto-detected) : {len(ticket_numbers)}")

    # -- STEP 2: Attendance / Roster (today's Status + Solver) ----
    present, absent, ratio, all_people = check_attendance(WORKGROUP)

    if present is None:
        print("\nRoster could not be read. Stopping program.")
        return

    # -- STEP 3: Allocation -----------------------------------------
    final_assignment = allocate_tickets(ticket_info, present, all_people, ratio)

    if not final_assignment:
        print("\nNo one received any tickets. Stopping program.")
        return

    # -- STEP 4: Post via API -----------------------------------------
    confirm = input("\nAssign tickets via API? (y/n): ").strip().lower()

    if confirm == "y":
        post_tickets(final_assignment)
    else:
        print("\nAPI posting skipped.")

    print("\n" + "*"*55)
    print("   Done!")
    print("*"*55)


if __name__ == "__main__":
    main()

# ============================================================
#  config.py -- All settings in one place
#  Only change things here, leave the other files alone
# ============================================================

# --- API Settings ---
API_URL = "http://msilstaging/Webservice/REST/Summit_RESTWCF.svc/RESTService/CommonWS_JsonObjCall"
API_KEY = "sWkL0CqC1bikNDIJvI66eNxPVBMgNTtlSX31d5kZ4OM="
ORG_ID  = 1
INSTANCE = "ITD"

# --- Workgroup ---
# This must exactly match BOTH the API's WorkgroupName AND a sheet
# name inside ROSTER_FILE (e.g. "SAP_MDM - OTH").
WORKGROUP = "SAP_MDM - OTH"

# --- Roster file ---
# One sheet per workgroup. Each sheet has the Employee/Vendor
# assignment ratio in row 2, and a person-by-person attendance +
# solver table starting at row 4 (headers: email, Alignment,
# Status, Solver, Name). This file is updated manually each day --
# there is no date column, the sheet always reflects "today".
ROSTER_FILE = "sample_roster.xlsx"

# NOTE: TOTAL_TICKETS / EMP_SPLIT / EXCEL_FILE no longer exist here.
# The Employee/Vendor split ratio is now read directly from row 2
# of the roster sheet (see step2_attendance.py), and the ticket
# count is auto-detected from the API response in step1.

# ============================================================
#  step2_attendance.py
#  Reads today's roster + attendance straight from the roster
#  Excel file (e.g. sample_roster.xlsx) using openpyxl.
#
#  NO "Solver" CONCEPT ANYMORE -- whoever is marked Present (P)
#  on TODAY's column receives tickets. If they are Absent (A) on
#  any given day, the ticket is reassigned to someone else who is
#  Present that day.
#
#  TWO supported sheet layouts (auto-detected per sheet):
#
#  FORMAT A -- date-wise columns (one column per calendar day):
#      Row 1:            | Employee | Vendor |
#      Row 2: Assignment Ratio | 20  |  80   |
#      Row 3: (blank)
#      Row 4: Name | Alignment | email | 01-Jun-26 | 02-Jun-26 | ...
#      Row 5+: one row per person, P/A under each date column
#
#  FORMAT B -- single "Status" column (legacy, today only):
#      Row 1:            | Employee | Vendor |
#      Row 2: Assignment Ratio | 20  |  80   |
#      Row 3: (blank)
#      Row 4: email | Alignment | Status | Name
#      Row 5+: one row per person
#
#  Whichever format a sheet uses, this module always returns the
#  SAME shape to the rest of the program: present/absent lists of
#  emails per role, for TODAY.
# ============================================================

import openpyxl
from datetime import datetime
from config import ROSTER_FILE


def _find_col(headers, name):
    """Case-insensitive header lookup. Returns index or None."""
    name_low = name.strip().lower()
    for i, h in enumerate(headers):
        if str(h).strip().lower() == name_low:
            return i
    return None


def _read_workgroup_sheet(workgroup, today_date=None):
    """
    Reads the roster sheet for one workgroup using openpyxl.
    Auto-detects whether the sheet uses FORMAT A (date columns) or
    FORMAT B (single Status column).

    Returns:
        ratio (dict)  : {"Emp": <int>, "Ven": <int>}
        people (list) : [{"email", "name", "role", "status"}, ...]
                         status is "P" or "A" for TODAY only.

        Returns (None, None) on any error (file/sheet/column/date
        not found), after printing a clear message.
    """
    try:
        wb = openpyxl.load_workbook(ROSTER_FILE, data_only=True)
    except FileNotFoundError:
        print(f"  [ERROR] File not found: {ROSTER_FILE}")
        return None, None

    if workgroup not in wb.sheetnames:
        print(f"  [ERROR] Sheet '{workgroup}' not found in {ROSTER_FILE}.")
        print(f"  Sheets available: {wb.sheetnames}")
        return None, None

    ws = wb[workgroup]
    today_date = today_date or datetime.now().date()

    # ---- Row 2: Assignment Ratio (B2 = Employee %, C2 = Vendor %) ----
    ratio_row = next(ws.iter_rows(min_row=2, max_row=2, values_only=True))
    try:
        emp_ratio = int(ratio_row[1])
        ven_ratio = int(ratio_row[2])
    except (TypeError, ValueError, IndexError):
        print(f"  [ERROR] Could not read Assignment Ratio from row 2 of sheet '{workgroup}'.")
        return None, None

    # ---- Row 4: headers ----
    header_row = list(next(ws.iter_rows(min_row=4, max_row=4, values_only=True)))

    name_idx  = _find_col(header_row, "Name")
    align_idx = _find_col(header_row, "Alignment")
    email_idx = _find_col(header_row, "email")
    status_idx = _find_col(header_row, "Status")

    if email_idx is None or align_idx is None:
        print(f"  [ERROR] Roster sheet '{workgroup}' is missing 'email' or 'Alignment' column.")
        return None, None

    # ---- Detect format: is there a date column matching today? ----
    today_col_idx = None
    date_cols_found = []
    for i, h in enumerate(header_row):
        if isinstance(h, datetime):
            date_cols_found.append((i, h.date()))
            if h.date() == today_date:
                today_col_idx = i

    people = []

    if date_cols_found:
        # ---- FORMAT A: date-wise columns ----
        if today_col_idx is None:
            available = ", ".join(d.strftime("%d-%m-%Y") for _, d in date_cols_found)
            print(f"  [ERROR] Today's date ({today_date.strftime('%d-%m-%Y')}) column "
                  f"not found in sheet '{workgroup}'.")
            print(f"  Available date columns: {available}")
            print(f"  Please add/fill today's attendance column in the roster file.")
            return None, None

        for row in ws.iter_rows(min_row=5, max_row=ws.max_row, values_only=True):
            if row[email_idx] is None:
                continue
            email = str(row[email_idx]).strip()
            alignment = str(row[align_idx] or "").strip()
            status = str(row[today_col_idx] or "").strip().upper()
            name = str(row[name_idx]).strip() if name_idx is not None and row[name_idx] else ""

            role = "Emp" if alignment.lower() == "employee" else "Ven"
            people.append({"email": email, "name": name, "role": role, "status": status})

    else:
        # ---- FORMAT B: single Status column (legacy, today only) ----
        if status_idx is None:
            print(f"  [ERROR] Sheet '{workgroup}' has neither date columns nor a 'Status' column.")
            return None, None

        for row in ws.iter_rows(min_row=5, max_row=ws.max_row, values_only=True):
            if row[email_idx] is None:
                continue
            email = str(row[email_idx]).strip()
            alignment = str(row[align_idx] or "").strip()
            status = str(row[status_idx] or "").strip().upper()
            name = str(row[name_idx]).strip() if name_idx is not None and row[name_idx] else ""

            role = "Emp" if alignment.lower() == "employee" else "Ven"
            people.append({"email": email, "name": name, "role": role, "status": status})

    return {"Emp": emp_ratio, "Ven": ven_ratio}, people


def check_attendance(workgroup, today_date=None):
    """
    Reads today's roster for the given workgroup.

    Returns:
        present (dict) : { "Emp": [{email,name}], "Ven": [...] }
                          -- Status == "P" people only (no Solver filter)
        absent  (dict) : { "Emp": [email,...], "Ven": [...] }
        ratio   (dict or None) : { "Emp": <int>, "Ven": <int> }
        all_people (list or None) : full raw roster (for name-matching in step3)
    """

    print("\n" + "="*70)
    print(f"  STEP 2 : Attendance Check  ({ROSTER_FILE} -> sheet '{workgroup}')")
    print("="*70)

    ratio, people = _read_workgroup_sheet(workgroup, today_date)

    if people is None:
        return None, None, None, None

    present = {"Emp": [], "Ven": []}
    absent  = {"Emp": [], "Ven": []}

    today_label = (today_date or datetime.now().date()).strftime("%d-%m-%Y")
    print(f"\n  Date              : {today_label}")
    print(f"  Assignment Ratio  : Employee {ratio['Emp']}% | Vendor {ratio['Ven']}%\n")
    print(f"  {'Email':<32} {'Name':<14} {'Role':<6} Status")
    print(f"  {'-'*65}")

    for p in people:
        role_label = "Emp" if p["role"] == "Emp" else "Ven"
        status_label = "Present" if p["status"] == "P" else "Absent "
        print(f"  {p['email']:<32} {p['name']:<14} {role_label:<6} {status_label}")

        if p["status"] == "P":
            present[p["role"]].append({"email": p["email"], "name": p["name"]})
        else:
            absent[p["role"]].append(p["email"])

    # ---- Summary ----
    print(f"\n  -- SUMMARY ------------------------------------------------")
    print(f"  Present Employees : {[p['email'] for p in present['Emp']] or 'None'}")
    print(f"  Present Vendors   : {[p['email'] for p in present['Ven']] or 'None'}")
    print(f"  Absent Employees  : {absent['Emp'] or 'None'}")
    print(f"  Absent Vendors    : {absent['Ven'] or 'None'}")

    return present, absent, ratio, people


# ---- Standalone run ----
if __name__ == "__main__":
    from config import WORKGROUP
    print(f"  Using workgroup : {WORKGROUP}")
    present, absent, ratio, people = check_attendance(WORKGROUP)

# ============================================================
#  step3_allocate.py
#  Decides who gets each ticket, based on the ticket's Status.
#
#  EMAIL-BASED MATCHING -- the ticket's currently-assigned engineer
#  is matched against the roster by EMAIL ID (Assigned_Engineer_Email),
#  NOT by name. Names can repeat or be formatted differently; emails
#  are unique and unambiguous.
#
#  NO "Solver" CONCEPT -- everyone marked Present (P) today is
#  eligible to receive tickets. Whoever is present gets tickets;
#  if absent, the ticket goes to someone else who is present.
#
#  Rule:
#    Status = "New"
#       -> goes into the Employee/Vendor split using the ratio read
#          from row 2 of the roster sheet (e.g. 20% Employee / 80%
#          Vendor), handed out ROUND-ROBIN (one ticket at a time,
#          cycling through the Present people) within each role.
#
#    Status = "Assigned"
#       -> stays with the person it's already assigned to
#          (matched by Assigned_Engineer_Email against the emails
#          in the roster sheet), IF that EMAIL is Present today.
#       -> if that person is Absent today, the ticket is handed
#          to the NEXT Present person in the SAME role, round-robin
#          style (Employee stays Employee, Vendor stays Vendor).
#
#    Any other / unrecognised Status
#       -> skipped, printed clearly as a warning so it can be
#          checked manually.
# ============================================================

from config import ROSTER_FILE


def _build_email_lookup(all_people):
    """
    Builds { lowercased_email : {"email", "role", "present"} }
    using the FULL roster (present + absent people) from step2, so a
    ticket's Assigned_Engineer_Email can be matched to a roster
    entry no matter whether that person is present today or not.
    """
    lookup = {}
    for p in all_people or []:
        key = p["email"].strip().lower()
        lookup[key] = {
            "email": p["email"],
            "role": p["role"],
            "present": p["status"] == "P",
        }
    return lookup


# ────────────────────────────────────────────────────────────────
#  ROUND-ROBIN distribution
# ────────────────────────────────────────────────────────────────
class RoundRobin:
    """
    Cycles through a list of emails, one ticket at a time.
    """
    def __init__(self, people):
        self.people = list(people)
        self.idx = 0

    def next(self):
        if not self.people:
            return None
        email = self.people[self.idx % len(self.people)]
        self.idx += 1
        return email


def _hand_out_round_robin(ticket_pool, people, final_assignment, label):
    """
    Distributes ticket_pool ONE TICKET AT A TIME, cycling through
    `people` in round-robin order, and records the exact ticket
    numbers each person gets into final_assignment.
    """
    if not ticket_pool:
        return
    if not people:
        print(f"  No Present {label} -- {len(ticket_pool)} ticket(s) skipped: {ticket_pool}")
        return

    rr = RoundRobin(people)
    assigned_log = {}

    for ticket_no in ticket_pool:
        email = rr.next()
        final_assignment.setdefault(email, []).append(ticket_no)
        assigned_log.setdefault(email, []).append(ticket_no)

    for email, tickets in assigned_log.items():
        print(f"  {email:<38} <- {tickets}")


def allocate_tickets(ticket_info, present, all_people, ratio):
    """
    Args:
        ticket_info (dict): { ticket_no : {"Status":.., "Assigned_Engineer_Email":..} }
                             -- from step1
        present (dict)    : { "Emp":[{email,name}], "Ven":[...] }
                             -- from step2 (Present people only, TODAY)
        all_people (list) : [{"email","name","role","status"}, ...]
                             -- from step2, FULL roster (present + absent)
        ratio (dict)      : { "Emp": <int>, "Ven": <int> } -- e.g. {"Emp":20,"Ven":80}
                             -- read from row 2 of the roster sheet

    No Solver filter -- EVERY Present person is eligible to receive
    tickets. Matching of an already-assigned ticket to a roster
    person is done by EMAIL ID (case-insensitive), not by name.

    Distribution within each role is ROUND-ROBIN: tickets are handed
    out one at a time, cycling through that role's Present people.

    Returns:
        final_assignment (dict): { email : [ticket_no, ticket_no, ...] }
    """

    print("\n" + "="*55)
    print("  STEP 3 : Ticket Allocation (Round-Robin, Email-Matched)")
    print("="*55)

    email_lookup = _build_email_lookup(all_people)

    new_tickets        = []              # Status == New
    direct_assign      = {}              # ticket_no -> email (Assigned + Present)
    reassign_pool       = {"Emp": [], "Ven": []}   # Assigned + Absent
    unmatched_tickets   = []             # Assigned, but email didn't match anyone
    skipped_tickets     = []             # any other/unknown status

    for ticket_no, info in ticket_info.items():
        status = str(info.get("Status", "")).strip().lower()
        assigned_email = str(info.get("Assigned_Engineer_Email", "")).strip().lower()

        if status == "new":
            new_tickets.append(ticket_no)

        elif status == "assigned":
            match = email_lookup.get(assigned_email)

            if not match:
                unmatched_tickets.append(ticket_no)
                print(f"  [WARN] Ticket {ticket_no}: assigned email "
                      f"'{assigned_email or '(blank)'}' not found in {ROSTER_FILE} -- skipped.")
                continue

            if match["present"]:
                direct_assign[ticket_no] = match["email"]
            else:
                # Absent today -- reassign within same role
                reassign_pool[match["role"]].append(ticket_no)

        else:
            skipped_tickets.append(ticket_no)
            print(f"  [WARN] Ticket {ticket_no}: unrecognised Status "
                  f"'{info.get('Status')}' -- skipped.")

    final_assignment = {}

    # ---- 1) Already-Assigned tickets, person Present -> stays put ----
    print(f"\n  -- Assigned tickets, person Present (stays as-is) --------")
    if direct_assign:
        for ticket_no, email in direct_assign.items():
            final_assignment.setdefault(email, []).append(ticket_no)
            print(f"  Ticket {ticket_no:<10} -> stays with {email}")
    else:
        print("  None")

    # ---- 2) Already-Assigned tickets, person Absent -> reassign, same role ----
    #          -> ROUND-ROBIN among present people in that role
    print(f"\n  -- Assigned tickets, needing reassignment (round-robin, same role) --")
    any_reassigned = False
    for role, tickets in reassign_pool.items():
        if not tickets:
            continue
        any_reassigned = True
        label = "Employees" if role == "Emp" else "Vendors"
        present_people = [p["email"] for p in present[role]]
        print(f"  {label} : {tickets}")
        _hand_out_round_robin(tickets, present_people, final_assignment, label)
    if not any_reassigned:
        print("  None")

    # ---- 3) New tickets -> Employee/Vendor split, ratio from roster sheet ----
    #          -> within each role, ROUND-ROBIN among present people
    total_new = len(new_tickets)
    emp_total = round(total_new * ratio["Emp"] / 100)
    ven_total = total_new - emp_total

    print(f"\n  -- New tickets : {ratio['Emp']}/{ratio['Ven']} split (Emp {ratio['Emp']}% | Ven {ratio['Ven']}%) --")
    print(f"  Total New Tickets : {total_new}")
    print(f"  Employee Share    : {emp_total}")
    print(f"  Vendor Share      : {ven_total}")

    pool = list(new_tickets)
    idx = 0
    for role, share in [("Emp", emp_total), ("Ven", ven_total)]:
        label = "Employees" if role == "Emp" else "Vendors"
        chunk = pool[idx: idx + share]
        idx += share
        present_people = [p["email"] for p in present[role]]
        print(f"\n  -- {label} (round-robin) --")
        _hand_out_round_robin(chunk, present_people, final_assignment, label)

    # ---- FINAL SUMMARY ----
    print(f"\n  -- FINAL ALLOCATION --------------------------")
    if final_assignment:
        for email, tickets in final_assignment.items():
            print(f"  {email:<38} : {len(tickets)} ticket(s) {tickets}")
    else:
        print("  Nobody received any tickets.")

    if unmatched_tickets:
        print(f"\n  Unmatched (email not found in {ROSTER_FILE}) : {unmatched_tickets}")
    if skipped_tickets:
        print(f"  Skipped (unrecognised Status)                  : {skipped_tickets}")

    return final_assignment


# ---- Standalone run ----
if __name__ == "__main__":
    # Test data, matching the shapes step2_attendance.py now produces
    sample_ticket_info = {
        "653501": {"Status": "New",      "Assigned_Engineer_Email": ""},
        "653502": {"Status": "New",      "Assigned_Engineer_Email": ""},
        "653503": {"Status": "New",      "Assigned_Engineer_Email": ""},
        "653504": {"Status": "Assigned", "Assigned_Engineer_Email": "raj.patil@kpmg.com"},     # present
        "653505": {"Status": "Assigned", "Assigned_Engineer_Email": "zafar.mohammad@kpmg.com"}, # absent -> reassigned
        "653506": {"Status": "New",      "Assigned_Engineer_Email": ""},
    }
    sample_present = {
        "Emp": [{"email": "anupam.jha@maruti.co.in", "name": "Anupam"},
                {"email": "shibasish.kar@maruti.co.in", "name": "Shibasish"}],
        "Ven": [{"email": "raj.patil@kpmg.com", "name": "Raj"},
                {"email": "rahil.rathi@kpmg.com", "name": "Rahil"}]
    }
    sample_all_people = [
        {"email": "anupam.jha@maruti.co.in", "name": "Anupam", "role": "Emp", "status": "P"},
        {"email": "shibasish.kar@maruti.co.in", "name": "Shibasish", "role": "Emp", "status": "P"},
        {"email": "raj.patil@kpmg.com", "name": "Raj", "role": "Ven", "status": "P"},
        {"email": "rahil.rathi@kpmg.com", "name": "Rahil", "role": "Ven", "status": "P"},
        {"email": "zafar.mohammad@kpmg.com", "name": "Zafar", "role": "Ven", "status": "A"},
    ]
    sample_ratio = {"Emp": 20, "Ven": 80}

    allocate_tickets(sample_ticket_info, sample_present, sample_all_people, sample_ratio)

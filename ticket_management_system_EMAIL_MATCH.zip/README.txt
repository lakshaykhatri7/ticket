============================================================
  TICKET MANAGEMENT SYSTEM -- Project Guide (Email-Matched)
============================================================

-- PROJECT FILES -----------------------------------------

  config.py              -> Change all settings here
  main.py                -> Run the full flow (run this one)

  step1_fetch_tickets.py -> Fetch tickets from API -> save 2 Excel + JSON
                             (fetches Assigned_Engineer_Email field)
  step2_attendance.py    -> Reads TODAY's attendance from roster_attendence.xlsx
                             (date-wise columns OR legacy Status column,
                             auto-detected per sheet)
  step3_allocate.py      -> Decides who gets each ticket (see RULES below)
                             ROUND-ROBIN distribution, EMAIL-based matching
  step4_post_tickets.py  -> Assigns tickets via API

  guessno.py              -> 4-Digit Guessing Game (bonus, unrelated)

-- EMAIL-BASED MATCHING (IMPORTANT CHANGE) ---------------------

  Tickets are matched to roster people by EMAIL ID
  (Assigned_Engineer_Email), NOT by name anymore.

  Earlier the system matched a ticket's "Executive Name" against
  the roster's "Name" column, which could go wrong if two people
  had the same first name, or if the name was formatted
  differently on the ticket vs the roster.

  Now: step1 fetches the ticket's "Assigned_Engineer_Email" field
  directly from the API, and step3 looks that email up in the
  roster's "email" column (case-insensitive, exact match). This is
  unambiguous -- no name-guessing involved.

  If the API does not return an Assigned_Engineer_Email for a
  ticket (blank), or the email is not found in the roster, the
  ticket is reported as "Unmatched" and skipped for manual review.

-- NO "SOLVER" CONCEPT ----------------------------------------

  There is NO Solver flag. Whoever is marked Present (P) for TODAY
  is eligible to receive tickets. If that person is Absent (A)
  on any given day, their ticket is reassigned (round-robin) to
  someone else who IS present that day, in the same role
  (Employee/Vendor).

-- SETUP ---------------------------------------------------

  1. Install Python (3.8+)
  2. Install libraries:
       pip install requests pandas openpyxl

  3. Open config.py and set these fields:
       API_URL      -> server address
       API_KEY      -> your API key
       WORKGROUP    -> must match BOTH the API's workgroup name AND
                       a sheet name inside ROSTER_FILE
       ROSTER_FILE  -> "roster_attendence.xlsx" (or your own roster file)

-- ROSTER FILE FORMAT (roster_attendence.xlsx) ------------------

  ONE SHEET PER WORKGROUP. The sheet name must exactly match the
  workgroup name (e.g. "SAP_MDM - OTH", "SAP_MDM - MM").

  TWO layouts are supported, auto-detected per sheet:

  -- FORMAT A : date-wise columns (one column per calendar day) --

    Row 1:  (blank)          | Employee | Vendor
    Row 2:  Assignment Ratio |   20     |   80
    Row 3:  (blank row)
    Row 4:  Name | Alignment | email | 01-Jun-26 | 02-Jun-26 | ...
    Row 5+: Rahil | Vendor  | rahil.rathi@kpmg.com | P | P | A | ...

    The system automatically finds TODAY's date column and reads
    that day's P/A.

  -- FORMAT B : legacy single Status column (today only) --

    Row 1:  (blank)          | Employee | Vendor
    Row 2:  Assignment Ratio |   20     |   80
    Row 3:  (blank row)
    Row 4:  email | Alignment | Status | Name
    Row 5+: person@x.com | Employee | P | First Name

  Column meanings (both formats):
    email      -> the person's email -- THIS is what tickets are
                  matched against (case-insensitive)
    Alignment  -> "Employee" or "Vendor"
    Name       -> display only, no longer used for matching
    P / A      -> Present / Absent for that day

  The Assignment Ratio in row 2 is read LIVE from each sheet.

-- HOW TO RUN ------------------------------------------------

  Run the whole system at once:
    python main.py

  Run steps individually:
    python step1_fetch_tickets.py
    python step2_attendance.py
    python step3_allocate.py
    python step4_post_tickets.py

  Game:
    python guessno.py

-- OUTPUT FILES -----------------------------------------------

  tickets_ddmmyy_hhmmss.xlsx           -> Step 1: full API data
  tickets_summary_ddmmyy_hhmmss.xlsx   -> Step 1: Incident ID, Logged Time,
                                          Status, Symptom, Workgroup Name,
                                          Executive Name, Assigned_Engineer_Email,
                                          FullCategory, Assigned by Bot
  output.json                           -> Step 1: Raw JSON response
  assignment_result_ddmmyy_hhmmss.xlsx -> Step 4: Ticket_No, Email,
                                          Status_Code, Result,
                                          Assigned by Bot, Time

-- RULES (step3_allocate.py) ------------------------------------

  Ticket Status = "New":
    -> Split between Employees and Vendors using the ratio from
       row 2 of the roster sheet (e.g. 20% Employee / 80% Vendor).
    -> Distributed ROUND-ROBIN (one ticket at a time, cycling
       through that role's Present people).
    -> EVERY Present person is eligible (no Solver filter).

  Ticket Status = "Assigned":
    -> Ticket's Assigned_Engineer_Email is looked up DIRECTLY in
       the roster's email column.
    -> If that EMAIL is Present TODAY, the ticket stays with them.
    -> Otherwise (Absent today), the ticket is reassigned
       ROUND-ROBIN to another Present person in the SAME role
       (Employee stays Employee, Vendor stays Vendor).
    -> If the email is blank or not found in the roster, the
       ticket is reported as "Unmatched" for manual review.

  Any other Status:
    -> Skipped and printed as a warning, for manual review.

  The Employee/Vendor split RATIO always comes from row 2 of the
  roster Excel sheet -- nowhere else.

============================================================

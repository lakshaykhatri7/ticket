# ============================================================
#  guessno.py - 4-Digit Number Guessing Game
#  The computer generates a secret 4-digit code
#  You guess it, and get a hint about which digits are correct
# ============================================================

import random


def play_game():
    # ---- Generate the secret code ----
    secret_code = str(random.randint(1000, 9999))

    print("\n" + "*"*40)
    print("   4-Digit Number Guessing Game")
    print("   Guess the secret 4-digit code!")
    print("*"*40)

    attempts = 0

    while True:
        guess = input("\nEnter a 4-digit number: ").strip()

        # ---- Validation ----
        if len(guess) != 4 or not guess.isdigit():
            print("Please enter exactly 4 digits.")
            continue

        attempts += 1

        # ---- Win condition ----
        if guess == secret_code:
            print(f"\nCorrect! The code was: {secret_code}")
            print(f"   Total Attempts : {attempts}")
            break

        # ---- Hint: which digits are correct ----
        correct_digits = [d for d in set(guess) if d in secret_code]

        if correct_digits:
            print(f"Correct digit(s): {', '.join(correct_digits)}")
        else:
            print("None of the digits are correct.")

        print(f"   (Attempts so far: {attempts})")

    # ---- Play again? ----
    again = input("\nPlay again? (y/n): ").strip().lower()
    if again == "y":
        play_game()
    else:
        print("\nGame over. Goodbye!")


if __name__ == "__main__":
    play_game()

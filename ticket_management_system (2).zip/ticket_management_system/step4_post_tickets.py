# ============================================================
#  step4_post_tickets.py
#  Assigns tickets via the API using the exact ticket -> email
#  plan decided by step3_allocate.py
#  (Assigned_Engineer_Email is taken from the ATTEND.xlsx
#   column header for each person -- no fixed config email is used)
#
#  The original "Executive Name" from the API (whoever the ticket
#  was assigned to before) is written into the result Excel as a
#  reference-only column ("Executive_Name (Previous)") -- it plays
#  no role in deciding the new assignment.
#
#  Every result is shown in both the terminal and Excel.
#  Output: assignment_result_ddmmyy_hhmmss.xlsx
# ============================================================

import requests
import pandas as pd
from datetime import datetime
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP


def post_tickets(final_assignment, executive_names=None):
    """
    Posts each ticket to the email it was allocated to by step3.

    Args:
        final_assignment (dict): { email : [ticket_no, ticket_no, ...] }
                                  -- produced by step3_allocate.allocate_tickets
        executive_names (dict)  : { ticket_no : original "Executive Name"
                                     from the API } -- reference-only label,
                                     written into the output Excel alongside
                                     the new assigned email. Not used for
                                     any matching/logic.
    """
    executive_names = executive_names or {}

    print("\n" + "="*70)
    print("  STEP 4 : Posting Tickets via API (by email)")
    print("="*70)

    if not final_assignment:
        print("  Nothing to post -- allocation is empty.")
        return

    print(f"\n  Assignment Plan:")
    print(f"  {'Email':<38} Tickets")
    print(f"  {'-'*60}")
    for email, tlist in final_assignment.items():
        print(f"  {email:<38} {tlist}")

    # ---- API Calls ----
    results = []

    for email, tickets in final_assignment.items():
        for ticket_no in tickets:

            print(f"\n  Posting Ticket {ticket_no} -> {email} ...")

            payload = {
                "ServiceName": "IM_LogOrUpdateIncident",
                "objCommonParameters": {
                    "_ProxyDetails": {
                        "AuthType": "APIKEY",
                        "APIKey": API_KEY,
                        "ProxyID": 0,
                        "ReturnType": "JSON",
                        "OrgID": ORG_ID
                    },
                    "incidentParamsJSON": {
                        "IncidentContainerJsonObj": {
                            "Updater": "Executive",
                            "Ticket": {
                                "IsFromWebService": True,
                                "Ticket_No": ticket_no,
                                "Sup_Function": INSTANCE,
                                "Status": "Assigned",
                                "Assigned_WorkGroup_Name": WORKGROUP,
                                "Medium": "API",
                                "Source": "API Call",
                                "Assigned_Engineer_Email": email,
                                "PageName": "LogTicket"
                            },
                            "TicketInformation": {
                                "Information": f"Auto-assigned to {email} via Python"
                            },
                            "CustomFields": []
                        }
                    },
                    "RequestType": "RemoteCall"
                }
            }

            try:
                resp = requests.post(API_URL, json=payload, timeout=30)

                if resp.status_code == 200:
                    print(f"  Success - Ticket {ticket_no} assigned to {email}.")
                    result_status = "Success"
                else:
                    print(f"  Failed ({resp.status_code}) - Ticket {ticket_no}")
                    result_status = f"Failed_{resp.status_code}"

                results.append({
                    "Ticket_No"        : ticket_no,
                    "Executive_Name (Previous)" : executive_names.get(str(ticket_no), ""),
                    "Email"            : email,
                    "Status_Code"      : resp.status_code,
                    "Result"           : result_status,
                    "Assigned by Bot"  : "Yes",
                    "Time"             : datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })

            except requests.exceptions.ConnectionError:
                print(f"  Connection error - Ticket {ticket_no}")
                results.append({
                    "Ticket_No"        : ticket_no,
                    "Executive_Name (Previous)" : executive_names.get(str(ticket_no), ""),
                    "Email"            : email,
                    "Status_Code"      : "N/A",
                    "Result"           : "Connection Error",
                    "Assigned by Bot"  : "Yes",
                    "Time"             : datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })

            except Exception as e:
                print(f"  Error: {e}")
                results.append({
                    "Ticket_No"        : ticket_no,
                    "Executive_Name (Previous)" : executive_names.get(str(ticket_no), ""),
                    "Email"            : email,
                    "Status_Code"      : "N/A",
                    "Result"           : f"Error: {str(e)}",
                    "Assigned by Bot"  : "Yes",
                    "Time"             : datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })

    # ---- Show the full result table in the terminal ----
    if results:
        print(f"\n  -- FULL RESULT TABLE (terminal) --------------------------------")
        print(f"  {'Ticket No':<12} {'Email':<38} {'Result'}")
        print(f"  {'-'*75}")
        for r in results:
            print(f"  {str(r['Ticket_No']):<12} {r['Email']:<38} {r['Result']}")

        # ---- Save result to Excel ----
        ts          = datetime.now().strftime("%d%m%y_%H%M%S")
        result_file = f"assignment_result_{ts}.xlsx"
        pd.DataFrame(results).to_excel(result_file, index=False)
        print(f"\n  Assignment result saved -> {result_file}")

        # ---- Summary print ----
        success = sum(1 for r in results if r["Result"] == "Success")
        failed  = len(results) - success
        print(f"\n  -- POST SUMMARY ---------------------------------")
        print(f"  Total Posted : {len(results)}")
        print(f"  Success      : {success}")
        print(f"  Failed       : {failed}")


# ---- Standalone run ----
# No fake/sample data -- runs the real chain (step1 API fetch -> step2
# real attendance -> step3 allocation) and then posts via the real API,
# exactly like main.py, but as a standalone script for testing step4.
if __name__ == "__main__":
    from datetime import datetime
    from step1_fetch_tickets import fetch_tickets
    from step2_attendance import check_attendance
    from step3_allocate import allocate_tickets

    date = datetime.now().strftime("%d-%m-%Y")
    print(f"  Using today's date : {date}")

    _, _, real_ticket_info = fetch_tickets()
    real_present, real_absent, real_rows = check_attendance(date)

    if real_present is None:
        print("\n  Attendance not found -- cannot run posting test.")
    elif not real_ticket_info:
        print("\n  No tickets returned from API -- cannot run posting test.")
    else:
        real_final_assignment, real_executive_names = allocate_tickets(
            real_ticket_info, real_present, real_rows
        )

        if not real_final_assignment:
            print("\n  Nobody received any tickets -- nothing to post.")
        else:
            confirm = input("\nAssign these tickets via the real API now? (y/n): ").strip().lower()
            if confirm == "y":
                post_tickets(real_final_assignment, real_executive_names)
            else:
                print("\nAPI posting skipped.")

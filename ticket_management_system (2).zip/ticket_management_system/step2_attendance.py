# ============================================================
#  step2_attendance.py
#  Reads attendance from ATTEND.xlsx -- single sheet
#  (config.ATTENDANCE_SHEET, e.g. "SAP_MDM - OTH").
#
#  Sheet layout (people in ROWS, dates in COLUMNS):
#    Row 0 : <blank> | Employee | Vendor | ...
#    Row 1 : "Assignment Ratio" | <emp %> | <ven %> | ...
#    Row 2 : <blank>
#    Row 3 : "Name" | "Alignment" | "email" | <date1> | <date2> | ...
#    Row 4+: <name> | Employee/Vendor | <email> | P/A | P/A | ...
#
#  "Alignment" column (Employee/Vendor) replaces the old
#  employee/vendor-sheet split -- it is the role for every rule
#  that used to look at "which sheet is this email in".
#
#  NOTE: There is no "Solver" column in this sheet. Same rule as
#  before -- everyone Present ("P") for today's date is treated
#  as a solver (eligible for tickets).
# ============================================================

import pandas as pd
from datetime import datetime
from config import EXCEL_FILE, ATTENDANCE_SHEET

HEADER_ROW_IDX = 3   # 0-indexed row containing "Name | Alignment | email | <dates...>"
RATIO_ROW_IDX  = 1   # 0-indexed row containing "Assignment Ratio | <emp%> | <ven%>"


def _read_ratio():
    """
    Reads the Employee/Vendor Assignment Ratio from the top of the sheet.
    Returns emp_split_fraction, e.g. 0.20 for a 20/80 split.
    Falls back to 0.30 (30/70) if the ratio row can't be read/parsed.
    """
    try:
        raw = pd.read_excel(EXCEL_FILE, sheet_name=ATTENDANCE_SHEET, header=None)
    except Exception as e:
        print(f"  [WARN] Could not read ratio row: {e}. Defaulting to 30/70.")
        return 0.30

    try:
        emp_pct = float(raw.iat[RATIO_ROW_IDX, 1])
        ven_pct = float(raw.iat[RATIO_ROW_IDX, 2])
        total = emp_pct + ven_pct
        if total <= 0:
            raise ValueError("Ratio values sum to 0")
        return emp_pct / total
    except Exception as e:
        print(f"  [WARN] Ratio row unreadable ({e}). Defaulting to 30/70.")
        return 0.30


def _read_sheet_status(date):
    """
    Reads ATTENDANCE_SHEET, finds the column matching `date`,
    and returns a dict per person: { email: {"status": P/A, "role": Emp/Ven, "name": ..} }
    Returns None if the file/sheet/date can't be found.
    """
    try:
        df = pd.read_excel(EXCEL_FILE, sheet_name=ATTENDANCE_SHEET, header=HEADER_ROW_IDX)
    except FileNotFoundError:
        print(f"  File not found: {EXCEL_FILE}")
        return None
    except ValueError:
        print(f"  Sheet '{ATTENDANCE_SHEET}' not found in {EXCEL_FILE}.")
        return None

    df.columns = [str(c).strip() for c in df.columns]

    required = {"Name", "Alignment", "email"}
    missing = required - set(df.columns)
    if missing:
        print(f"  [ERROR] Expected columns missing in '{ATTENDANCE_SHEET}': {missing}")
        return None

    # Date columns are everything after Name/Alignment/email
    date_cols = [c for c in df.columns if c not in ("Name", "Alignment", "email")]

    # Match the requested date (dd-mm-YYYY) against the date-like column headers
    target = pd.to_datetime(date, dayfirst=True)
    matched_col = None
    for c in date_cols:
        try:
            if pd.to_datetime(c).date() == target.date():
                matched_col = c
                break
        except Exception:
            continue

    if matched_col is None:
        return None

    result = {}
    for _, row in df.iterrows():
        email = str(row.get("email", "")).strip()
        if not email or email.lower() == "nan":
            continue
        result[email] = {
            "status": str(row.get(matched_col, "")).strip().upper(),
            "role": str(row.get("Alignment", "")).strip(),
            "name": str(row.get("Name", "")).strip(),
        }
    return result


def check_attendance(date):
    """
    Checks attendance for the given date from ATTEND.xlsx (ATTENDANCE_SHEET).

    Returns:
        present (dict)  : { "Emp": [{email, solver}], "Ven": [...] }
        absent  (dict)  : { "Emp": [email,...],        "Ven": [...] }
        rows    (dict or None) : flat { email: {"status":P/A, "role":.., "name":..} }
                                  (kept flat -- step3 has been updated to read this)
    """

    print("\n" + "="*70)
    print(f"  STEP 2 : Attendance Check  ({EXCEL_FILE} -> '{ATTENDANCE_SHEET}')")
    print("="*70)

    status_map = _read_sheet_status(date)

    if status_map is None:
        print(f"  Date '{date}' not found in sheet '{ATTENDANCE_SHEET}'.")
        return None, None, None

    present = {"Emp": [], "Ven": []}
    absent  = {"Emp": [], "Ven": []}

    role_key = {"employee": "Emp", "vendor": "Ven"}

    # ---- Table Header ----
    print(f"\n  Date : {date}\n")
    print(f"  {'Email':<38} {'Role':<10} Status")
    print(f"  {'-'*65}")

    for email, info in status_map.items():
        role_raw = info["role"].strip().lower()
        role = role_key.get(role_raw)
        if role is None:
            print(f"  [WARN] {email}: unrecognised Alignment '{info['role']}' -- skipped.")
            continue

        if info["status"] == "P":
            present[role].append({"email": email, "solver": "Y"})
            icon = "Present"
        else:
            absent[role].append(email)
            icon = "Absent "
        print(f"  {email:<38} {role:<10} {icon}")

    # ---- Summary ----
    print(f"\n  -- SUMMARY --------------------------------------")
    print(f"  Present Employees : {[p['email'] for p in present['Emp']] or 'None'}")
    print(f"  Present Vendors   : {[p['email'] for p in present['Ven']] or 'None'}")
    print(f"  Absent Employees  : {absent['Emp'] or 'None'}")
    print(f"  Absent Vendors    : {absent['Ven'] or 'None'}")

    # `rows` kept as a flat { email: {status, role, name} } dict for step3.
    return present, absent, status_map


# ---- Standalone run ----
if __name__ == "__main__":
    date = datetime.now().strftime("%d-%m-%Y")
    print(f"  Using today's date : {date}")
    present, absent, rows = check_attendance(date)
    print(f"\n  Dynamic Emp/Ven ratio -> Emp share: {_read_ratio():.0%}")

# ============================================================
#  config.py — Saari settings ek jagah
#  Sirf yahan changes karo, baaki files mat chhuo
# ============================================================

# --- API Settings ---
API_URL = "http://msilstaging/Webservice/REST/Summit_RESTWCF.svc/RESTService/CommonWS_JsonObjCall"
API_KEY = "sWkL0CqC1bikNDIJvI66eNxPVBMgNTtlSX31d5kZ4OM="
ORG_ID  = 1
INSTANCE = "ITD"

# --- Workgroup & Assignment ---
WORKGROUP       = "SAP_MDM - OTH"
# NOTE: Fixed ASSIGNED_EMAIL hata diya gaya — ab har ticket allocation
# ATTENDANCE.xlsx ke column header (jo ab email IDs hain) se hi
# "Assigned_Engineer_Email" set hota hai (step4_post_tickets.py mein).

# --- Excel / Data File ---
# ATTEND.xlsx mein workgroup-wise sheets hain (e.g. "SAP_MDM - OTH").
# Sirf ATTENDANCE_SHEET wala sheet use hota hai -- baaki sheets ignore.
# Sheet layout: Name | Alignment | email | <date columns P/A...>
# Row 1 = Assignment Ratio (Employee % | Vendor %) -- ratio yahin se
# dynamically read hota hai, config mein hardcode nahi karna.
EXCEL_FILE       = "ATTEND.xlsx"
ATTENDANCE_SHEET = "SAP_MDM - OTH"

# --- Ticket Split ---
TOTAL_TICKETS = 16
# NOTE: EMP_SPLIT ab config mein nahi hai -- Assignment Ratio row se
# (ATTEND.xlsx, ATTENDANCE_SHEET) dynamically read hota hai step2 mein.

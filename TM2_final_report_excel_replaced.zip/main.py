# ============================================================
#  main.py -- Ticket Management System -- Full Auto Flow
#
#  Logic:
#   1. Fetch tickets from API
#   2. Read attendance from ATTENDANCE.xlsx
#   3. New tickets -> assign to present person
#   4. Already assigned tickets:
#        - assignee present -> remain assigned to same person
#        - assignee absent  -> reassign to present person
#   5. Post only tickets that need assignment/reassignment
#
#  Run: python main.py
# ============================================================

from datetime import datetime
from step1_fetch_tickets import fetch_tickets
from step2_attendance import check_attendance
from step3_allocate import allocate_ticket_actions
from step4_post_tickets import post_ticket_actions
from step5_report import create_ticket_assignment_report


def main():
    print("\n" + "*"*55)
    print("   TICKET MANAGEMENT SYSTEM -- Full Auto Flow")
    print("*"*55)

    date = datetime.now().strftime("%d-%m-%Y")
    print(f"\n  Using today's date : {date}")

    # STEP 1: Fetch tickets
    excel_file, ticket_numbers, ticket_rows = fetch_tickets()

    if not ticket_rows:
        print("\n[WARNING] No tickets fetched. Stopping program.")
        return

    print(f"\n  Total Tickets (auto-detected) : {len(ticket_rows)}")

    # STEP 2: Attendance
    present, absent, rows = check_attendance(date)

    if present is None:
        print("\n[ERROR] Attendance not found. Stopping program.")
        return

    # STEP 3: Apply user logic ticket-by-ticket
    actions, kept, skipped = allocate_ticket_actions(ticket_rows, present, rows)

    post_results = []

    # STEP 4: Post only required tickets
    if not actions:
        print("\nNo ticket needs assignment/reassignment. Nothing to post.")
    else:
        confirm = input("\nPost only these required ticket updates via API now? (y/n): ").strip().lower()

        if confirm == "y":
            post_results = post_ticket_actions(actions)
        else:
            print("\nAPI posting skipped.")

    # STEP 5: Final Excel report for every fetched ticket
    create_ticket_assignment_report(ticket_rows, actions, kept, skipped, rows, post_results)

    print("\n" + "*"*55)
    print("   Done!")
    print("*"*55)


if __name__ == "__main__":
    main()

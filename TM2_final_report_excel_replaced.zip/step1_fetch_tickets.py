# ============================================================
#  step1_fetch_tickets.py
#  Fetches the ticket list from the API and saves Excel + JSON.
#  FETCH_STATUS is blank by default so both NEW and Assigned tickets are fetched.
#  Output : tickets_ddmmyy_hhmmss.xlsx          -> full data
#            tickets_summary_ddmmyy_hhmmss.xlsx  -> selected columns only
#            output.json                          -> Raw JSON response
# ============================================================

import requests
import json
import pandas as pd
from datetime import datetime
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP, FETCH_STATUS

# Summary excel should only have these columns (in this order)
SUMMARY_COLUMNS = [
    "Incident ID",
    "Logged Time",
    "Status",
    "Symptom",
    "Workgroup Name",
    "Executive Name",
    "FullCategory",
]


def fetch_tickets(page_size=100):
    """
    Calls the API to fetch assigned tickets.
    Returns: (excel_filename, ticket_number_list, ticket_rows)
    """

    print("\n" + "="*55)
    print("  STEP 1 : Fetching Ticket List from API")
    print("="*55)

    payload = {
        "ServiceName": "IM_GetIncidentList",
        "objCommonParameters": {
            "_ProxyDetails": {
                "AuthType": "APIKey",
                "APIKey": API_KEY,
                "ProxyID": 0,
                "ReturnType": "json",
                "OrgID": ORG_ID,
                "TokenID": ""
            },
            "objIncidentCommonFilter": {
                "WorkgroupName": WORKGROUP,
                "CurrentPageIndex": 0,
                "PageSize": page_size,
                "OrgID": str(ORG_ID),
                "Instance": INSTANCE,
                "Status": FETCH_STATUS,
                "IsWebServiceRequest": True
            }
        }
    }

    try:
        print("  Calling API...")
        response = requests.post(API_URL, json=payload, timeout=30)
        print(f"  Status Code : {response.status_code}")

        # ---- Failure check ----
        if response.status_code != 200:
            print("  [ERROR] API did not return 200. Response:")
            print("    ", response.text[:300])
            return None, [], []

        data = response.json()

        # ---- Raw JSON save ----
        with open("output.json", "w") as f:
            json.dump(data, f, indent=4)
        print("  [OK] Raw JSON saved  -> output.json")

        # ---- Extract tickets ----
        tickets = data.get("OutputObject", {}).get("MyTickets", [])

        if not tickets:
            print("  [WARNING] No tickets found in response.")
            return None, [], []

        print(f"  Total Tickets found : {len(tickets)}")

        # ---- JSON -> DataFrame ----
        df = pd.DataFrame(tickets)
        timestamp = datetime.now().strftime("%d%m%y_%H%M%S")

        # ---- Excel #1 : Full data ----
        excel_filename = f"tickets_{timestamp}.xlsx"
        df.to_excel(excel_filename, index=False)
        print(f"  [OK] Full Excel saved     -> {excel_filename}")

        # ---- Excel #2 : Summary (selected columns only) ----
        missing_cols = [c for c in SUMMARY_COLUMNS if c not in df.columns]
        if missing_cols:
            print(f"  [WARNING] These columns were not in the response (will be blank): {missing_cols}")

        summary_df = df.reindex(columns=SUMMARY_COLUMNS)
        summary_df["Assigned by Bot"] = "Yes"
        summary_filename = f"tickets_summary_{timestamp}.xlsx"
        summary_df.to_excel(summary_filename, index=False)
        print(f"  [OK] Summary Excel saved  -> {summary_filename}")

        # ---- Ticket numbers list ----
        # NOTE: the API's list response uses the column "Incident ID",
        # not "Ticket_No" (that name is only used in the assign/post payload).
        if "Incident ID" in df.columns:
            ticket_numbers = df["Incident ID"].astype(str).tolist()
        else:
            ticket_numbers = []
            print("  [WARNING] 'Incident ID' column not found in DataFrame.")

        return excel_filename, ticket_numbers, tickets

    except requests.exceptions.ConnectionError:
        print("  [ERROR] Could not connect to server. Check network/URL.")
        return None, [], []
    except Exception as e:
        print(f"  [ERROR] Unexpected error: {e}")
        return None, [], []


# ---- Standalone run ----
if __name__ == "__main__":
    excel_file, ticket_numbers, ticket_rows = fetch_tickets()
    if ticket_numbers:
        print(f"\n  Ticket Numbers : {ticket_numbers[:5]} ... (total {len(ticket_numbers)})")

# ============================================================
#  config.py -- All settings in one place
# ============================================================

# --- API Settings ---
API_URL = "http://msilstaging/Webservice/REST/Summit_RESTWCF.svc/RESTService/CommonWS_JsonObjCall"
API_KEY = "sWkL0CqC1bikNDIJvI66eNxPVBMgNTtlSX31d5kZ4OM="
ORG_ID  = 1
INSTANCE = "ITD"

# --- Workgroup & Assignment ---
# This MUST match one sheet name in ATTENDANCE.xlsx, for example:
#   SAP_MDM - OTH
#   SAP_MDM - MM
WORKGROUP       = "SAP_MDM - OTH"
# Blank means fetch all statuses so NEW + Assigned tickets can be checked.
FETCH_STATUS    = ""

# --- Excel / Data File ---
# Code reads attendance + employee/vendor ratio from this file only.
EXCEL_FILE = "ATTENDANCE.xlsx"

# --- Defaults only if Excel ratio is missing ---
DEFAULT_EMP_SPLIT = 0.30
DEFAULT_VEN_SPLIT = 0.70

# ============================================================
#  step5_report.py
#  Creates final ticket assignment decision Excel.
#
#  Output columns required by user:
#    Ticket Number | Status | Last Assigned | Attendance | Current Assigned
#
#  Meaning:
#    - Last Assigned    : person already assigned before this run (API/state)
#    - Attendance       : attendance of last assigned person.
#                         For NEW tickets with no last assignee, it shows
#                         attendance of the newly/current assigned person.
#    - Current Assigned : final person after applying the logic
#                         (same person if present, new person if absent/new)
# ============================================================

from datetime import datetime
import pandas as pd

from step3_allocate import (
    _ticket_no,
    _status,
    _assignee,
    _state_assignee,
    _load_assignment_state,
    _match_person,
)


def _clean(value):
    return "" if value is None else str(value).strip()


def _all_known_emails(rows):
    details = (rows or {}).get("details", {}) or {}
    return list(details.keys())


def _find_email(person, rows):
    """Return email key from attendance rows for an API name/email if possible."""
    person = _clean(person)
    if not person:
        return ""

    details = (rows or {}).get("details", {}) or {}
    emails = list(details.keys())

    # 1) Match against email keys.
    matched = _match_person(person, emails)
    if matched:
        return matched

    # 2) Match against display names.
    names = [info.get("name", "") for info in details.values() if info.get("name")]
    matched_name = _match_person(person, names)
    if matched_name:
        for email, info in details.items():
            if _clean(info.get("name")) == _clean(matched_name):
                return email

    return ""


def _display_person(person, rows):
    """Prefer display name from Excel; fall back to given API/email value."""
    person = _clean(person)
    if not person:
        return ""

    email = _find_email(person, rows)
    if email:
        name = ((rows or {}).get("details", {}) or {}).get(email, {}).get("name", "")
        return _clean(name) or email

    return person


def _attendance(person, rows):
    """Get P/A style attendance from Excel for a name/email."""
    person = _clean(person)
    if not person:
        return ""

    email = _find_email(person, rows)
    if not email:
        return ""

    status = ((rows or {}).get("details", {}) or {}).get(email, {}).get("status", "")
    return _clean(status).lower() if status else ""


def _action_maps(actions):
    by_ticket = {}
    for a in actions or []:
        tno = _clean(a.get("ticket_no"))
        if tno:
            by_ticket[tno] = a
    return by_ticket


def _result_maps(post_results):
    by_ticket = {}
    for r in post_results or []:
        tno = _clean(r.get("Ticket_No"))
        if tno:
            by_ticket[tno] = r
    return by_ticket


def create_ticket_assignment_report(tickets, actions, kept, skipped, rows, post_results=None):
    """
    Creates final report Excel and returns filename.
    This report includes ALL fetched tickets, not only API-posted tickets.
    """

    print("\n" + "="*70)
    print("  STEP 5 : Creating Final Ticket Assignment Report Excel")
    print("="*70)

    state = _load_assignment_state()
    actions_by_ticket = _action_maps(actions)
    results_by_ticket = _result_maps(post_results)

    report_rows = []

    for ticket in tickets or []:
        ticket_no = _ticket_no(ticket)
        status = _status(ticket)
        api_last = _assignee(ticket)
        cached_last = _state_assignee(ticket_no, state) if ticket_no else ""

        # IMPORTANT:
        # If API has current assignee, use it as last assigned.
        # If API is blank but state has previous bot assignment, use state.
        last_assigned_raw = api_last or cached_last

        action = actions_by_ticket.get(str(ticket_no), {})
        planned_current_raw = action.get("email", "")

        if planned_current_raw:
            current_assigned_raw = planned_current_raw
        else:
            current_assigned_raw = last_assigned_raw

        # For NEW ticket with no last assigned, attendance should still show
        # present person's attendance after new assignment (like user's example).
        attendance_source = last_assigned_raw or current_assigned_raw

        report_rows.append({
            "Ticket Number": ticket_no,
            "Status": status,
            "Last Assigned": _display_person(last_assigned_raw, rows),
            "Attendance": _attendance(attendance_source, rows),
            "Current Assigned": _display_person(current_assigned_raw, rows),
        })

    ts = datetime.now().strftime("%d%m%y_%H%M%S")
    report_file = f"ticket_assignment_report_{ts}.xlsx"

    df = pd.DataFrame(report_rows, columns=[
        "Ticket Number",
        "Status",
        "Last Assigned",
        "Attendance",
        "Current Assigned",
    ])

    # Save with readable formatting.
    with pd.ExcelWriter(report_file, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Ticket Report")
        ws = writer.book["Ticket Report"]

        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        header_fill = PatternFill("solid", fgColor="D9EAF7")
        header_font = Font(bold=True, color="000000")
        border = Border(
            left=Side(style="thin", color="BFBFBF"),
            right=Side(style="thin", color="BFBFBF"),
            top=Side(style="thin", color="BFBFBF"),
            bottom=Side(style="thin", color="BFBFBF"),
        )

        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = border

        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.border = border

        widths = {
            "A": 18,
            "B": 18,
            "C": 24,
            "D": 15,
            "E": 24,
        }
        for col, width in widths.items():
            ws.column_dimensions[col].width = width

        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions

    print(f"  [OK] Final report saved -> {report_file}")
    return report_file

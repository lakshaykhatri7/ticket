Ticket Management System - Updated for new ATTENDANCE.xlsx
=============================================================

Run:
  python main.py

Main logic implemented:
1. Fetch tickets from API.
2. Read attendance directly from ATTENDANCE.xlsx using openpyxl.
3. Read Employee/Vendor assignment ratio directly from ATTENDANCE.xlsx.
4. New/unassigned ticket:
   - Assign to a present solver according to Excel ratio.
5. Already assigned ticket:
   - If assigned person is present, keep same assignment. No API update.
   - If assigned person is absent/not solver, reassign to another present solver.
6. Post only the tickets that need assignment/reassignment.

Excel format supported:
- Each workgroup is one sheet, e.g. SAP_MDM - OTH or SAP_MDM - MM.
- Row with "Assignment Ratio" is used for Employee/Vendor ratio.
- Header row has columns like email, Alignment, Status/Solver/Name or date columns.
- If date columns exist, today's date column is used.
- If no date column exists, Status column is used.

Important config:
- In config.py, WORKGROUP must match the sheet name you want to use:
    WORKGROUP = "SAP_MDM - OTH"
  or
    WORKGROUP = "SAP_MDM - MM"

Files:
- main.py              Full flow
- step1_fetch_tickets.py Fetch tickets
- step2_attendance.py Read Excel attendance + ratio
- step3_allocate.py   Apply your ticket logic
- step4_post_tickets.py Post required updates only
- ATTENDANCE.xlsx     Your latest Excel format


IMPORTANT FIX ADDED:
- The program now creates assignment_state.json after a successful API post.
- On the next run, if the API still shows the ticket as blank/new/open, the program checks assignment_state.json and will NOT post the same assignment again.
- Status=Open/New alone is no longer treated as unassigned because many systems keep status Open even after assignment.
- If the saved assignee is present, the ticket is kept and skipped. If that assignee becomes absent, it will be reassigned.

LATEST CHANGE - Final Ticket Report
-----------------------------------
After every run, the program now creates a final Excel report:

  ticket_assignment_report_ddmmyy_hhmmss.xlsx

Report columns:
  Ticket Number
  Status
  Last Assigned
  Attendance
  Current Assigned

Logic used in report:
  - New ticket: Last Assigned blank, Attendance of newly assigned present person, Current Assigned new person
  - Already assigned + present: Last Assigned same, Attendance p, Current Assigned same
  - Already assigned + absent: Last Assigned old person, Attendance a, Current Assigned new present person

Also fixed repeat assignment state saving inside post_ticket_actions().

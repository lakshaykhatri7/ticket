# ============================================================
#  main_demo.py — Full Auto Flow, DEMO MODE
#
#  Same 4 steps as main.py, but forces every step1-4 module to
#  import config_demo.py (mock API + local file) instead of the
#  real config.py. No changes needed in step1-4 themselves.
#
#  BEFORE RUNNING THIS:
#    1. In one terminal: python mock_api_server.py   (leave running)
#    2. In another terminal: python main_demo.py
#
#  See README_DEMO.txt for full instructions.
# ============================================================

import sys
import config_demo

# Make every "from config import ..." inside step1-4 resolve to
# config_demo instead -- this is the only trick needed to demo
# the real pipeline code with fake settings.
sys.modules["config"] = config_demo

from datetime import datetime
from step1_fetch_tickets import fetch_tickets
from step2_attendance    import check_attendance
from step3_allocate      import allocate_tickets
from step4_post_tickets  import post_tickets


def main():
    print("\n" + "*"*60)
    print("   TICKET MANAGEMENT SYSTEM -- DEMO MODE (mock API)")
    print("*"*60)
    print("   Make sure mock_api_server.py is running in another")
    print("   terminal (python mock_api_server.py) before continuing.")
    print("*"*60)

    date = datetime.now().strftime("%d-%m-%Y")
    print(f"\n  Using today's date : {date}")

    # -- STEP 1: API Fetch (mock) --------------------------------
    excel_file, ticket_numbers, ticket_info = fetch_tickets()
    print(f"\n  Total Tickets (auto-detected) : {len(ticket_numbers)}")

    if not ticket_numbers:
        print("\n  No tickets returned -- is mock_api_server.py running?")
        print("  Start it with: python mock_api_server.py")
        return

    # -- STEP 2: Attendance ---------------------------------------
    present, absent, rows = check_attendance(date)

    if present is None:
        print(f"\n  Attendance not found for date '{date}' in ATTEND.xlsx.")
        print("  (The demo sheet only has dates 2026-06-01 to 2026-07-01 --")
        print("   if today is outside that range, edit ATTEND.xlsx or this date.)")
        return

    # -- STEP 3: Allocation -----------------------------------------
    final_assignment, executive_names = allocate_tickets(ticket_info, present, rows)

    if not final_assignment:
        print("\nNo one received any tickets. Stopping demo.")
        return

    # -- STEP 4: Post via mock API -----------------------------------
    confirm = input("\nPost tickets to the MOCK API? (y/n): ").strip().lower()

    if confirm == "y":
        post_tickets(final_assignment, executive_names)
    else:
        print("\nMock API posting skipped.")

    print("\n" + "*"*60)
    print("   Demo Done! Check the generated .xlsx files in this folder.")
    print("*"*60)


if __name__ == "__main__":
    main()

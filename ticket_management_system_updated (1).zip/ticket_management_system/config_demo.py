# ============================================================
#  config_demo.py — DEMO settings, points at the local mock API
#  Use this instead of config.py to run the whole pipeline
#  offline / without real credentials.
#
#  To run the demo: see README_DEMO.txt
# ============================================================

# --- API Settings (local mock server) ---
API_URL  = "http://127.0.0.1:5050/Webservice/REST/Summit_RESTWCF.svc/RESTService/CommonWS_JsonObjCall"
API_KEY  = "DEMO-KEY-NOT-REAL"
ORG_ID   = 1
INSTANCE = "ITD"

# --- Workgroup & Assignment ---
WORKGROUP = "SAP_MDM - OTH"

# --- Excel / Data File ---
EXCEL_FILE       = "ATTEND.xlsx"
ATTENDANCE_SHEET = "SAP_MDM - OTH"

# --- Ticket Split ---
TOTAL_TICKETS = 16
# EMP_SPLIT is read dynamically from ATTEND.xlsx's Assignment Ratio row

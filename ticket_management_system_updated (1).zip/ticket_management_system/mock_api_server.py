# ============================================================
#  mock_api_server.py
#  A tiny local Flask server that fakes the two API calls used
#  by this project, so the whole pipeline can be demoed with
#  ZERO network/credentials:
#
#    1. IM_GetIncidentList        (step1_fetch_tickets.py)
#    2. IM_LogOrUpdateIncident    (step4_post_tickets.py)
#
#  Run this FIRST, in its own terminal:
#      python mock_api_server.py
#  It starts on http://127.0.0.1:5050
#
#  Then run main.py / step1 / step4 as normal -- config_demo.py
#  points API_URL at this local server instead of the real one.
# ============================================================

from flask import Flask, request, jsonify
import random

app = Flask(__name__)

# ---- Fake ticket pool the mock "database" hands out ----
# A realistic mix: some New, some already Assigned to real people
# from ATTEND.xlsx (so step3's name-matching has something to do).
FAKE_TICKETS = [
    {"Incident ID": "653501", "Status": "New",      "Executive Name": "",
     "Symptom": "SAP login failure",            "Workgroup Name": "SAP_MDM - OTH",
     "FullCategory": "Access > Login"},
    {"Incident ID": "653502", "Status": "New",      "Executive Name": "",
     "Symptom": "MDM sync error",                "Workgroup Name": "SAP_MDM - OTH",
     "FullCategory": "Data > Sync"},
    {"Incident ID": "653504", "Status": "Assigned", "Executive Name": "Shreyansh Sharma",
     "Symptom": "Material master incorrect UOM", "Workgroup Name": "SAP_MDM - OTH",
     "FullCategory": "Data > Master"},
    {"Incident ID": "653505", "Status": "Assigned", "Executive Name": "Rahil Rathi",
     "Symptom": "Pricing condition mismatch",    "Workgroup Name": "SAP_MDM - OTH",
     "FullCategory": "Data > Pricing"},
    {"Incident ID": "653507", "Status": "Assigned", "Executive Name": "Lipasa Dash",
     "Symptom": "Plant data not replicating",    "Workgroup Name": "SAP_MDM - OTH",
     "FullCategory": "Data > Replication"},
]

# Common fields every ticket gets, so the full-excel export looks realistic
for t in FAKE_TICKETS:
    t.setdefault("Logged Time", "2026-06-30 09:00:00")


@app.route("/Webservice/REST/Summit_RESTWCF.svc/RESTService/CommonWS_JsonObjCall", methods=["POST"])
def common_ws_call():
    body = request.get_json(force=True, silent=True) or {}
    service = body.get("ServiceName", "")

    # ---- 1) Ticket list fetch ----
    if service == "IM_GetIncidentList":
        params = body.get("objCommonParameters", {}).get("objIncidentCommonFilter", {})
        page_size = params.get("PageSize", 100)

        # Demo mock always returns the full fake pool (5 tickets) regardless
        # of the Status filter sent, so a fetch always yields 5 tickets.
        tickets = FAKE_TICKETS[:page_size]

        print(f"  [mock-api] IM_GetIncidentList -> returning {len(tickets)} ticket(s)")
        return jsonify({
            "OutputObject": {"MyTickets": tickets},
            "Message": "OK",
            "ErrorCode": 0
        }), 200

    # ---- 2) Ticket assignment / update ----
    if service == "IM_LogOrUpdateIncident":
        ticket_json = (
            body.get("objCommonParameters", {})
                .get("incidentParamsJSON", {})
                .get("IncidentContainerJsonObj", {})
                .get("Ticket", {})
        )
        ticket_no = ticket_json.get("Ticket_No")
        email     = ticket_json.get("Assigned_Engineer_Email")

        # Simulate an occasional failure (1 in 12) so the demo shows
        # both Success and Failed rows, like the real API would.
        if random.randint(1, 12) == 1:
            print(f"  [mock-api] IM_LogOrUpdateIncident -> ticket {ticket_no} SIMULATED FAILURE")
            return jsonify({"Message": "Simulated failure", "ErrorCode": 1}), 500

        print(f"  [mock-api] IM_LogOrUpdateIncident -> ticket {ticket_no} assigned to {email}")
        return jsonify({"Message": "Updated", "ErrorCode": 0}), 200

    # ---- 3) SR list (from the earlier sr_tickets module, in case it's tested too) ----
    if service == "SR_GetServiceRequestList":
        print("  [mock-api] SR_GetServiceRequestList -> returning empty list (demo)")
        return jsonify({"OutputObject": {"ServiceRequests": []}, "Message": "OK"}), 200

    return jsonify({"Message": f"Unknown ServiceName: {service}", "ErrorCode": 99}), 400


if __name__ == "__main__":
    print("\n" + "="*60)
    print("  MOCK API SERVER running at http://127.0.0.1:5050")
    print("  Simulates IM_GetIncidentList + IM_LogOrUpdateIncident")
    print("  Press CTRL+C to stop.")
    print("="*60 + "\n")
    app.run(host="127.0.0.1", port=5050, debug=False)

# ============================================================
#  step3_allocate.py
#  Decides who gets each ticket, based on the ticket's Status.
#
#  Rule:
#    Status = "New"
#       -> goes into the Employee/Vendor split (ratio read
#          dynamically from ATTEND.xlsx's "Assignment Ratio" row,
#          via step2._read_ratio()), shared equally among the
#          Present people in each role.
#
#    Status = "Assigned"
#       -> The API's "Executive Name" is matched ONLY against the
#          LOCAL-PART of each person's email in ATTEND.xlsx's
#          "email" column (text before the @). The "Name" column
#          is NEVER used for this -- it exists purely for human
#          reference in the sheet.
#       -> If the matched email is Present today, the ticket stays
#          with that email.
#       -> If Absent, the ticket is handed to another Present
#          person in the SAME role (Employee stays Employee,
#          Vendor stays Vendor), split equally among them.
#       -> If no email matches at all, the ticket is skipped and
#          printed as a warning so it can be checked manually.
#
#    Any other / unrecognised Status
#       -> skipped, printed clearly as a warning so it can be
#          checked manually.
# ============================================================

from step2_attendance import _read_ratio


def _normalize(text):
    """
    Normalizes a string into an order-independent set of words, so
    'Neha Aswal' (Executive Name) and 'JKTECH_Neha.Aswal' (email
    local-part) can be compared even with different formatting/order.
    """
    text = str(text).strip()
    if "_" in text:
        # drop a vendor-company prefix, e.g. JKTECH_ / DTL_ / MYSOFTLABS_
        text = text.split("_")[-1]
    text = text.replace(".", " ").replace("_", " ")
    words = [w.lower() for w in text.split() if w]
    return tuple(sorted(words))


def _build_email_lookup(rows):
    """
    Builds { normalized_email_localpart : {"email", "role", "present"} }
    using ALL attendance rows (present + absent) from step2, keyed
    ONLY by each person's email local-part -- the "Name" column in
    ATTEND.xlsx is never read here.

    `rows` is the flat dict from step2.check_attendance:
        { email: {"status": "P"/"A", "role": "Employee"/"Vendor", "name": ..} }
    """
    lookup = {}
    role_map = {"employee": "Emp", "vendor": "Ven"}

    for email, info in (rows or {}).items():
        role = role_map.get(str(info.get("role", "")).strip().lower())
        if role is None:
            continue
        present = str(info.get("status", "")).strip().upper() == "P"

        local_part = email.split("@")[0]
        key = _normalize(local_part)
        if key:
            lookup[key] = {"email": email, "role": role, "present": present}

    return lookup


def _split_equally(people, share):
    """
    Equal split of `share` items among `people` (list of emails).
    Remainder is handed out to the first ones, one by one.
    Returns { email : count }.
    """
    result = {}
    if not people or share <= 0:
        return result
    for i, email in enumerate(people):
        result[email] = share // len(people) + (1 if i < share % len(people) else 0)
    return result


def _hand_out(ticket_pool, people, final_assignment, label):
    """
    Splits ticket_pool equally among people and records the exact
    ticket numbers each person gets into final_assignment.
    """
    if not ticket_pool:
        return
    if not people:
        print(f"  No Present {label} -- {len(ticket_pool)} ticket(s) skipped: {ticket_pool}")
        return

    counts = _split_equally(people, len(ticket_pool))
    idx = 0
    for email, count in counts.items():
        chunk = ticket_pool[idx: idx + count]
        idx += count
        if not chunk:
            continue
        final_assignment.setdefault(email, []).extend(chunk)
        print(f"  {email:<38} <- {chunk}")


def allocate_tickets(ticket_info, present, rows):
    """
    Args:
        ticket_info (dict): { ticket_no : {"Status":.., "Executive Name":..} }
                             -- from step1
        present (dict)    : { "Emp":[{email,solver}], "Ven":[...] }
                             -- from step2 (Present people only)
        rows (dict)       : flat { email: {"status":P/A, "role":Employee/Vendor,
                                            "name":..} } -- from step2 (ALL people)

    Returns:
        final_assignment (dict)  : { email : [ticket_no, ticket_no, ...] }
        executive_names (dict)   : { ticket_no : original "Executive Name"
                                      from the API, kept for reference only
                                      in the output Excel }
    """

    print("\n" + "="*55)
    print("  STEP 3 : Ticket Allocation")
    print("="*55)

    emp_split = _read_ratio()
    print(f"  Using Assignment Ratio -> Employee {emp_split:.0%} / Vendor {1 - emp_split:.0%}")
    print("  NOTE: Matching uses ONLY the email local-part -- the 'Name'")
    print("        column in ATTEND.xlsx is for reference only, never used.")

    email_lookup = _build_email_lookup(rows)

    executive_names = {
        t: str(info.get("Executive Name", "")).strip()
        for t, info in ticket_info.items()
    }

    new_tickets        = []              # Status == New
    direct_assign      = {}              # ticket_no -> email (Assigned + Present)
    reassign_pool       = {"Emp": [], "Ven": []}   # Assigned + Absent
    unmatched_tickets   = []             # Assigned, but email couldn't be matched
    skipped_tickets     = []             # any other/unknown status

    for ticket_no, info in ticket_info.items():
        status = str(info.get("Status", "")).strip().lower()
        exec_name = info.get("Executive Name", "")

        if status == "new":
            new_tickets.append(ticket_no)

        elif status == "assigned":
            match = email_lookup.get(_normalize(exec_name))

            if not match:
                unmatched_tickets.append(ticket_no)
                print(f"  [WARN] Ticket {ticket_no}: assigned executive "
                      f"'{exec_name}' -- no matching email found in "
                      f"ATTEND.xlsx -- skipped.")
                continue

            if match["present"]:
                direct_assign[ticket_no] = match["email"]
            else:
                reassign_pool[match["role"]].append(ticket_no)

        else:
            skipped_tickets.append(ticket_no)
            print(f"  [WARN] Ticket {ticket_no}: unrecognised Status "
                  f"'{info.get('Status')}' -- skipped.")

    final_assignment = {}

    # ---- 1) Already-Assigned tickets, person Present -> stays put ----
    print(f"\n  -- Assigned tickets, person Present (stays as-is) --------")
    if direct_assign:
        for ticket_no, email in direct_assign.items():
            final_assignment.setdefault(email, []).append(ticket_no)
            print(f"  Ticket {ticket_no:<10} -> stays with {email}")
    else:
        print("  None")

    # ---- 2) Already-Assigned tickets, person Absent -> reassign, same role ----
    print(f"\n  -- Assigned tickets, person Absent (reassigned, same role) --")
    any_reassigned = False
    for role, tickets in reassign_pool.items():
        if not tickets:
            continue
        any_reassigned = True
        label = "Employees" if role == "Emp" else "Vendors"
        present_people = [p["email"] for p in present[role]]
        print(f"  {label} : {tickets}")
        _hand_out(tickets, present_people, final_assignment, label)
    if not any_reassigned:
        print("  None")

    # ---- 3) New tickets -> dynamic Employee/Vendor split ----
    total_new = len(new_tickets)
    emp_total = round(total_new * emp_split)
    ven_total = total_new - emp_total

    print(f"\n  -- New tickets : dynamic split (Emp {emp_split:.0%} | Ven {1 - emp_split:.0%}) ----------")
    print(f"  Total New Tickets : {total_new}")
    print(f"  Employee Share    : {emp_total}")
    print(f"  Vendor Share      : {ven_total}")

    pool = list(new_tickets)
    idx = 0
    for role, share in [("Emp", emp_total), ("Ven", ven_total)]:
        label = "Employees" if role == "Emp" else "Vendors"
        chunk = pool[idx: idx + share]
        idx += share
        present_people = [p["email"] for p in present[role] if p["solver"] == "Y"]
        print(f"\n  -- {label} --")
        _hand_out(chunk, present_people, final_assignment, label)

    # ---- FINAL SUMMARY ----
    print(f"\n  -- FINAL ALLOCATION --------------------------")
    if final_assignment:
        for email, tickets in final_assignment.items():
            print(f"  {email:<38} : {len(tickets)} ticket(s) {tickets}")
    else:
        print("  Nobody received any tickets.")

    if unmatched_tickets:
        print(f"\n  Unmatched (Executive Name not found via email) : {unmatched_tickets}")
    if skipped_tickets:
        print(f"  Skipped (unrecognised Status)                  : {skipped_tickets}")

    return final_assignment, executive_names


# ---- Standalone run ----
if __name__ == "__main__":
    # Test data matching the ATTEND.xlsx ("SAP_MDM - OTH") sample rows
    sample_ticket_info = {
        "653501": {"Status": "New",      "Executive Name": ""},
        "653502": {"Status": "New",      "Executive Name": ""},
        "653503": {"Status": "New",      "Executive Name": ""},
        "653504": {"Status": "Assigned", "Executive Name": "Shreyansh Sharma"},  # present, employee
        "653505": {"Status": "Assigned", "Executive Name": "Rahil Rathi"},       # present, vendor
        "653506": {"Status": "Assigned", "Executive Name": "Lipasa Dash"},       # absent, employee -> reassigned
        "653507": {"Status": "New",      "Executive Name": ""},
    }
    sample_present = {
        "Emp": [{"email": "shreyansh.sharma@maruti.co.in", "solver": "Y"},
                {"email": "sumit.bhardwaj@maruti.co.in", "solver": "Y"}],
        "Ven": [{"email": "rahil.rathi@kpmg.com", "solver": "Y"},
                {"email": "sohani.singh@kpmg.com", "solver": "Y"}]
    }
    sample_rows = {
        "shreyansh.sharma@maruti.co.in": {"status": "P", "role": "Employee", "name": "Shreyansh"},
        "sumit.bhardwaj@maruti.co.in": {"status": "P", "role": "Employee", "name": "Sumit"},
        "lipasa.dash@maruti.co.in": {"status": "A", "role": "Employee", "name": "Lipasa"},
        "rahil.rathi@kpmg.com": {"status": "P", "role": "Vendor", "name": "Rahil"},
        "sohani.singh@kpmg.com": {"status": "P", "role": "Vendor", "name": "Sohani"},
    }
    allocate_tickets(sample_ticket_info, sample_present, sample_rows)

============================================================
  TICKET MANAGEMENT SYSTEM - Project Guide
============================================================

-- PROJECT FILES ------------------------------------------

  config.py              -> Change all settings here
  main.py                -> Runs the full flow (run this one)

  step1_fetch_tickets.py -> Fetches tickets from API -> saves 2 Excel + JSON
  step2_attendance.py    -> Present / Absent from ATTEND.xlsx,
                             also reads the Employee/Vendor split
                             ratio dynamically from the sheet
  step3_allocate.py      -> New tickets: dynamic ratio split.
                             Assigned tickets: stays with current
                             person if Present (matched by EMAIL
                             only), else reassigned within the
                             same role
  step4_post_tickets.py  -> Assigns tickets via API (by email)

  guessno.py              -> 4-Digit Guessing Game (bonus!)

-- SETUP ----------------------------------------------------

  1. Install Python (3.8+)
  2. Install libraries:
       pip install requests pandas openpyxl

  3. Open config.py and set:
       API_URL           -> server address
       API_KEY           -> your API key
       EXCEL_FILE         -> "ATTEND.xlsx"
       ATTENDANCE_SHEET  -> "SAP_MDM - OTH" (the only sheet used)
       TOTAL_TICKETS      -> not used by step3 -- kept only for any
                             old/manual testing.

  NOTE: There is no fixed EMP_SPLIT / ASSIGNED_EMAIL setting.
  The Employee/Vendor ratio is read live from ATTEND.xlsx's
  "Assignment Ratio" row each run. Each ticket is assigned to
  the actual email of the person it was allocated to.

-- ATTENDANCE FILE FORMAT (ATTEND.xlsx) -----------------

  Sheet used: config.ATTENDANCE_SHEET (currently "SAP_MDM - OTH")
  Other sheets in the file are ignored.

  Layout (people in ROWS, dates in COLUMNS):

    Row 1 : <blank>   | Employee | Vendor | ...
    Row 2 : "Assignment Ratio" | <emp %> | <ven %> | ...
    Row 3 : <blank>
    Row 4 : "Name" | "Alignment" | "email" | <date1> | <date2> | ...
    Row 5+: <name> | Employee/Vendor | <email> | P/A | P/A | ...

  "Alignment" column (Employee/Vendor) is the role used for the
  split. "email" column must be the person's actual, complete
  email address -- this is what gets sent to the API as
  "Assigned_Engineer_Email" when a ticket is posted, so a typo
  or incomplete email will cause that person's assignment to fail.

  IMPORTANT: The "Name" column is for HUMAN REFERENCE ONLY. It
  is never read by any matching logic in the code -- all matching
  against the API's "Executive Name" is done purely against the
  "email" column's local-part (the text before @).

  Everyone marked "P" (Present) for today's date is eligible to
  receive tickets (treated as a solver -- there is no separate
  Solver column).

-- HOW TICKETS ARE ALLOCATED (IMPORTANT) ------------------------

  Status = "New"
    -> Goes into the Employee/Vendor split pool, using the ratio
       read live from ATTEND.xlsx's "Assignment Ratio" row
       (e.g. 20% Employee / 80% Vendor).
    -> Split equally among today's Present people within each role.

  Status = "Assigned"
    -> The API's "Executive Name" (e.g. "Neha Aswal") is matched
       ONLY against the LOCAL-PART of each person's email in
       ATTEND.xlsx (e.g. "JKTECH_Neha.Aswal" from
       JKTECH_Neha.Aswal@maruti.co.in). The "Name" column is
       NEVER used for this match.
    -> If that matched email is Present today, the ticket stays
       with them, unchanged.
    -> If that matched email is Absent today, the ticket is
       reassigned to another Present person in the SAME role
       (Employee -> Employee, Vendor -> Vendor), split equally
       if there are multiple such tickets/people.
    -> If no email can be matched to the Executive Name at all,
       the ticket is skipped and printed as a warning, so it can
       be checked manually.

  Any other / unrecognised Status
    -> Skipped, printed as a warning -- not auto-allocated.

  "Executive Name" from the API is also carried through as a
  reference-only label -- it is written into the Step 4 output
  Excel as "Executive_Name (Previous)" so you can see who the
  ticket used to belong to.

-- HOW TO RUN -------------------------------------------------

  Run the whole system at once:
    python main.py

  Run steps individually:
    python step1_fetch_tickets.py
    python step2_attendance.py
    python step3_allocate.py
    python step4_post_tickets.py

  Game:
    python guessno.py

  NOTE: No date needs to be typed in -- main.py and standalone
  step2_attendance.py both automatically use today's system date.

  For a fully offline demo (no real API/credentials needed), see
  README_DEMO.txt.

-- OUTPUT FILES -----------------------------------------------

  tickets_ddmmyy_hhmmss.xlsx           -> Step 1: full API data
  tickets_summary_ddmmyy_hhmmss.xlsx   -> Step 1: Incident ID, Logged Time,
                                          Status, Symptom, Workgroup Name,
                                          Executive Name, FullCategory,
                                          Assigned by Bot
  output.json                           -> Step 1: raw JSON response
  assignment_result_ddmmyy_hhmmss.xlsx -> Step 4: Ticket_No,
                                          Executive_Name (Previous), Email,
                                          Status_Code, Result,
                                          Assigned by Bot, Time

-- RULES (SUMMARY) -----------------------------------------------

  - "New" tickets -> dynamic Employee/Vendor ratio split, among
    today's Present people
  - "Assigned" tickets -> stays if matched email is Present;
    reassigned within the same role if Absent
  - Matching uses ONLY the email local-part -- never the "Name"
    column
  - Unmatched Executive Names -> skipped, flagged as a warning
  - Only people marked Present ("P") today get tickets
  - If no one is Present in a role, that role's tickets are
    skipped (with a warning) until someone is
  - Every output Excel includes an "Assigned by Bot" column
  - All terminal output is in English

============================================================

============================================================
  DEMO MODE — Run the full pipeline with a fake API
============================================================

This lets you run the ENTIRE ticket management flow (fetch ->
attendance -> allocate -> post) on your own machine with NO
real API, NO credentials, and NO network needed. A small local
Flask server fakes the two API calls the real system uses.

------------------------------------------------------------
FILES ADDED FOR THE DEMO
------------------------------------------------------------
  mock_api_server.py   -> fake local API (run this first)
  config_demo.py        -> points API_URL at the mock server
  main_demo.py           -> runs steps 1-4 using config_demo

  (step1_fetch_tickets.py, step2_attendance.py,
   step3_allocate.py, step4_post_tickets.py are UNCHANGED --
   the demo just points them at fake settings.)

------------------------------------------------------------
ONE-TIME SETUP
------------------------------------------------------------
  pip install flask requests pandas openpyxl

------------------------------------------------------------
HOW TO RUN
------------------------------------------------------------
Open TWO terminals in this folder.

TERMINAL 1 — start the fake API and leave it running:
  python mock_api_server.py

  You should see:
    MOCK API SERVER running at http://127.0.0.1:5050

TERMINAL 2 — run the demo pipeline:
  python main_demo.py

  This will:
    1. Fetch 5 fake tickets from the mock API (mix of New
       and Assigned, with full names matching real people's
       email local-parts in ATTEND.xlsx -- e.g. "Rahil Rathi"
       matches rahil.rathi@kpmg.com -- so you can see the
       email-based matching work, including a reassignment
       case since Lipasa Dash is marked Absent today)
    2. Read today's attendance from ATTEND.xlsx
       (sheet "SAP_MDM - OTH")
    3. Allocate tickets using the same logic as production:
       - Assigned + present -> stays
       - Assigned + absent -> reassigned, same role (matched
         purely by EMAIL local-part, never the "Name" column)
       - New -> split by the dynamic ratio (20/80) from the sheet
    4. Ask "Post tickets to the MOCK API? (y/n)" — answer "y"
       to see it actually call the mock server and get back
       Success/Failed results (it randomly simulates 1-in-12
       failures so you see both outcomes, like a real API).

------------------------------------------------------------
OUTPUT FILES (generated in this folder after running)
------------------------------------------------------------
  tickets_ddmmyy_hhmmss.xlsx          -> full fetched ticket data
  tickets_summary_ddmmyy_hhmmss.xlsx  -> summary columns only
  output.json                          -> raw mock API response
  assignment_result_ddmmyy_hhmmss.xlsx -> Step 4 post results

------------------------------------------------------------
NOTE ON DATES
------------------------------------------------------------
ATTEND.xlsx only has attendance data for 2026-06-01 through
2026-07-01. If you run this after that range, step2 will say
"Date not found" — just edit ATTEND.xlsx to add today's date
as a new column, or change the date check inside main_demo.py
for testing.

------------------------------------------------------------
GOING BACK TO THE REAL API
------------------------------------------------------------
Demo mode never touches config.py or main.py — your real
production files are untouched. To run for real:
  python main.py
(uses config.py, the actual API_URL/API_KEY)
============================================================

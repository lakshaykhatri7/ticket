# ============================================================
#  step1_fetch_sr.py
#  Fetches the Service Request (SR) list from the API and saves Excel + JSON.
#  Mirrors step1_fetch_tickets.py (which fetches Incidents) but uses the
#  SR_GetServiceRequestList service and its objSR_SearchFilterParam block.
#
#  Output : sr_all_raw_ddmmyy_hhmmss.xlsx     -> ALL fetched tickets (unfiltered, all workgroups)
#            sr_ddmmyy_hhmmss.xlsx             -> full data, filtered to our workgroup only
#            sr_summary_ddmmyy_hhmmss.xlsx     -> selected columns, filtered to our workgroup only
#            output_sr.json                    -> Raw JSON response
# ============================================================

import requests
import json
import pandas as pd
from datetime import datetime
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP, FETCH_STATUS

# Adjust these to match the actual field names returned by SR_GetServiceRequestList
SUMMARY_COLUMNS = [
    "SR ID",
    "Logged Time",
    "Status",
    "Symptom",
    "Workgroup Name",
    "Executive Name",
    "FullCategory",
]


def fetch_service_requests(page_size=100, executive=1, category=None, catalog_name=None):
    """
    Calls the SR_GetServiceRequestList API to fetch service requests.
    Returns: (excel_filename, sr_number_list, sr_rows)
    """

    print("\n" + "=" * 55)
    print("  STEP 1 : Fetching Service Request List from API")
    print("=" * 55)

    filter_params = {
        "Executive": executive,
        # "WorkGroupID": 114,
        "Assigned_WorkGroup_Name": WORKGROUP,
        "CurrentPageIndex": 0,
        "PageSize": page_size,
        "OrgID": str(ORG_ID),
        "Instance": INSTANCE,
        "Status": FETCH_STATUS,
        "IsWebServiceRequest": True,
    }

    # Optional filters - only added if explicitly passed in
    if category:
        filter_params["Category"] = category
    if catalog_name:
        filter_params["CatalogName"] = catalog_name

    payload = {
        "ServiceName": "SR_GetServiceRequestList",
        "objCommonParameters": {
            "_ProxyDetails": {
                "AuthType": "APIKEY",
                "APIKey": API_KEY,
                "TokenID": "",
                "OrgID": str(ORG_ID),
                "ReturnType": "JSON",
                "ProxyID": 0,
            },
            "objSR_SearchFilterParam": filter_params,
        },
    }

    try:
        print("  Calling API...")
        response = requests.post(API_URL, json=payload, timeout=30)
        print(f"  Status Code : {response.status_code}")

        # ---- Failure check ----
        if response.status_code != 200:
            print("  [ERROR] API did not return 200. Response:")
            print("    ", response.text[:300])
            return None, [], []

        data = response.json()

        # ---- Raw JSON save ----
        with open("output_sr.json", "w") as f:
            json.dump(data, f, indent=4)
        print("  [OK] Raw JSON saved  -> output_sr.json")

        # ---- DEBUG: show the actual response shape so we can find the real keys ----
        print("\n  [DEBUG] Top-level keys in response:", list(data.keys()))
        output_obj = data.get("OutputObject", {})
        if isinstance(output_obj, dict):
            print("  [DEBUG] Keys inside OutputObject:", list(output_obj.keys()))
        else:
            print(f"  [DEBUG] OutputObject is type {type(output_obj)}, not a dict. Value: {str(output_obj)[:300]}")
        for err_key in ("ErrorMessage", "ExceptionMessage", "Message", "StatusMessage", "IsError", "IsSuccess"):
            if err_key in data:
                print(f"  [DEBUG] {err_key} = {data.get(err_key)}")
            if isinstance(output_obj, dict) and err_key in output_obj:
                print(f"  [DEBUG] OutputObject.{err_key} = {output_obj.get(err_key)}")

        # ---- Extract service requests ----
        # NOTE: "MyServiceRequests" is an unconfirmed guess. Auto-detect a list-valued
        # key inside OutputObject as a fallback so this doesn't silently return empty.
        sr_list = []
        if isinstance(output_obj, dict):
            sr_list = output_obj.get("MyServiceRequests", [])
            if not sr_list:
                for key, value in output_obj.items():
                    if isinstance(value, list) and value:
                        print(f"  [AUTO-DETECT] Found list data under OutputObject['{key}'] "
                              f"with {len(value)} item(s) - using this instead of 'MyServiceRequests'.")
                        sr_list = value
                        break

        if not sr_list:
            print("  [WARNING] No service requests found in response.")
            print("  [HINT] Open output_sr.json and check: (1) did the call actually")
            print("         succeed / return an error message, (2) is OutputObject empty")
            print("         because filters (Assigned_WorkGroup_Name / Instance / Status)")
            print("         matched nothing real, (3) is the data nested under a key")
            print("         other than OutputObject entirely.")
            return None, [], []

        print(f"  Total Service Requests found (before workgroup filter) : {len(sr_list)}")

        # ---- Excel #1 : RAW (ALL workgroups, unfiltered) ----
        # Saved first, before any filtering, so you always have a record of
        # exactly what the API returned - useful for debugging the workgroup
        # filter issue too.
        timestamp = datetime.now().strftime("%d%m%y_%H%M%S")
        raw_df = pd.DataFrame(sr_list)
        raw_excel_filename = f"sr_all_raw_{timestamp}.xlsx"
        raw_df.to_excel(raw_excel_filename, index=False)
        print(f"  [OK] RAW Excel saved (all workgroups, unfiltered) -> {raw_excel_filename}")

        # ---- CLIENT-SIDE WORKGROUP FILTER ----
        # The API's Assigned_WorkGroup_Name filter has been observed NOT reliably
        # filtering server-side (it returns other workgroups' data too). As a
        # safety net, filter the results down to WORKGROUP here using whatever
        # workgroup-name-like field the response actually contains.
        WORKGROUP_FIELD_CANDIDATES = [
            "Assigned_WorkGroup_Name", "Workgroup Name", "WorkgroupName",
            "Workgroup", "Assigned Workgroup", "AssignedWorkGroupName",
        ]
        wg_field = None
        if sr_list:
            sample = sr_list[0]
            wg_field = next((f for f in WORKGROUP_FIELD_CANDIDATES if f in sample), None)

        if wg_field:
            found_workgroups = sorted({str(row.get(wg_field, "")).strip() for row in sr_list})
            print(f"  [DEBUG] Workgroups present in raw response (field='{wg_field}'): {found_workgroups}")

            filtered = [row for row in sr_list if str(row.get(wg_field, "")).strip() == str(WORKGROUP).strip()]

            if len(filtered) != len(sr_list):
                print(f"  [WARNING] API returned {len(sr_list)} SR(s) across multiple workgroups "
                      f"even though Assigned_WorkGroup_Name='{WORKGROUP}' was requested. "
                      f"Filtering client-side down to {len(filtered)} matching SR(s).")
            sr_list = filtered
        else:
            print("  [WARNING] Could not find a workgroup-name field in the response to "
                  "client-side filter on. Returning all fetched SRs UNFILTERED - please "
                  "check output_sr.json / the raw Excel for the correct field name and "
                  "share it so it can be added to WORKGROUP_FIELD_CANDIDATES.")

        if not sr_list:
            print("  [WARNING] No service requests remained after workgroup filtering.")
            return None, [], []

        print(f"  Total Service Requests found (after workgroup filter, our workgroup only) : {len(sr_list)}")

        # ---- JSON -> DataFrame (filtered - our workgroup only) ----
        df = pd.DataFrame(sr_list)

        # ---- Excel #2 : Full data, FILTERED to our workgroup only ----
        excel_filename = f"sr_{timestamp}.xlsx"
        df.to_excel(excel_filename, index=False)
        print(f"  [OK] Full Excel saved (our workgroup only) -> {excel_filename}")

        # ---- Excel #3 : Summary (selected columns only), FILTERED ----
        missing_cols = [c for c in SUMMARY_COLUMNS if c not in df.columns]
        if missing_cols:
            print(f"  [WARNING] These columns were not in the response (will be blank): {missing_cols}")

        summary_df = df.reindex(columns=SUMMARY_COLUMNS)
        summary_df["Assigned by Bot"] = "Yes"

        # ---- SR_Ticket_ID : numeric part only, e.g. "SR231472" -> "231472" ----
        if "SR ID" in summary_df.columns:
            summary_df["SR_Ticket_ID"] = (
                summary_df["SR ID"]
                .astype(str)
                .str.strip()
                .str.upper()
                .str.lstrip("SR")   # removes leading "SR" (case-insensitive after .upper())
                .str.strip()        # clean any leftover whitespace
            )
        else:
            summary_df["SR_Ticket_ID"] = ""
            print("  [WARNING] 'SR ID' column not found -- SR_Ticket_ID column will be blank.")

        summary_filename = f"sr_summary_{timestamp}.xlsx"
        summary_df.to_excel(summary_filename, index=False)
        print(f"  [OK] Summary Excel saved (our workgroup only) -> {summary_filename}")

        # ---- SR numbers list ----
        # NOTE: "SR ID" is an unconfirmed guess. Try common variants, and if none
        # match, print the real column list so we can pick the right one.
        ID_CANDIDATES = ["SR ID", "SR_No", "SR No", "ServiceRequestID", "Service Request ID", "SRNo", "ID"]
        id_col = next((c for c in ID_CANDIDATES if c in df.columns), None)

        if id_col:
            sr_numbers = df[id_col].astype(str).tolist()
            if id_col != "SR ID":
                print(f"  [AUTO-DETECT] Using '{id_col}' as the SR ID column (not 'SR ID').")
        else:
            sr_numbers = []
            print("  [WARNING] None of the expected ID columns found.")
            print(f"  [DEBUG] Actual columns in response: {list(df.columns)}")

        return excel_filename, sr_numbers, sr_list

    except requests.exceptions.ConnectionError:
        print("  [ERROR] Could not connect to server. Check network/URL.")
        return None, [], []
    except Exception as e:
        print(f"  [ERROR] Unexpected error: {e}")
        return None, [], []


# ---- Standalone run ----
if __name__ == "__main__":
    excel_file, sr_numbers, sr_rows = fetch_service_requests()
    if sr_numbers:
        print(f"\n  SR Numbers : {sr_numbers[:5]} ... (total {len(sr_numbers)})")

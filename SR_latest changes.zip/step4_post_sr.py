# ============================================================
#  step4_post_sr.py
#  Assigns allocated Service Requests to each person's email via the API.
#
#  *** IMPORTANT / UNCONFIRMED ***
#  Your uploaded project only contained the Incident update payload
#  ("IM_LogOrUpdateIncident"). No SR "update/assign" payload sample was
#  provided (only the SR *list* payload, SR_GetServiceRequestList).
#
#  The ServiceName and field names below ("SR_LogOrUpdateServiceRequest",
#  "srParamsJSON", "SRContainerJsonObj", "SR_No", etc.) are a BEST-GUESS
#  mirror of the Incident update payload structure. They are NOT confirmed
#  against your actual backend and will very likely need correction once
#  you have (or your API team can provide) a real "update/assign SR" sample
#  payload. Please verify:
#    1. The exact ServiceName for updating/assigning an SR.
#    2. The exact wrapper key (equivalent to "incidentParamsJSON").
#    3. The exact field name for the SR number (equivalent to "Ticket_No").
#    4. The exact field name for the assignee email.
#
#  Everything else in this file (state caching, Excel result export,
#  error handling) mirrors step4_post_tickets.py exactly.
#
#  Output: sr_assignment_result_ddmmyy_hhmmss.xlsx
# ============================================================

import glob
import requests
import pandas as pd
from datetime import datetime
import json
import os
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP

ASSIGNMENT_STATE_FILE = "assignment_state_sr.json"


def _get_sr_ticket_id(sr_no):
    """
    Looks up the SR_Ticket_ID (numeric part, e.g. 231472 from SR231472)
    from the LATEST sr_summary_*.xlsx file in the current directory.

    The sr_summary file is written by step1_fetch_sr.py during the same run,
    so it always reflects the tickets fetched in this execution.

    Returns the numeric ID as a string, or sr_no itself as a fallback so
    the payload always has something sensible in IncidentTicketID.
    """
    # Find the most recently modified sr_summary_*.xlsx file
    files = glob.glob("sr_summary_*.xlsx")
    if not files:
        print(f"  [WARN] No sr_summary_*.xlsx found -- using raw sr_no '{sr_no}' as IncidentTicketID.")
        return sr_no

    latest_file = max(files, key=os.path.getmtime)

    try:
        df = pd.read_excel(latest_file, dtype=str)

        # Find the SR ID column (same candidates as step1)
        id_col = next(
            (c for c in ["SR ID", "SR_No", "SR No", "ServiceRequestID", "SRNo", "ID"]
             if c in df.columns),
            None
        )
        ticket_id_col = "SR_Ticket_ID" if "SR_Ticket_ID" in df.columns else None

        if id_col is None:
            print(f"  [WARN] No SR ID column found in {latest_file} -- using raw sr_no.")
            return sr_no

        # Match the row whose SR ID equals sr_no
        mask = df[id_col].str.strip().str.upper() == str(sr_no).strip().upper()
        matched = df[mask]

        if matched.empty:
            print(f"  [WARN] SR '{sr_no}' not found in {latest_file} -- using raw sr_no.")
            return sr_no

        # Prefer SR_Ticket_ID column (numeric), fall back to stripping "SR" ourselves
        if ticket_id_col:
            val = str(matched.iloc[0][ticket_id_col]).strip()
        else:
            raw = str(matched.iloc[0][id_col]).strip().upper()
            val = raw.lstrip("SR").strip()

        return val if val else sr_no

    except Exception as e:
        print(f"  [WARN] Could not read SR_Ticket_ID from {latest_file}: {e} -- using raw sr_no.")
        return sr_no


def _load_assignment_state():
    if not os.path.exists(ASSIGNMENT_STATE_FILE):
        return {}
    try:
        with open(ASSIGNMENT_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_successful_assignment(sr_no, email, reason=""):
    state = _load_assignment_state()
    state[str(sr_no)] = {
        "email": str(email).strip(),
        "workgroup": WORKGROUP,
        "reason": reason,
        "updated_at": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
    }
    with open(ASSIGNMENT_STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=4)


def post_sr_actions(actions):
    """
    Posts only selected SR actions returned from step3_allocate_sr.allocate_sr_actions.

    Args:
        actions: list of {sr_no, email, reason}
    """

    print("\n" + "=" * 70)
    print("  STEP 4 : Posting Required Service Request Updates via API")
    print("=" * 70)

    if not actions:
        print("  No SR needs API update. Already-assigned present users remain unchanged.")
        return []

    print(f"\n  Total SRs to post : {len(actions)}")
    print(f"  {'SR No':<15} {'Email':<45} Reason")
    print(f"  {'-'*90}")
    for item in actions:
        print(f"  {item['sr_no']:<15} {item['email']:<45} {item.get('reason', '')}")

    results = []

    for item in actions:
        sr_no = item["sr_no"]
        email = item["email"]
        reason = item.get("reason", "Auto assignment")

        print(f"\n  Posting SR {sr_no} -> {email} ...")

        # ---- Read the numeric SR_Ticket_ID from the latest sr_summary Excel ----
        sr_ticket_id = _get_sr_ticket_id(sr_no)

        # ---- Choose payload based on ticket status ----
        ticket_status = item.get("status", "").strip()
        ticket_status_norm = ticket_status.lower().replace("-", "").replace(" ", "")

        if ticket_status_norm == "inprogress":
            # In-Progress payload
            payload = {
                "ServiceName": "SR_UpdateServiceRequest",
                "objCommonParameters": {
                    "_ProxyDetails": {
                        "AuthType": "APIKEY",
                        "APIKey": API_KEY,
                        "ProxyID": 0,
                        "ReturnType": "JSON",
                    },
                    "objSRServiceTicket": {
                        "IncidentTicketID": sr_ticket_id,
                        "Org_ID": ORG_ID,
                        "Status": "In-Progress",
                        "SupportFunction": INSTANCE,
                        "WorkGroupName": WORKGROUP,
                        "AssignedEngineer": email,
                        "InternalLog": "",
                        "UserLog": "",
                    },
                },
            }

        elif ticket_status_norm == "pending":
            # Pending payload (assignee was absent, reassigning)
            payload = {
                "ServiceName": "SR_UpdateServiceRequest",
                "objCommonParameters": {
                    "_ProxyDetails": {
                        "AuthType": "APIKEY",
                        "APIKey": API_KEY,
                        "ProxyID": 0,
                        "ReturnType": "JSON",
                    },
                    "objSRServiceTicket": {
                        "IncidentTicketID": sr_ticket_id,
                        "Org_ID": ORG_ID,
                        "Status": "Pending",
                        "SupportFunction": INSTANCE,
                        "WorkGroupID": 0,
                        "WorkGroupName": WORKGROUP,
                        "AssignedEngineer": email,
                        "PendingReason": "",
                        "InternalLog": "",
                        "ResolutionCode": "",
                    },
                },
            }

        else:
            # Assigned payload (New SR assigned fresh, OR Assigned-absent reassigned)
            payload = {
                "ServiceName": "SR_UpdateServiceRequest",
                "objCommonParameters": {
                    "_ProxyDetails": {
                        "AuthType": "APIKEY",
                        "APIKey": API_KEY,
                        "ProxyID": 0,
                        "ReturnType": "JSON",
                    },
                    "objSRServiceTicket": {
                        "IncidentTicketID": sr_ticket_id,
                        "Org_ID": ORG_ID,
                        "Status": "Assigned",
                        "SupportFunction": INSTANCE,
                        "WorkGroupName": WORKGROUP,
                        "UrgencyName": "U1",
                        "ImpactName": "high",
                        "PriorityName": "Priority 2",
                        "SLAWindowName": "TestSLA",
                        "InternalLog": "",
                        "UserLog": "",
                        "CustomFields": [
                            {
                                "GroupName": "Additional Information",
                                "Name": "Sample Text Name",
                                "Value": "Sample Text value",
                            },
                            {
                                "GroupName": "Additional Information",
                                "Name": "Sample Date",
                                "Value": "2021-12-11",
                            },
                        ],
                    },
                },
            }

        try:
            resp = requests.post(API_URL, json=payload, timeout=30)

            # ---- DEBUG: always show the raw response, since these APIs can
            # return HTTP 200 even when the actual operation failed (the
            # real error is buried inside the JSON body). This is essential
            # to diagnose why posting isn't working.
            print(f"  [DEBUG] HTTP Status : {resp.status_code}")
            try:
                resp_json = resp.json()
                print(f"  [DEBUG] Response body : {json.dumps(resp_json)[:800]}")
            except Exception:
                resp_json = None
                print(f"  [DEBUG] Response body (non-JSON) : {resp.text[:500]}")

            api_says_error = False
            if isinstance(resp_json, dict):
                out_obj = resp_json.get("OutputObject", {})
                for err_key in ("ErrorMessage", "ExceptionMessage", "Message", "StatusMessage"):
                    val = resp_json.get(err_key) or (out_obj.get(err_key) if isinstance(out_obj, dict) else None)
                    if val:
                        print(f"  [DEBUG] {err_key} = {val}")
                        api_says_error = True
                for flag_key in ("IsError", "IsSuccess"):
                    val = resp_json.get(flag_key)
                    if val is not None:
                        print(f"  [DEBUG] {flag_key} = {val}")
                        if flag_key == "IsError" and val:
                            api_says_error = True
                        if flag_key == "IsSuccess" and val is False:
                            api_says_error = True

            if resp.status_code == 200 and not api_says_error:
                print(f"  [OK] Success -- SR {sr_no} assigned to {email}.")
                _save_successful_assignment(sr_no, email, reason)
                print(f"  [OK] Saved local state so this SR is not posted again on next run.")
                result_status = "Success"
            else:
                print(f"  [FAILED] ({resp.status_code}) -- SR {sr_no} - see [DEBUG] lines above for the real reason.")
                result_status = f"Failed_{resp.status_code}"

            results.append({
                "SR_No": sr_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": resp.status_code,
                "Result": result_status,
                "Assigned by Bot": "Yes",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })

        except requests.exceptions.ConnectionError:
            print(f"  [ERROR] Connection error -- SR {sr_no}")
            results.append({
                "SR_No": sr_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": "N/A",
                "Result": "Connection Error",
                "Assigned by Bot": "Yes",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })
        except Exception as e:
            print(f"  [ERROR] {e}")
            results.append({
                "SR_No": sr_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": "N/A",
                "Result": f"Error: {str(e)}",
                "Assigned by Bot": "Yes",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })

    if results:
        ts = datetime.now().strftime("%d%m%y_%H%M%S")
        result_file = f"sr_assignment_result_{ts}.xlsx"
        pd.DataFrame(results).to_excel(result_file, index=False)
        print(f"\n  [OK] Assignment result saved -> {result_file}")

        success = sum(1 for r in results if r["Result"] == "Success")
        failed = len(results) - success
        print(f"\n  -- POST SUMMARY --------------------------------")
        print(f"  Total Posted : {len(results)}")
        print(f"  Success      : {success}")
        print(f"  Failed       : {failed}")

    return results


# ---- Standalone run ----
if __name__ == "__main__":
    sample_actions = [
        {"sr_no": "SR001", "email": "Akshita.Bhandari@maruti.co.in", "reason": "New SR -> Emp"},
        {"sr_no": "SR002", "email": "JKTECH_Neha.Aswal@maruti.co.in", "reason": "New SR -> Ven"},
    ]
    post_sr_actions(sample_actions)

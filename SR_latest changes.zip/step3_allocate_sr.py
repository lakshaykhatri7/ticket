# ============================================================
#  step3_allocate_sr.py
#  Service Request (SR) allocation logic. Mirrors step3_allocate.py
#  (used for Incidents) but keyed off SR-specific field names.
#
#  User logic implemented (same rules as Incident flow, now updated):
#    1. If SR is NEW / unassigned -> assign via Employee/Vendor split.
#    2. If SR is PENDING          -> reassign via Employee/Vendor split
#                                     to a present person (regardless of
#                                     current assignee).
#    3. If SR is IN PROGRESS      -> reassign via Employee/Vendor split
#                                     to a present person (regardless of
#                                     current assignee). NOTE: this used to
#                                     be "never touch" - that rule has been
#                                     removed per updated instructions.
#    4. Any OTHER status (e.g. "Assigned") that's already assigned:
#         - if current person is present -> keep same person, do not post update
#         - if current person is absent  -> assign to another present person
#    5. New / Pending / In Progress SRs all draw from the same Employee /
#       Vendor split pool from ATTENDANCE.xlsx (combined split target).
# ============================================================

from config import DEFAULT_EMP_SPLIT
import json
import os

ASSIGNMENT_STATE_FILE = "assignment_state_sr.json"


def _load_assignment_state():
    """Local idempotency cache: remembers successful SR assignments from previous runs.

    Kept in a SEPARATE file (assignment_state_sr.json) from the Incident flow's
    assignment_state.json so the two do not overwrite each other if run side by side.
    """
    if not os.path.exists(ASSIGNMENT_STATE_FILE):
        return {}
    try:
        with open(ASSIGNMENT_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _state_assignee(sr_no, state):
    item = (state or {}).get(str(sr_no), {})
    if isinstance(item, dict):
        return _clean(item.get("email"))
    return _clean(item)


# NOTE: Confirm the actual key names returned by SR_GetServiceRequestList once you
# have inspected a live response (see output_sr.json from step1_fetch_sr.py) and
# adjust these lists if needed. Kept broad on purpose so common variants match.
SR_ID_KEYS = ["SR ID", "SR_No", "SR No", "ServiceRequestID", "Service Request ID", "SRNo", "ID"]
ASSIGNEE_KEYS = ["Executive Email", "Assigned_Engineer_Email", "Executive Name", "Assigned Engineer", "Assignee", "Owner"]
STATUS_KEYS = ["Status", "SR Status", "Ticket Status"]


def _clean(value):
    return "" if value is None else str(value).strip()


def _norm(value):
    return _clean(value).lower().replace(" ", "")


def _get(sr, keys):
    for key in keys:
        if key in sr and _clean(sr.get(key)):
            return _clean(sr.get(key))
    return ""


def _sr_no(sr):
    return _get(sr, SR_ID_KEYS)


def _assignee(sr):
    return _get(sr, ASSIGNEE_KEYS)


def _status(sr):
    return _get(sr, STATUS_KEYS)


def _status_norm(sr):
    """Normalize SR status for reliable comparisons."""
    return _norm(_status(sr)).replace("-", "")


def _is_in_progress(sr):
    """In-progress SRs now go through split-based reassignment (see _needs_split_assignment)."""
    return _status_norm(sr) in {"inprogress", "inprogess"}


def _is_pending(sr):
    """Pending SRs go through split-based reassignment (see _needs_split_assignment)."""
    status = _status_norm(sr)
    return status == "pending" or status.startswith("pending")


def _person_pool(present):
    return {
        "Emp": [p["name"] for p in present.get("Emp", []) if p.get("solver") == "Y"],
        "Ven": [p["name"] for p in present.get("Ven", []) if p.get("solver") == "Y"],
    }


def _all_people(rows):
    emp = list((rows or {}).get("employee", {}).keys())
    ven = list((rows or {}).get("vendor", {}).keys())
    return {"Emp": emp, "Ven": ven, "All": emp + ven}


def _compact_identity(value):
    """Normalize names/emails for comparison: ignores case, spaces, dots, underscores and hyphens."""
    text = _norm(value)
    return (
        text.replace(".", "")
            .replace("_", "")
            .replace("-", "")
            .replace("@", "")
    )


def _email_local_part(email):
    return _clean(email).split("@")[0]


def _match_person(name_or_email, people):
    """Match exact email/name first; then safe partial match.

    API sometimes returns Executive Name, while ATTENDANCE.xlsx stores email + Name.
    This function supports both forms.
    """
    target = _clean(name_or_email)
    target_norm = _norm(target)
    target_compact = _compact_identity(target)
    target_local = _compact_identity(_email_local_part(target))

    if not target_compact:
        return ""

    # 1) Exact normalized match.
    for person in people or []:
        if _norm(person) == target_norm:
            return person

    # 2) Compare compact full value and email local-part.
    for person in people or []:
        person_compact = _compact_identity(person)
        person_local = _compact_identity(_email_local_part(person))
        candidates = [person_compact, person_local]
        for cand in candidates:
            if not cand:
                continue
            if len(target_compact) >= 3 and (target_compact in cand or cand in target_compact):
                return person
            if len(target_local) >= 3 and (target_local in cand or cand in target_local):
                return person

    return ""


def _identity_values_for_role(rows, role):
    """Return all known emails + display names for one role from attendance rows."""
    details = (rows or {}).get("details", {}) or {}
    values = []
    for email, info in details.items():
        if (info or {}).get("role") == role:
            values.append(email)
            name = _clean((info or {}).get("name"))
            if name:
                values.append(name)
    return values


def _present_identity_values(present):
    """Return present solver emails + display names from Step 2."""
    values = []
    for role in ["Emp", "Ven"]:
        for item in (present or {}).get(role, []) or []:
            if item.get("solver") == "Y":
                values.append(item.get("name", ""))          # email used internally
                values.append(item.get("display_name", ""))  # Name column from Excel
    return [v for v in values if _clean(v)]


def _role_of_person(name_or_email, rows):
    if _match_person(name_or_email, _identity_values_for_role(rows, "Emp")):
        return "Emp"
    if _match_person(name_or_email, _identity_values_for_role(rows, "Ven")):
        return "Ven"
    return ""


def _is_present(name_or_email, present, rows):
    return bool(_match_person(name_or_email, _present_identity_values(present)))


def _is_new_sr(sr, cached_assignee=""):
    """An SR is treated as new (-> assign to a present person) when EITHER:
      (a) Status is explicitly "New" (primary signal, as requested), OR
      (b) there is no assignee in API and no assignee in local state, and the
          status isn't one of the "already handled" states (fallback safety
          net for SRs that have no status or an unexpected status value).

    Do NOT treat Status=Open alone as unassigned/new, since many systems keep
    an SR "Open" even after assignment - only "New" is treated as the new-SR
    signal on its own.
    """
    status = _status_norm(sr)

    # (a) Explicit "New" status -> always treat as new, regardless of assignee.
    # Uses startswith rather than exact match to also catch values like
    # "New Request" / "New-Ticket" that normalize to "newrequest" etc.
    if status == "new" or status.startswith("new"):
        return True

    # (b) Fallback: no assignee anywhere, and not already assigned/resolved/closed.
    assignee = _assignee(sr) or cached_assignee
    if assignee:
        return False

    if status in {"assigned", "resolved", "closed"}:
        return False

    # Note: pending/inprogress SRs are handled separately via
    # _needs_split_assignment() below, so they are excluded from the plain
    # "new" fallback here to avoid double-classification.
    if status in {"pending", "inprogress", "inprogess"}:
        return False

    return True


def _needs_split_assignment(sr, cached_assignee=""):
    """SRs that must be (re)assigned via the Employee/Vendor split, to a
    present person, REGARDLESS of who (if anyone) currently holds them:
      - New / unassigned SRs
      - Pending SRs
      - In Progress SRs
    """
    return _is_new_sr(sr, cached_assignee) or _is_pending(sr) or _is_in_progress(sr)


def _make_round_robin_selector(candidates):
    state = {"i": 0}

    def pick(exclude=""):
        available = [c for c in candidates if _norm(c) != _norm(exclude)]
        if not available:
            return ""
        chosen = available[state["i"] % len(available)]
        state["i"] += 1
        return chosen

    return pick


def allocate_sr_actions(sr_list, present, rows):
    """
    Returns only the SRs that must be posted to the API.

    Output list item:
      {"sr_no": "...", "email": "...", "reason": "New SR/Reassigned - Assignee Absent"}
    """

    print("\n" + "=" * 70)
    print("  STEP 3 : Service Request Decision Logic")
    print("=" * 70)

    state = _load_assignment_state()

    pools = _person_pool(present)
    pick_emp = _make_round_robin_selector(pools["Emp"])
    pick_ven = _make_round_robin_selector(pools["Ven"])
    pick_any = _make_round_robin_selector(pools["Emp"] + pools["Ven"])

    actions = []
    kept = []
    skipped = []

    # ---- DEBUG: verify STATUS_KEYS / ASSIGNEE_KEYS are actually matching the
    # real API field names. If they aren't, _status()/_assignee() silently
    # return "" and every SR falls through to the wrong branch (e.g. "New"
    # tickets showing up as 0 even though many were fetched).
    if sr_list:
        sample = sr_list[0]
        matched_status_key = next((k for k in STATUS_KEYS if k in sample), None)
        matched_assignee_key = next((k for k in ASSIGNEE_KEYS if k in sample), None)
        print(f"\n  [DEBUG] Status field matched   : {matched_status_key!r} (tried {STATUS_KEYS})")
        print(f"  [DEBUG] Assignee field matched : {matched_assignee_key!r} (tried {ASSIGNEE_KEYS})")
        if not matched_status_key or not matched_assignee_key:
            print(f"  [DEBUG] Raw keys available on first SR record: {list(sample.keys())}")

        raw_statuses = sorted({_clean(sr.get(matched_status_key, "")) or "(blank)" for sr in sr_list}) if matched_status_key else []
        print(f"  [DEBUG] Distinct raw status values seen : {raw_statuses}")
        norm_statuses = sorted({_status_norm(sr) or "(blank)" for sr in sr_list})
        print(f"  [DEBUG] Distinct normalized status values (what code compares to 'new') : {norm_statuses}")

    split_srs = []
    for sr in sr_list:
        sno = _sr_no(sr)
        cached = _state_assignee(sno, state) if sno else ""
        if _needs_split_assignment(sr, cached):
            split_srs.append(sr)

    ratio = (rows or {}).get("ratio", {})
    emp_split = ratio.get("Emp", DEFAULT_EMP_SPLIT)
    ven_split = ratio.get("Ven", 1 - emp_split)
    emp_target = round(len(split_srs) * emp_split)
    emp_done = 0
    ven_done = 0

    print(f"\n  Total fetched SRs            : {len(sr_list)}")
    print(f"  New / Pending / In Progress  : {len(split_srs)}  (all draw from the split pool)")
    print(f"  Ratio used from Excel        : Emp {round(emp_split*100)}%, Ven {round(ven_split*100)}%")
    print(f"  Previous bot assignments loaded: {len(state)}")
    print(f"  Split target                 : Emp {emp_target}, Ven {len(split_srs) - emp_target}")

    for sr in sr_list:
        sr_no = _sr_no(sr)
        api_current = _assignee(sr)
        cached_current = _state_assignee(sr_no, state) if sr_no else ""
        current = api_current or cached_current

        if not sr_no:
            skipped.append({"sr_no": "", "reason": "SR number missing"})
            continue

        # Case 1: New / Pending / In Progress -> (re)assign via Employee/Vendor
        # split to a present person, regardless of current assignee.
        if _needs_split_assignment(sr, cached_current):
            if _is_pending(sr):
                status_label = "Pending"
            elif _is_in_progress(sr):
                status_label = "In Progress"
            else:
                status_label = "New"

            if emp_done < emp_target:
                email = pick_emp() or pick_any()
                emp_done += 1
                role = "Emp"
            else:
                email = pick_ven() or pick_any()
                ven_done += 1
                role = "Ven"

            if email:
                actions.append({
                    "sr_no": sr_no,
                    "email": email,
                    "reason": f"{status_label} -> reassigned via split ({role})",
                    "status": status_label,   # passed to step4 to pick the right payload
                })
            else:
                skipped.append({"sr_no": sr_no, "reason": f"No present person available for {status_label} SR"})
            continue

        # Case 2 (any OTHER status, e.g. "Assigned"): already assigned and
        # person is present -> keep as it is.
        if _is_present(current, present, rows):
            kept.append({"sr_no": sr_no, "email": current, "reason": "Already assigned person is present"})
            continue

        # Case 3: already assigned but person absent -> reassign.
        role = _role_of_person(current, rows)
        if role == "Emp":
            email = pick_emp(exclude=current) or pick_any(exclude=current)
        elif role == "Ven":
            email = pick_ven(exclude=current) or pick_any(exclude=current)
        else:
            email = pick_any(exclude=current)

        if email:
            actions.append({
                "sr_no": sr_no,
                "email": email,
                "reason": "Reassigned - current assignee absent",
                "status": "Assigned",   # passed to step4 to pick the right payload
            })
        else:
            skipped.append({"sr_no": sr_no, "reason": f"Current assignee absent, but no present replacement found ({current})"})

    print(f"\n  -- KEPT SAME (No API update) -------------------")
    if kept:
        for item in kept:
            print(f"  {item['sr_no']:<15} stays with {item['email']}  ({item.get('reason', '')})")
    else:
        print("  None")

    print(f"\n  -- WILL BE ASSIGNED / REASSIGNED ---------------")
    if actions:
        for item in actions:
            print(f"  {item['sr_no']:<15} -> {item['email']:<45} {item['reason']}")
    else:
        print("  None")

    if skipped:
        print(f"\n  -- SKIPPED -------------------------------------")
        for item in skipped:
            print(f"  {item['sr_no'] or 'UNKNOWN':<15} {item['reason']}")

    return actions, kept, skipped


if __name__ == "__main__":
    sample_present = {
        "Emp": [{"name": "rahul@maruti.co.in", "solver": "Y"}],
        "Ven": [{"name": "neha@maruti.co.in", "solver": "Y"}],
    }
    sample_rows = {
        "employee": {"rahul@maruti.co.in": "P", "amit@maruti.co.in": "A"},
        "vendor": {"neha@maruti.co.in": "P"},
    }
    sample_sr_list = [
        {"SR ID": "SR001", "Status": "Assigned", "Executive Name": "rahul@maruti.co.in"},
        {"SR ID": "SR002", "Status": "Assigned", "Executive Name": "amit@maruti.co.in"},
        {"SR ID": "SR003", "Status": "New", "Executive Name": ""},
        {"SR ID": "SR004", "Status": "Pending", "Executive Name": "amit@maruti.co.in"},
        {"SR ID": "SR005", "Status": "In Progress", "Executive Name": "rahul@maruti.co.in"},
    ]
    allocate_sr_actions(sample_sr_list, sample_present, sample_rows)

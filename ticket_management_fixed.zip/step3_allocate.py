# ============================================================
#  step3_allocate.py
#  Ticket-by-ticket assignment logic.
#
#  User logic implemented:
#    1. If ticket is NEW / unassigned -> assign it.
#    2. If ticket is already assigned:
#         - if current person is present -> keep same person, do not post update
#         - if current person is absent  -> assign to another present person
#    3. If ticket status is IN PROGRESS -> do not touch it at all.
#       Keep the same assigned person even if attendance is absent.
#    4. New tickets still follow 30% Employee / 70% Vendor split.
# ============================================================

from config import DEFAULT_EMP_SPLIT
import json
import os

ASSIGNMENT_STATE_FILE = "assignment_state.json"


def _load_assignment_state():
    """Local idempotency cache: remembers successful assignments from previous runs.

    This prevents the same fetched NEW/unassigned ticket from being posted again
    if the API list response has not started showing the assignee yet.
    """
    if not os.path.exists(ASSIGNMENT_STATE_FILE):
        return {}
    try:
        with open(ASSIGNMENT_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _state_assignee(ticket_no, state):
    item = (state or {}).get(str(ticket_no), {})
    if isinstance(item, dict):
        return _clean(item.get("email"))
    return _clean(item)

TICKET_ID_KEYS = ["Incident ID", "Ticket_No", "Ticket No", "TicketNo", "Ticket ID", "ID"]
ASSIGNEE_KEYS = ["Executive Email", "Assigned_Engineer_Email", "Executive Name", "Assigned Engineer", "Assignee", "Owner"]
STATUS_KEYS = ["Status", "Ticket Status"]


def _clean(value):
    return "" if value is None else str(value).strip()


def _norm(value):
    return _clean(value).lower().replace(" ", "")


def _get(ticket, keys):
    for key in keys:
        if key in ticket and _clean(ticket.get(key)):
            return _clean(ticket.get(key))
    return ""


def _ticket_no(ticket):
    return _get(ticket, TICKET_ID_KEYS)


def _assignee(ticket):
    return _get(ticket, ASSIGNEE_KEYS)


def _status(ticket):
    return _get(ticket, STATUS_KEYS)


def _status_norm(ticket):
    """Normalize ticket status for reliable comparisons."""
    return _norm(_status(ticket)).replace("-", "")


def _is_in_progress(ticket):
    """In-progress tickets must never be assigned/reassigned by this bot."""
    return _status_norm(ticket) in {"inprogress", "inprogess"}


def _person_pool(present):
    return {
        "Emp": [p["name"] for p in present.get("Emp", []) if p.get("solver") == "Y"],
        "Ven": [p["name"] for p in present.get("Ven", []) if p.get("solver") == "Y"],
    }


def _all_people(rows):
    emp = list((rows or {}).get("employee", {}).keys())
    ven = list((rows or {}).get("vendor", {}).keys())
    return {"Emp": emp, "Ven": ven, "All": emp + ven}


def _compact_identity(value):
    """Normalize names/emails for comparison: ignores case, spaces, dots, underscores and hyphens."""
    text = _norm(value)
    return (
        text.replace(".", "")
            .replace("_", "")
            .replace("-", "")
            .replace("@", "")
    )


def _email_local_part(email):
    return _clean(email).split("@")[0]


def _match_person(name_or_email, people):
    """Match exact email/name first; then safe partial match.

    API sometimes returns Executive Name, while ATTENDANCE.xlsx stores email + Name.
    This function supports both forms. Example: API gives "Neha" or "Neha Sharma",
    Excel has "neha.sharma@..." or Name="Neha Sharma".
    """
    target = _clean(name_or_email)
    target_norm = _norm(target)
    target_compact = _compact_identity(target)
    target_local = _compact_identity(_email_local_part(target))

    if not target_compact:
        return ""

    # 1) Exact normalized match.
    for person in people or []:
        if _norm(person) == target_norm:
            return person

    # 2) Compare compact full value and email local-part.
    for person in people or []:
        person_compact = _compact_identity(person)
        person_local = _compact_identity(_email_local_part(person))
        candidates = [person_compact, person_local]
        for cand in candidates:
            if not cand:
                continue
            # Require at least 3 chars for partial match to avoid accidental one-letter matches.
            if len(target_compact) >= 3 and (target_compact in cand or cand in target_compact):
                return person
            if len(target_local) >= 3 and (target_local in cand or cand in target_local):
                return person

    return ""


def _identity_values_for_role(rows, role):
    """Return all known emails + display names for one role from attendance rows."""
    details = (rows or {}).get("details", {}) or {}
    values = []
    for email, info in details.items():
        if (info or {}).get("role") == role:
            values.append(email)
            name = _clean((info or {}).get("name"))
            if name:
                values.append(name)
    return values


def _present_identity_values(present):
    """Return present solver emails + display names from Step 2."""
    values = []
    for role in ["Emp", "Ven"]:
        for item in (present or {}).get(role, []) or []:
            if item.get("solver") == "Y":
                values.append(item.get("name", ""))          # email used internally
                values.append(item.get("display_name", ""))  # Name column from Excel
    return [v for v in values if _clean(v)]


def _role_of_person(name_or_email, rows):
    # Match using both email and Name from ATTENDANCE.xlsx.
    if _match_person(name_or_email, _identity_values_for_role(rows, "Emp")):
        return "Emp"
    if _match_person(name_or_email, _identity_values_for_role(rows, "Ven")):
        return "Ven"
    return ""


def _is_present(name_or_email, present, rows):
    """
    Check if a person is present today.

    Uses rows[details] (full attendance from step2) as source of truth so:
      - A present Solver=N person is NOT wrongly reassigned
      - Name-only matches from the API (e.g. Neha) are resolved to the
        correct email and their real P/A status is checked

    Strategy:
      1. Direct email key lookup in rows[details]
      2. Match target against every email + display_name in details
      3. Fallback fuzzy match against the present pool (Solver=Y only)
    """
    target = _clean(name_or_email)
    if not target:
        return False

    details = (rows or {}).get("details", {}) or {}

    # 1. Direct email match
    if target in details:
        return details[target].get("status", "A") == "P"

    # 2. Check all emails and display names stored in details
    for email, info in details.items():
        person_name = _clean((info or {}).get("name", ""))
        if (_norm(target) == _norm(email)
                or (person_name and _norm(target) == _norm(person_name))
                or _match_person(target, [email, person_name])):
            return info.get("status", "A") == "P"

    # 3. Fallback: fuzzy match against present solver pool only
    return bool(_match_person(target, _present_identity_values(present)))

def _is_new_ticket(ticket, cached_assignee=""):
    """A ticket is new only when there is no assignee in API and no assignee in local state.

    Important: do NOT treat Status=Open/New alone as unassigned. In many ticket
    systems a ticket remains Open even after assignment, so using Status alone
    causes repeat API assignment on every run.
    """
    assignee = _assignee(ticket) or cached_assignee
    if assignee:
        return False

    status = _status_norm(ticket)
    if status in {"assigned", "inprogress", "inprogess", "resolved", "closed"}:
        return False

    return True


def _make_round_robin_selector(candidates):
    state = {"i": 0}

    def pick(exclude=""):
        available = [c for c in candidates if _norm(c) != _norm(exclude)]
        if not available:
            return ""
        chosen = available[state["i"] % len(available)]
        state["i"] += 1
        return chosen

    return pick


def allocate_ticket_actions(tickets, present, rows):
    """
    Returns only the tickets that must be posted to API.

    Output list item:
      {"ticket_no": "...", "email": "...", "reason": "New Ticket/Reassigned - Assignee Absent"}
    """

    print("\n" + "="*70)
    print("  STEP 3 : Ticket Decision Logic")
    print("="*70)

    state = _load_assignment_state()

    pools = _person_pool(present)
    pick_emp = _make_round_robin_selector(pools["Emp"])
    pick_ven = _make_round_robin_selector(pools["Ven"])
    pick_any = _make_round_robin_selector(pools["Emp"] + pools["Ven"])

    actions = []
    kept = []
    skipped = []

    new_tickets = []
    for t in tickets:
        tno = _ticket_no(t)
        cached = _state_assignee(tno, state) if tno else ""
        if _is_new_ticket(t, cached):
            new_tickets.append(t)

    # Assignment ratio now comes from ATTENDANCE.xlsx (row: Assignment Ratio).
    # Example: SAP_MDM - OTH has 20/80, SAP_MDM - MM has 30/70.
    ratio = (rows or {}).get("ratio", {})
    emp_split = ratio.get("Emp", DEFAULT_EMP_SPLIT)
    ven_split = ratio.get("Ven", 1 - emp_split)
    emp_new_target = round(len(new_tickets) * emp_split)
    emp_new_done = 0
    ven_new_done = 0

    print(f"\n  Total fetched tickets : {len(tickets)}")
    print(f"  New/unassigned tickets: {len(new_tickets)}")
    print(f"  Ratio used from Excel : Emp {round(emp_split*100)}%, Ven {round(ven_split*100)}%")
    print(f"  Previous bot assignments loaded: {len(state)}")
    print(f"  New ticket split      : Emp {emp_new_target}, Ven {len(new_tickets) - emp_new_target}")

    for ticket in tickets:
        ticket_no    = _ticket_no(ticket)
        api_current  = _assignee(ticket)
        cached_current = _state_assignee(ticket_no, state) if ticket_no else ""
        current      = api_current or cached_current

        if not ticket_no:
            skipped.append({"ticket_no": "", "reason": "Ticket number missing"})
            continue

        # ---------------------------------------------------------------
        # RULE 0 : In Progress -> never touch, always keep as-is
        # ---------------------------------------------------------------
        if _is_in_progress(ticket):
            kept.append({
                "ticket_no": ticket_no,
                "email": current,
                "reason": "In Progress - not touched"
            })
            continue

        # ---------------------------------------------------------------
        # RULE 1 : New ticket (no assignee) -> assign fresh
        # ---------------------------------------------------------------
        if _is_new_ticket(ticket, cached_current):
            if emp_new_done < emp_new_target:
                email = pick_emp() or pick_any()
                emp_new_done += 1
                role = "Emp"
            else:
                email = pick_ven() or pick_any()
                ven_new_done += 1
                role = "Ven"

            if email:
                actions.append({"ticket_no": ticket_no, "email": email, "reason": f"New -> assigned to {role}"})
            else:
                skipped.append({"ticket_no": ticket_no, "reason": "New ticket but no present person available"})
            continue

        # ---------------------------------------------------------------
        # RULE 2 : Already assigned
        #   IF   assigned person is Present -> keep exactly as-is, no API call
        #   ELSE (person is Absent)         -> reassign to a present person
        # ---------------------------------------------------------------
        if _is_present(current, present, rows):
            # Person is PRESENT -> DO NOT touch the ticket
            kept.append({
                "ticket_no": ticket_no,
                "email": current,
                "reason": "Assigned + Present -> no change"
            })
        else:
            # Person is ABSENT -> reassign within same role
            role = _role_of_person(current, rows)
            if role == "Emp":
                email = pick_emp(exclude=current) or pick_any(exclude=current)
            elif role == "Ven":
                email = pick_ven(exclude=current) or pick_any(exclude=current)
            else:
                email = pick_any(exclude=current)

            if email:
                actions.append({
                    "ticket_no": ticket_no,
                    "email": email,
                    "reason": f"Assigned + Absent ({current}) -> reassigned"
                })
            else:
                skipped.append({
                    "ticket_no": ticket_no,
                    "reason": f"Assigned + Absent ({current}) but no present replacement found"
                })

    print(f"\n  -- KEPT SAME (No API update) -------------------")
    if kept:
        for item in kept:
            print(f"  {item['ticket_no']:<15} stays with {item['email']}  ({item.get('reason', '')})")
    else:
        print("  None")

    print(f"\n  -- WILL BE ASSIGNED / REASSIGNED ---------------")
    if actions:
        for item in actions:
            print(f"  {item['ticket_no']:<15} -> {item['email']:<45} {item['reason']}")
    else:
        print("  None")

    if skipped:
        print(f"\n  -- SKIPPED -------------------------------------")
        for item in skipped:
            print(f"  {item['ticket_no'] or 'UNKNOWN':<15} {item['reason']}")

    return actions, kept, skipped


# Old count-based function kept only for backward compatibility.
def allocate_tickets(present, total_tickets=None):
    pools = _person_pool(present)
    total_tickets = total_tickets or 0
    emp_total = round(total_tickets * DEFAULT_EMP_SPLIT)
    ven_total = total_tickets - emp_total
    allocation = {}
    for role, share in [("Emp", emp_total), ("Ven", ven_total)]:
        people = pools[role]
        if not people:
            continue
        for i, name in enumerate(people):
            allocation[name] = share // len(people) + (1 if i < share % len(people) else 0)
    return allocation


if __name__ == "__main__":
    sample_present = {
        "Emp": [{"name": "rahul@maruti.co.in", "solver": "Y"}],
        "Ven": [{"name": "neha@maruti.co.in", "solver": "Y"}],
    }
    sample_rows = {
        "employee": {"rahul@maruti.co.in": "P", "amit@maruti.co.in": "A"},
        "vendor": {"neha@maruti.co.in": "P"},
    }
    sample_tickets = [
        {"Incident ID": "INC001", "Status": "Assigned", "Executive Name": "rahul@maruti.co.in"},
        {"Incident ID": "INC002", "Status": "Assigned", "Executive Name": "amit@maruti.co.in"},
        {"Incident ID": "INC003", "Status": "New", "Executive Name": ""},
    ]
    allocate_ticket_actions(sample_tickets, sample_present, sample_rows)

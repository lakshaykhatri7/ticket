# ============================================================
#  step4_post_sr.py
#  Assigns allocated Service Requests to each person's email via the API.
#
#  *** IMPORTANT / UNCONFIRMED ***
#  Your uploaded project only contained the Incident update payload
#  ("IM_LogOrUpdateIncident"). No SR "update/assign" payload sample was
#  provided (only the SR *list* payload, SR_GetServiceRequestList).
#
#  The ServiceName and field names below ("SR_LogOrUpdateServiceRequest",
#  "srParamsJSON", "SRContainerJsonObj", "SR_No", etc.) are a BEST-GUESS
#  mirror of the Incident update payload structure. They are NOT confirmed
#  against your actual backend and will very likely need correction once
#  you have (or your API team can provide) a real "update/assign SR" sample
#  payload. Please verify:
#    1. The exact ServiceName for updating/assigning an SR.
#    2. The exact wrapper key (equivalent to "incidentParamsJSON").
#    3. The exact field name for the SR number (equivalent to "Ticket_No").
#    4. The exact field name for the assignee email.
#
#  Everything else in this file (state caching, Excel result export,
#  error handling) mirrors step4_post_tickets.py exactly.
#
#  Output: sr_assignment_result_ddmmyy_hhmmss.xlsx
# ============================================================

import requests
import pandas as pd
from datetime import datetime
import json
import os
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP

ASSIGNMENT_STATE_FILE = "assignment_state_sr.json"


def _load_assignment_state():
    if not os.path.exists(ASSIGNMENT_STATE_FILE):
        return {}
    try:
        with open(ASSIGNMENT_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_successful_assignment(sr_no, email, reason=""):
    state = _load_assignment_state()
    state[str(sr_no)] = {
        "email": str(email).strip(),
        "workgroup": WORKGROUP,
        "reason": reason,
        "updated_at": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
    }
    with open(ASSIGNMENT_STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=4)


def post_sr_actions(actions):
    """
    Posts only selected SR actions returned from step3_allocate_sr.allocate_sr_actions.

    Args:
        actions: list of {sr_no, email, reason}
    """

    print("\n" + "=" * 70)
    print("  STEP 4 : Posting Required Service Request Updates via API")
    print("=" * 70)

    if not actions:
        print("  No SR needs API update. Already-assigned present users remain unchanged.")
        return []

    print(f"\n  Total SRs to post : {len(actions)}")
    print(f"  {'SR No':<15} {'Email':<45} Reason")
    print(f"  {'-'*90}")
    for item in actions:
        print(f"  {item['sr_no']:<15} {item['email']:<45} {item.get('reason', '')}")

    results = []

    for item in actions:
        sr_no = item["sr_no"]
        email = item["email"]
        reason = item.get("reason", "Auto assignment")

        print(f"\n  Posting SR {sr_no} -> {email} ...")

        # ---- BEST-GUESS payload, mirrors IM_LogOrUpdateIncident structure ----
        # Confirm/replace ServiceName and field names once a real SR update
        # sample payload is available (see file header note above).
        payload = {
            "ServiceName": "SR_LogOrUpdateServiceRequest",
            "objCommonParameters": {
                "_ProxyDetails": {
                    "AuthType": "APIKEY",
                    "APIKey": API_KEY,
                    "ProxyID": 0,
                    "ReturnType": "JSON",
                    "OrgID": ORG_ID
                },
                "srParamsJSON": {
                    "SRContainerJsonObj": {
                        "Updater": "Executive",
                        "SR": {
                            "IsFromWebService": True,
                            "SR_No": sr_no,
                            "Sup_Function": INSTANCE,
                            "Status": "Assigned",
                            "Assigned_WorkGroup_Name": WORKGROUP,
                            "Medium": "API",
                            "Source": "API Call",
                            "Assigned_Engineer_Email": email,
                            "PageName": "LogSR"
                        },
                        "SRInformation": {
                            "Information": f"{reason}: auto-assigned to {email} via Python"
                        },
                        "CustomFields": []
                    }
                },
                "RequestType": "RemoteCall"
            }
        }

        try:
            resp = requests.post(API_URL, json=payload, timeout=30)
            if resp.status_code == 200:
                print(f"  [OK] Success -- SR {sr_no} assigned to {email}.")
                _save_successful_assignment(sr_no, email, reason)
                print(f"  [OK] Saved local state so this SR is not posted again on next run.")
                result_status = "Success"
            else:
                print(f"  [FAILED] ({resp.status_code}) -- SR {sr_no}")
                result_status = f"Failed_{resp.status_code}"

            results.append({
                "SR_No": sr_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": resp.status_code,
                "Result": result_status,
                "Assigned by Bot": "Yes",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })

        except requests.exceptions.ConnectionError:
            print(f"  [ERROR] Connection error -- SR {sr_no}")
            results.append({
                "SR_No": sr_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": "N/A",
                "Result": "Connection Error",
                "Assigned by Bot": "Yes",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })
        except Exception as e:
            print(f"  [ERROR] {e}")
            results.append({
                "SR_No": sr_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": "N/A",
                "Result": f"Error: {str(e)}",
                "Assigned by Bot": "Yes",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })

    if results:
        ts = datetime.now().strftime("%d%m%y_%H%M%S")
        result_file = f"sr_assignment_result_{ts}.xlsx"
        pd.DataFrame(results).to_excel(result_file, index=False)
        print(f"\n  [OK] Assignment result saved -> {result_file}")

        success = sum(1 for r in results if r["Result"] == "Success")
        failed = len(results) - success
        print(f"\n  -- POST SUMMARY --------------------------------")
        print(f"  Total Posted : {len(results)}")
        print(f"  Success      : {success}")
        print(f"  Failed       : {failed}")

    return results


# ---- Standalone run ----
if __name__ == "__main__":
    sample_actions = [
        {"sr_no": "SR001", "email": "Akshita.Bhandari@maruti.co.in", "reason": "New SR -> Emp"},
        {"sr_no": "SR002", "email": "JKTECH_Neha.Aswal@maruti.co.in", "reason": "New SR -> Ven"},
    ]
    post_sr_actions(sample_actions)

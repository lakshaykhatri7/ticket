Service Request (SR) Management System — Parallel to the Incident flow
========================================================================

Run:
  python main_sr.py

This is a full SR-based clone of your original Incident (TM2) project.
It reuses config.py, ATTENDANCE.xlsx, and step2_attendance.py unchanged
(attendance/ratio logic isn't Incident- or SR-specific), and adds SR-specific
versions of the fetch / allocate / post / report / main steps.

Files:
- config.py               Shared settings (API URL, key, org, instance, workgroup, Excel file)
- ATTENDANCE.xlsx         Same attendance file used by both flows
- step1_fetch_sr.py       Fetches SR list (ServiceName: SR_GetServiceRequestList)
- step2_attendance.py     Reads attendance + Employee/Vendor ratio (shared, unchanged)
- step3_allocate_sr.py    SR-by-SR assignment/reassignment decision logic
- step4_post_sr.py        Posts required SR assignment updates via API
- step5_report_sr.py      Builds final sr_assignment_report_ddmmyy_hhmmss.xlsx
- main_sr.py               Full automated flow (Fetch -> Attendance -> Allocate -> Post -> Report)

Same core rules as the Incident bot:
  1. New/unassigned SR -> assign to a present solver by Excel ratio.
  2. Already-assigned SR, assignee present -> keep as-is, no API call.
  3. Already-assigned SR, assignee absent  -> reassign to a present solver.
  4. In Progress SR -> never touched, regardless of attendance.
  5. Local state file (assignment_state_sr.json) prevents re-posting the
     same assignment if the API list hasn't reflected it yet. This is a
     SEPARATE file from the Incident flow's assignment_state.json, so
     running both bots side by side will not conflict.

============================================================
IMPORTANT — PLEASE VERIFY BEFORE PRODUCTION USE
============================================================

1. step1_fetch_sr.py (list SRs)
   - Built directly from the SR_GetServiceRequestList payload you provided,
     so the REQUEST side should be accurate.
   - The RESPONSE parsing is a best guess based on the Incident list
     response shape:
       * Expects sr list at data["OutputObject"]["MyServiceRequests"]
       * Expects an ID column named "SR ID"
     Run step1_fetch_sr.py once, inspect the saved output_sr.json, and if
     the real key names differ, update:
       - the `sr_list = data.get("OutputObject", {}).get("MyServiceRequests", [])`
         line in step1_fetch_sr.py
       - the `SUMMARY_COLUMNS` list and `sr_numbers` extraction in the same file
       - the `SR_ID_KEYS` / `ASSIGNEE_KEYS` / `STATUS_KEYS` lists at the top of
         step3_allocate_sr.py

2. step4_post_sr.py (assign/update an SR) — NOT CONFIRMED
   Your uploaded project only included the Incident update payload
   ("IM_LogOrUpdateIncident"). No sample "update/assign SR" payload was
   provided. step4_post_sr.py currently sends a BEST-GUESS payload modeled
   on the Incident one:
     ServiceName: "SR_LogOrUpdateServiceRequest"
     objCommonParameters.srParamsJSON.SRContainerJsonObj.SR.SR_No / Assigned_Engineer_Email / etc.
   This will very likely need correcting once you have (or your API/backend
   team can provide) the real SR update/assign payload — specifically:
     - the correct ServiceName
     - the correct wrapper key name
     - the correct SR-number field name
     - the correct assignee-email field name
   Until this is confirmed, treat step4_post_sr.py as a placeholder — don't
   rely on it against production without verifying the payload first.

3. Once you have a working sample "assign SR" request/response (even one
   captured from Postman or the vendor portal), send it over and I'll
   correct step4_post_sr.py and step3_allocate_sr.py's field-name lists to
   match exactly.

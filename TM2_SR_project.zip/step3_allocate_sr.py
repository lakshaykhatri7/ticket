# ============================================================
#  step3_allocate_sr.py
#  Service Request (SR) allocation logic. Mirrors step3_allocate.py
#  (used for Incidents) but keyed off SR-specific field names.
#
#  User logic implemented (same rules as Incident flow):
#    1. If SR is NEW / unassigned -> assign it.
#    2. If SR is already assigned:
#         - if current person is present -> keep same person, do not post update
#         - if current person is absent  -> assign to another present person
#    3. If SR status is IN PROGRESS -> do not touch it at all.
#       Keep the same assigned person even if attendance is absent.
#    4. New SRs still follow the Employee / Vendor split from ATTENDANCE.xlsx.
# ============================================================

from config import DEFAULT_EMP_SPLIT
import json
import os

ASSIGNMENT_STATE_FILE = "assignment_state_sr.json"


def _load_assignment_state():
    """Local idempotency cache: remembers successful SR assignments from previous runs.

    Kept in a SEPARATE file (assignment_state_sr.json) from the Incident flow's
    assignment_state.json so the two do not overwrite each other if run side by side.
    """
    if not os.path.exists(ASSIGNMENT_STATE_FILE):
        return {}
    try:
        with open(ASSIGNMENT_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _state_assignee(sr_no, state):
    item = (state or {}).get(str(sr_no), {})
    if isinstance(item, dict):
        return _clean(item.get("email"))
    return _clean(item)


# NOTE: Confirm the actual key names returned by SR_GetServiceRequestList once you
# have inspected a live response (see output_sr.json from step1_fetch_sr.py) and
# adjust these lists if needed. Kept broad on purpose so common variants match.
SR_ID_KEYS = ["SR ID", "SR_No", "SR No", "ServiceRequestID", "Service Request ID", "SRNo", "ID"]
ASSIGNEE_KEYS = ["Executive Email", "Assigned_Engineer_Email", "Executive Name", "Assigned Engineer", "Assignee", "Owner"]
STATUS_KEYS = ["Status", "SR Status", "Ticket Status"]


def _clean(value):
    return "" if value is None else str(value).strip()


def _norm(value):
    return _clean(value).lower().replace(" ", "")


def _get(sr, keys):
    for key in keys:
        if key in sr and _clean(sr.get(key)):
            return _clean(sr.get(key))
    return ""


def _sr_no(sr):
    return _get(sr, SR_ID_KEYS)


def _assignee(sr):
    return _get(sr, ASSIGNEE_KEYS)


def _status(sr):
    return _get(sr, STATUS_KEYS)


def _status_norm(sr):
    """Normalize SR status for reliable comparisons."""
    return _norm(_status(sr)).replace("-", "")


def _is_in_progress(sr):
    """In-progress SRs must never be assigned/reassigned by this bot."""
    return _status_norm(sr) in {"inprogress", "inprogess"}


def _person_pool(present):
    return {
        "Emp": [p["name"] for p in present.get("Emp", []) if p.get("solver") == "Y"],
        "Ven": [p["name"] for p in present.get("Ven", []) if p.get("solver") == "Y"],
    }


def _all_people(rows):
    emp = list((rows or {}).get("employee", {}).keys())
    ven = list((rows or {}).get("vendor", {}).keys())
    return {"Emp": emp, "Ven": ven, "All": emp + ven}


def _compact_identity(value):
    """Normalize names/emails for comparison: ignores case, spaces, dots, underscores and hyphens."""
    text = _norm(value)
    return (
        text.replace(".", "")
            .replace("_", "")
            .replace("-", "")
            .replace("@", "")
    )


def _email_local_part(email):
    return _clean(email).split("@")[0]


def _match_person(name_or_email, people):
    """Match exact email/name first; then safe partial match.

    API sometimes returns Executive Name, while ATTENDANCE.xlsx stores email + Name.
    This function supports both forms.
    """
    target = _clean(name_or_email)
    target_norm = _norm(target)
    target_compact = _compact_identity(target)
    target_local = _compact_identity(_email_local_part(target))

    if not target_compact:
        return ""

    # 1) Exact normalized match.
    for person in people or []:
        if _norm(person) == target_norm:
            return person

    # 2) Compare compact full value and email local-part.
    for person in people or []:
        person_compact = _compact_identity(person)
        person_local = _compact_identity(_email_local_part(person))
        candidates = [person_compact, person_local]
        for cand in candidates:
            if not cand:
                continue
            if len(target_compact) >= 3 and (target_compact in cand or cand in target_compact):
                return person
            if len(target_local) >= 3 and (target_local in cand or cand in target_local):
                return person

    return ""


def _identity_values_for_role(rows, role):
    """Return all known emails + display names for one role from attendance rows."""
    details = (rows or {}).get("details", {}) or {}
    values = []
    for email, info in details.items():
        if (info or {}).get("role") == role:
            values.append(email)
            name = _clean((info or {}).get("name"))
            if name:
                values.append(name)
    return values


def _present_identity_values(present):
    """Return present solver emails + display names from Step 2."""
    values = []
    for role in ["Emp", "Ven"]:
        for item in (present or {}).get(role, []) or []:
            if item.get("solver") == "Y":
                values.append(item.get("name", ""))          # email used internally
                values.append(item.get("display_name", ""))  # Name column from Excel
    return [v for v in values if _clean(v)]


def _role_of_person(name_or_email, rows):
    if _match_person(name_or_email, _identity_values_for_role(rows, "Emp")):
        return "Emp"
    if _match_person(name_or_email, _identity_values_for_role(rows, "Ven")):
        return "Ven"
    return ""


def _is_present(name_or_email, present, rows):
    return bool(_match_person(name_or_email, _present_identity_values(present)))


def _is_new_sr(sr, cached_assignee=""):
    """An SR is new only when there is no assignee in API and no assignee in local state.

    Do NOT treat Status=Open/New alone as unassigned, since many systems keep
    an SR "Open" even after assignment.
    """
    assignee = _assignee(sr) or cached_assignee
    if assignee:
        return False

    status = _status_norm(sr)
    if status in {"assigned", "inprogress", "inprogess", "resolved", "closed"}:
        return False

    return True


def _make_round_robin_selector(candidates):
    state = {"i": 0}

    def pick(exclude=""):
        available = [c for c in candidates if _norm(c) != _norm(exclude)]
        if not available:
            return ""
        chosen = available[state["i"] % len(available)]
        state["i"] += 1
        return chosen

    return pick


def allocate_sr_actions(sr_list, present, rows):
    """
    Returns only the SRs that must be posted to the API.

    Output list item:
      {"sr_no": "...", "email": "...", "reason": "New SR/Reassigned - Assignee Absent"}
    """

    print("\n" + "=" * 70)
    print("  STEP 3 : Service Request Decision Logic")
    print("=" * 70)

    state = _load_assignment_state()

    pools = _person_pool(present)
    pick_emp = _make_round_robin_selector(pools["Emp"])
    pick_ven = _make_round_robin_selector(pools["Ven"])
    pick_any = _make_round_robin_selector(pools["Emp"] + pools["Ven"])

    actions = []
    kept = []
    skipped = []

    new_srs = []
    for sr in sr_list:
        sno = _sr_no(sr)
        cached = _state_assignee(sno, state) if sno else ""
        if _is_new_sr(sr, cached):
            new_srs.append(sr)

    ratio = (rows or {}).get("ratio", {})
    emp_split = ratio.get("Emp", DEFAULT_EMP_SPLIT)
    ven_split = ratio.get("Ven", 1 - emp_split)
    emp_new_target = round(len(new_srs) * emp_split)
    emp_new_done = 0
    ven_new_done = 0

    print(f"\n  Total fetched SRs      : {len(sr_list)}")
    print(f"  New/unassigned SRs     : {len(new_srs)}")
    print(f"  Ratio used from Excel  : Emp {round(emp_split*100)}%, Ven {round(ven_split*100)}%")
    print(f"  Previous bot assignments loaded: {len(state)}")
    print(f"  New SR split           : Emp {emp_new_target}, Ven {len(new_srs) - emp_new_target}")

    for sr in sr_list:
        sr_no = _sr_no(sr)
        api_current = _assignee(sr)
        cached_current = _state_assignee(sr_no, state) if sr_no else ""
        current = api_current or cached_current

        if not sr_no:
            skipped.append({"sr_no": "", "reason": "SR number missing"})
            continue

        # Hard rule: In Progress SR must remain with current assignee.
        if _is_in_progress(sr):
            kept.append({
                "sr_no": sr_no,
                "email": current,
                "reason": "In Progress - no touching"
            })
            continue

        # Case 1: New SR -> assign to present person using Excel split.
        if _is_new_sr(sr, cached_current):
            if emp_new_done < emp_new_target:
                email = pick_emp() or pick_any()
                emp_new_done += 1
                role = "Emp"
            else:
                email = pick_ven() or pick_any()
                ven_new_done += 1
                role = "Ven"

            if email:
                actions.append({"sr_no": sr_no, "email": email, "reason": f"New SR -> {role}"})
            else:
                skipped.append({"sr_no": sr_no, "reason": "No present person available for new SR"})
            continue

        # Case 2: Already assigned and person is present -> keep as it is.
        if _is_present(current, present, rows):
            kept.append({"sr_no": sr_no, "email": current, "reason": "Already assigned person is present"})
            continue

        # Case 3: Already assigned but person absent -> reassign.
        role = _role_of_person(current, rows)
        if role == "Emp":
            email = pick_emp(exclude=current) or pick_any(exclude=current)
        elif role == "Ven":
            email = pick_ven(exclude=current) or pick_any(exclude=current)
        else:
            email = pick_any(exclude=current)

        if email:
            actions.append({"sr_no": sr_no, "email": email, "reason": "Reassigned - current assignee absent"})
        else:
            skipped.append({"sr_no": sr_no, "reason": f"Current assignee absent, but no present replacement found ({current})"})

    print(f"\n  -- KEPT SAME (No API update) -------------------")
    if kept:
        for item in kept:
            print(f"  {item['sr_no']:<15} stays with {item['email']}  ({item.get('reason', '')})")
    else:
        print("  None")

    print(f"\n  -- WILL BE ASSIGNED / REASSIGNED ---------------")
    if actions:
        for item in actions:
            print(f"  {item['sr_no']:<15} -> {item['email']:<45} {item['reason']}")
    else:
        print("  None")

    if skipped:
        print(f"\n  -- SKIPPED -------------------------------------")
        for item in skipped:
            print(f"  {item['sr_no'] or 'UNKNOWN':<15} {item['reason']}")

    return actions, kept, skipped


if __name__ == "__main__":
    sample_present = {
        "Emp": [{"name": "rahul@maruti.co.in", "solver": "Y"}],
        "Ven": [{"name": "neha@maruti.co.in", "solver": "Y"}],
    }
    sample_rows = {
        "employee": {"rahul@maruti.co.in": "P", "amit@maruti.co.in": "A"},
        "vendor": {"neha@maruti.co.in": "P"},
    }
    sample_sr_list = [
        {"SR ID": "SR001", "Status": "Assigned", "Executive Name": "rahul@maruti.co.in"},
        {"SR ID": "SR002", "Status": "Assigned", "Executive Name": "amit@maruti.co.in"},
        {"SR ID": "SR003", "Status": "New", "Executive Name": ""},
    ]
    allocate_sr_actions(sample_sr_list, sample_present, sample_rows)

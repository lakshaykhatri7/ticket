# ============================================================
#  step1_fetch_sr.py
#  Fetches the Service Request (SR) list from the API and saves Excel + JSON.
#  Mirrors step1_fetch_tickets.py (which fetches Incidents) but uses the
#  SR_GetServiceRequestList service and its objSR_SearchFilterParam block.
#
#  Output : sr_ddmmyy_hhmmss.xlsx          -> full data
#            sr_summary_ddmmyy_hhmmss.xlsx  -> selected columns only
#            output_sr.json                 -> Raw JSON response
# ============================================================

import requests
import json
import pandas as pd
from datetime import datetime
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP, FETCH_STATUS

# Adjust these to match the actual field names returned by SR_GetServiceRequestList
SUMMARY_COLUMNS = [
    "SR ID",
    "Logged Time",
    "Status",
    "Symptom",
    "Workgroup Name",
    "Executive Name",
    "FullCategory",
]


def fetch_service_requests(page_size=100, executive=1, category=None, catalog_name=None):
    """
    Calls the SR_GetServiceRequestList API to fetch service requests.
    Returns: (excel_filename, sr_number_list, sr_rows)
    """

    print("\n" + "=" * 55)
    print("  STEP 1 : Fetching Service Request List from API")
    print("=" * 55)

    filter_params = {
        "Executive": executive,
        # "WorkGroupID": 114,
        "Assigned_WorkGroup_Name": WORKGROUP,
        "CurrentPageIndex": 0,
        "PageSize": page_size,
        "OrgID": str(ORG_ID),
        "Instance": INSTANCE,
        "Status": FETCH_STATUS,
        "IsWebServiceRequest": True,
    }

    # Optional filters - only added if explicitly passed in
    if category:
        filter_params["Category"] = category
    if catalog_name:
        filter_params["CatalogName"] = catalog_name

    payload = {
        "ServiceName": "SR_GetServiceRequestList",
        "objCommonParameters": {
            "_ProxyDetails": {
                "AuthType": "APIKEY",
                "APIKey": API_KEY,
                "TokenID": "",
                "OrgID": str(ORG_ID),
                "ReturnType": "JSON",
                "ProxyID": 0,
            },
            "objSR_SearchFilterParam": filter_params,
        },
    }

    try:
        print("  Calling API...")
        response = requests.post(API_URL, json=payload, timeout=30)
        print(f"  Status Code : {response.status_code}")

        # ---- Failure check ----
        if response.status_code != 200:
            print("  [ERROR] API did not return 200. Response:")
            print("    ", response.text[:300])
            return None, [], []

        data = response.json()

        # ---- Raw JSON save ----
        with open("output_sr.json", "w") as f:
            json.dump(data, f, indent=4)
        print("  [OK] Raw JSON saved  -> output_sr.json")

        # ---- Extract service requests ----
        # NOTE: confirm the actual key name in the response (e.g. "MyServiceRequests",
        # "MySR", "SRList") by inspecting output_sr.json after your first live call,
        # then update the key below accordingly.
        sr_list = data.get("OutputObject", {}).get("MyServiceRequests", [])

        if not sr_list:
            print("  [WARNING] No service requests found in response.")
            return None, [], []

        print(f"  Total Service Requests found : {len(sr_list)}")

        # ---- JSON -> DataFrame ----
        df = pd.DataFrame(sr_list)
        timestamp = datetime.now().strftime("%d%m%y_%H%M%S")

        # ---- Excel #1 : Full data ----
        excel_filename = f"sr_{timestamp}.xlsx"
        df.to_excel(excel_filename, index=False)
        print(f"  [OK] Full Excel saved     -> {excel_filename}")

        # ---- Excel #2 : Summary (selected columns only) ----
        missing_cols = [c for c in SUMMARY_COLUMNS if c not in df.columns]
        if missing_cols:
            print(f"  [WARNING] These columns were not in the response (will be blank): {missing_cols}")

        summary_df = df.reindex(columns=SUMMARY_COLUMNS)
        summary_df["Assigned by Bot"] = "Yes"
        summary_filename = f"sr_summary_{timestamp}.xlsx"
        summary_df.to_excel(summary_filename, index=False)
        print(f"  [OK] Summary Excel saved  -> {summary_filename}")

        # ---- SR numbers list ----
        # NOTE: confirm the actual ID column name (e.g. "SR ID", "SR_No", "ServiceRequestID")
        # once you inspect a real response, then update the check below.
        if "SR ID" in df.columns:
            sr_numbers = df["SR ID"].astype(str).tolist()
        else:
            sr_numbers = []
            print("  [WARNING] 'SR ID' column not found in DataFrame.")

        return excel_filename, sr_numbers, sr_list

    except requests.exceptions.ConnectionError:
        print("  [ERROR] Could not connect to server. Check network/URL.")
        return None, [], []
    except Exception as e:
        print(f"  [ERROR] Unexpected error: {e}")
        return None, [], []


# ---- Standalone run ----
if __name__ == "__main__":
    excel_file, sr_numbers, sr_rows = fetch_service_requests()
    if sr_numbers:
        print(f"\n  SR Numbers : {sr_numbers[:5]} ... (total {len(sr_numbers)})")

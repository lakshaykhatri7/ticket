# ============================================================
#  main_sr.py -- Service Request Management -- Full Auto Flow
#
#  Logic (mirrors main.py used for Incidents):
#   1. Fetch service requests from API (SR_GetServiceRequestList)
#   2. Read attendance from ATTENDANCE.xlsx
#   3. New SRs -> assign to present person
#   4. In Progress SRs -> do not touch, keep same assignee
#   5. Already assigned SRs:
#        - assignee present -> remain assigned to same person
#        - assignee absent  -> reassign to present person
#   6. Post only SRs that need assignment/reassignment
#
#  Run: python main_sr.py
# ============================================================

from datetime import datetime
from step1_fetch_sr import fetch_service_requests
from step2_attendance import check_attendance
from step3_allocate_sr import allocate_sr_actions
from step4_post_sr import post_sr_actions
from step5_report_sr import create_sr_assignment_report


def main():
    print("\n" + "*" * 55)
    print("   SERVICE REQUEST MANAGEMENT SYSTEM -- Full Auto Flow")
    print("*" * 55)

    date = datetime.now().strftime("%d-%m-%Y")
    print(f"\n  Using today's date : {date}")

    # STEP 1: Fetch service requests
    excel_file, sr_numbers, sr_rows = fetch_service_requests()

    if not sr_rows:
        print("\n[WARNING] No service requests fetched. Stopping program.")
        return

    print(f"\n  Total Service Requests (auto-detected) : {len(sr_rows)}")

    # STEP 2: Attendance (shared logic/file with the Incident flow)
    present, absent, rows = check_attendance(date)

    if present is None:
        print("\n[ERROR] Attendance not found. Stopping program.")
        return

    # STEP 3: Apply user logic SR-by-SR
    actions, kept, skipped = allocate_sr_actions(sr_rows, present, rows)

    post_results = []

    # STEP 4: Post only required SRs
    if not actions:
        print("\nNo SR needs assignment/reassignment. Nothing to post.")
    else:
        confirm = input("\nPost only these required SR updates via API now? (y/n): ").strip().lower()

        if confirm == "y":
            post_results = post_sr_actions(actions)
        else:
            print("\nAPI posting skipped.")

    # STEP 5: Final Excel report for every fetched SR
    create_sr_assignment_report(sr_rows, actions, kept, skipped, rows, post_results)

    print("\n" + "*" * 55)
    print("   Done!")
    print("*" * 55)


if __name__ == "__main__":
    main()

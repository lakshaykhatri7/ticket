# ============================================================
#  config.py — Saari settings ek jagah
#  Sirf yahan changes karo, baaki files mat chhuo
# ============================================================

# --- API Settings ---
API_URL = "http://msilstaging/Webservice/REST/Summit_RESTWCF.svc/RESTService/CommonWS_JsonObjCall"
API_KEY = "sWkL0CqC1bikNDIJvI66eNxPVBMgNTtlSX31d5kZ4OM="
ORG_ID  = 1
INSTANCE = "ITD"

# --- Workgroup & Assignment ---
WORKGROUP       = "SAP_MDM - OTH"
# NOTE: Fixed ASSIGNED_EMAIL hata diya gaya — ab har ticket allocation
# ATTENDANCE.xlsx ke column header (jo ab email IDs hain) se hi
# "Assigned_Engineer_Email" set hota hai (step4_post_tickets.py mein).

# --- Excel / Data File ---
# ATTENDANCE.xlsx mein 2 sheets hain: "employee" aur "vendor"
EXCEL_FILE = "ATTENDANCE.xlsx"

# --- Ticket Split ---
TOTAL_TICKETS = 16
EMP_SPLIT     = 0.30   # 30% employees, 70% vendors

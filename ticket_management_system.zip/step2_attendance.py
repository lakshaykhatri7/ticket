# ============================================================
#  step2_attendance.py
#  Reads attendance from ATTENDANCE.xlsx -- 2 sheets:
#    "employee" -> Date | <employee email columns, P/A>
#    "vendor"   -> Date | <vendor email columns, P/A>
#
#  NOTE: There is no "Solver/Not" column anymore. Everyone who is
#  Present is treated as a solver (everyone present gets tickets) --
#  this was confirmed with the user.
# ============================================================

import pandas as pd
from datetime import datetime
from config import EXCEL_FILE


def _read_sheet_status(date, sheet_name):
    """
    Reads one sheet (employee/vendor), finds the row for the given date,
    and returns a dict of each person's P/A status.
    Returns None if the date/sheet/file is not found.
    """
    try:
        df = pd.read_excel(EXCEL_FILE, sheet_name=sheet_name)
    except FileNotFoundError:
        print(f"  File not found: {EXCEL_FILE}")
        return None
    except ValueError:
        print(f"  Sheet '{sheet_name}' not found in {EXCEL_FILE}.")
        return None

    df.columns = df.columns.str.strip()
    df["Date"] = pd.to_datetime(df["Date"]).dt.strftime("%d-%m-%Y")

    row = df[df["Date"] == date]
    if row.empty:
        return None

    row = row.iloc[0]
    person_cols = [c for c in df.columns if c != "Date"]

    return {email: str(row[email]).strip().upper() for email in person_cols}


def check_attendance(date):
    """
    Checks attendance for the given date (employee + vendor sheets).

    Returns:
        present (dict) : { "Emp": [{email, solver}], "Ven": [...] }
        absent  (dict) : { "Emp": [email,...],        "Ven": [...] }
        rows    (dict or None) : { "employee": {...}, "vendor": {...} } raw status
    """

    print("\n" + "="*70)
    print("  STEP 2 : Attendance Check  (ATTENDANCE.xlsx)")
    print("="*70)

    emp_status = _read_sheet_status(date, "employee")
    ven_status = _read_sheet_status(date, "vendor")

    if emp_status is None and ven_status is None:
        print(f"  Date '{date}' not found in either sheet (employee/vendor).")
        return None, None, None

    present = {"Emp": [], "Ven": []}
    absent  = {"Emp": [], "Ven": []}

    # ---- Table Header ----
    print(f"\n  Date : {date}\n")
    print(f"  {'Email':<38} {'Type':<6} Status")
    print(f"  {'-'*60}")

    for role, statuses in [("Emp", emp_status), ("Ven", ven_status)]:
        if not statuses:
            continue
        for email, status in statuses.items():
            if status == "P":
                # No Solver/Not column -- present is treated as solver
                present[role].append({"email": email, "solver": "Y"})
                icon = "Present"
            else:
                absent[role].append(email)
                icon = "Absent "
            print(f"  {email:<38} {role:<6} {icon}")

    # ---- Summary ----
    print(f"\n  -- SUMMARY --------------------------------------")
    print(f"  Present Employees : {[p['email'] for p in present['Emp']] or 'None'}")
    print(f"  Present Vendors   : {[p['email'] for p in present['Ven']] or 'None'}")
    print(f"  Absent Employees  : {absent['Emp'] or 'None'}")
    print(f"  Absent Vendors    : {absent['Ven'] or 'None'}")

    return present, absent, {"employee": emp_status, "vendor": ven_status}


# ---- Standalone run ----
if __name__ == "__main__":
    # Manual date input removed -- uses today's date automatically
    date = datetime.now().strftime("%d-%m-%Y")
    print(f"  Using today's date : {date}")
    present, absent, row = check_attendance(date)

# ============================================================
#  main.py — Ticket Management System — Full Auto Flow
#
#  Steps:
#   1. Fetch ticket list from API   -> save Excel + JSON
#   2. Check attendance             -> split Present / Absent
#   3. Allocate tickets:
#        Status "New"      -> 30/70 Employee/Vendor split
#        Status "Assigned" -> stays with current person if Present,
#                              else reassigned within the same role
#   4. Assign via API               -> save result to Excel
#
#  Run: python main.py
# ============================================================

from datetime import datetime
from step1_fetch_tickets import fetch_tickets
from step2_attendance    import check_attendance
from step3_allocate      import allocate_tickets
from step4_post_tickets  import post_tickets


def main():
    print("\n" + "*"*55)
    print("   TICKET MANAGEMENT SYSTEM - Full Auto Flow")
    print("*"*55)

    # -- Date (automatic - uses today's date, manual input removed) --
    date = datetime.now().strftime("%d-%m-%Y")
    print(f"\n  Using today's date : {date}")

    # -- STEP 1: API Fetch --------------------------------------
    excel_file, ticket_numbers, ticket_info = fetch_tickets()
    print(f"\n  Total Tickets (auto-detected) : {len(ticket_numbers)}")

    # -- STEP 2: Attendance ---------------------------------------
    present, absent, rows = check_attendance(date)

    if present is None:
        print("\nAttendance not found. Stopping program.")
        return

    # -- STEP 3: Allocation -----------------------------------------
    final_assignment = allocate_tickets(ticket_info, present, rows)

    if not final_assignment:
        print("\nNo one received any tickets. Stopping program.")
        return

    # -- STEP 4: Post via API -----------------------------------------
    confirm = input("\nAssign tickets via API? (y/n): ").strip().lower()

    if confirm == "y":
        post_tickets(final_assignment)
    else:
        print("\nAPI posting skipped.")

    print("\n" + "*"*55)
    print("   Done!")
    print("*"*55)


if __name__ == "__main__":
    main()

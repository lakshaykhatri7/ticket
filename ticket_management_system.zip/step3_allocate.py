# ============================================================
#  step3_allocate.py
#  Decides who gets each ticket, based on the ticket's Status.
#
#  Rule:
#    Status = "New"
#       -> goes into the 30-70 Employee/Vendor split
#          (Employees 30% | Vendors 70%), shared equally among
#          the Present people in each role.
#
#    Status = "Assigned"
#       -> stays with the person it's already assigned to
#          (matched by "Executive Name" against the emails in
#          ATTENDANCE.xlsx), IF that person is Present today.
#       -> if that person is Absent today, the ticket is handed
#          to another Present person in the SAME role
#          (Employee stays Employee, Vendor stays Vendor),
#          split equally among them.
#
#    Any other / unrecognised Status
#       -> skipped, printed clearly as a warning so it can be
#          checked manually.
# ============================================================

from config import EMP_SPLIT


def _normalize_name(text):
    """
    Turns an email's local-part or an 'Executive Name' string into a
    normalized, order-independent set of words, so the two can be
    matched even if formatted differently
    (e.g. email 'JKTECH_Neha.Aswal' vs ticket name 'Neha Aswal').
    """
    text = str(text).strip()
    if "_" in text:
        # drop a vendor-company prefix, e.g. JKTECH_ / DTL_ / MYSOFTLABS_
        text = text.split("_")[-1]
    text = text.replace(".", " ").replace("_", " ")
    words = [w.lower() for w in text.split() if w]
    return tuple(sorted(words))


def _build_name_lookup(rows):
    """
    Builds { normalized_name : {"email", "role", "present"} } using the
    FULL attendance rows (present + absent people) from step2, so an
    'Executive Name' can be matched to an email no matter whether that
    person is present today or not.
    """
    lookup = {}
    role_map = {"employee": "Emp", "vendor": "Ven"}

    for sheet, role in role_map.items():
        statuses = (rows or {}).get(sheet) or {}
        for email, status in statuses.items():
            key = _normalize_name(email.split("@")[0])
            lookup[key] = {
                "email": email,
                "role": role,
                "present": status == "P"
            }
    return lookup


def _split_equally(people, share):
    """
    Equal split of `share` items among `people` (list of emails).
    Remainder is handed out to the first ones, one by one.
    Returns { email : count }.
    """
    result = {}
    if not people or share <= 0:
        return result
    for i, email in enumerate(people):
        result[email] = share // len(people) + (1 if i < share % len(people) else 0)
    return result


def _hand_out(ticket_pool, people, final_assignment, label):
    """
    Splits ticket_pool equally among people and records the exact
    ticket numbers each person gets into final_assignment.
    """
    if not ticket_pool:
        return
    if not people:
        print(f"  No Present {label} -- {len(ticket_pool)} ticket(s) skipped: {ticket_pool}")
        return

    counts = _split_equally(people, len(ticket_pool))
    idx = 0
    for email, count in counts.items():
        chunk = ticket_pool[idx: idx + count]
        idx += count
        if not chunk:
            continue
        final_assignment.setdefault(email, []).extend(chunk)
        print(f"  {email:<38} <- {chunk}")


def allocate_tickets(ticket_info, present, rows):
    """
    Args:
        ticket_info (dict): { ticket_no : {"Status":.., "Executive Name":..} }
                             -- from step1
        present (dict)    : { "Emp":[{email,solver}], "Ven":[...] }
                             -- from step2 (Present people only)
        rows (dict)       : { "employee":{email:P/A}, "vendor":{email:P/A} }
                             -- from step2 (EVERYONE, present + absent)

    Returns:
        final_assignment (dict): { email : [ticket_no, ticket_no, ...] }
    """

    print("\n" + "="*55)
    print("  STEP 3 : Ticket Allocation")
    print("="*55)

    name_lookup = _build_name_lookup(rows)

    new_tickets        = []              # Status == New
    direct_assign      = {}              # ticket_no -> email (Assigned + Present)
    reassign_pool       = {"Emp": [], "Ven": []}   # Assigned + Absent
    unmatched_tickets   = []             # Assigned, but name didn't match anyone
    skipped_tickets     = []             # any other/unknown status

    for ticket_no, info in ticket_info.items():
        status = str(info.get("Status", "")).strip().lower()
        exec_name = info.get("Executive Name", "")

        if status == "new":
            new_tickets.append(ticket_no)

        elif status == "assigned":
            match = name_lookup.get(_normalize_name(exec_name))

            if not match:
                unmatched_tickets.append(ticket_no)
                print(f"  [WARN] Ticket {ticket_no}: assigned executive "
                      f"'{exec_name}' not found in ATTENDANCE.xlsx -- skipped.")
                continue

            if match["present"]:
                direct_assign[ticket_no] = match["email"]
            else:
                reassign_pool[match["role"]].append(ticket_no)

        else:
            skipped_tickets.append(ticket_no)
            print(f"  [WARN] Ticket {ticket_no}: unrecognised Status "
                  f"'{info.get('Status')}' -- skipped.")

    final_assignment = {}

    # ---- 1) Already-Assigned tickets, person Present -> stays put ----
    print(f"\n  -- Assigned tickets, person Present (stays as-is) --------")
    if direct_assign:
        for ticket_no, email in direct_assign.items():
            final_assignment.setdefault(email, []).append(ticket_no)
            print(f"  Ticket {ticket_no:<10} -> stays with {email}")
    else:
        print("  None")

    # ---- 2) Already-Assigned tickets, person Absent -> reassign, same role ----
    print(f"\n  -- Assigned tickets, person Absent (reassigned, same role) --")
    any_reassigned = False
    for role, tickets in reassign_pool.items():
        if not tickets:
            continue
        any_reassigned = True
        label = "Employees" if role == "Emp" else "Vendors"
        present_people = [p["email"] for p in present[role]]
        print(f"  {label} : {tickets}")
        _hand_out(tickets, present_people, final_assignment, label)
    if not any_reassigned:
        print("  None")

    # ---- 3) New tickets -> 30/70 Employee/Vendor split ----
    total_new = len(new_tickets)
    emp_total = round(total_new * EMP_SPLIT)
    ven_total = total_new - emp_total

    print(f"\n  -- New tickets : 30/70 split (Emp 30% | Ven 70%) ----------")
    print(f"  Total New Tickets : {total_new}")
    print(f"  Employee Share    : {emp_total}")
    print(f"  Vendor Share      : {ven_total}")

    pool = list(new_tickets)
    idx = 0
    for role, share in [("Emp", emp_total), ("Ven", ven_total)]:
        label = "Employees" if role == "Emp" else "Vendors"
        chunk = pool[idx: idx + share]
        idx += share
        present_people = [p["email"] for p in present[role] if p["solver"] == "Y"]
        print(f"\n  -- {label} --")
        _hand_out(chunk, present_people, final_assignment, label)

    # ---- FINAL SUMMARY ----
    print(f"\n  -- FINAL ALLOCATION --------------------------")
    if final_assignment:
        for email, tickets in final_assignment.items():
            print(f"  {email:<38} : {len(tickets)} ticket(s) {tickets}")
    else:
        print("  Nobody received any tickets.")

    if unmatched_tickets:
        print(f"\n  Unmatched (Executive Name not found in ATTENDANCE.xlsx) : {unmatched_tickets}")
    if skipped_tickets:
        print(f"  Skipped (unrecognised Status)                            : {skipped_tickets}")

    return final_assignment


# ---- Standalone run ----
if __name__ == "__main__":
    # Test data
    sample_ticket_info = {
        "653501": {"Status": "New",      "Executive Name": ""},
        "653502": {"Status": "New",      "Executive Name": ""},
        "653503": {"Status": "New",      "Executive Name": ""},
        "653504": {"Status": "Assigned", "Executive Name": "Vaibhav Agarwal"},   # present
        "653505": {"Status": "Assigned", "Executive Name": "Robin Jain"},        # absent -> reassigned
        "653506": {"Status": "New",      "Executive Name": ""},
    }
    sample_present = {
        "Emp": [{"email": "vaibhav.agarwal@marui", "solver": "Y"},
                {"email": "akshita.bhandari@maruti.co.in", "solver": "Y"}],
        "Ven": [{"email": "jktech_neha.aswal@maruti.co.in", "solver": "Y"},
                {"email": "dtl_ayushkumar.choubey@maruti.co.in", "solver": "Y"}]
    }
    sample_rows = {
        "employee": {
            "vaibhav.agarwal@marui": "P",
            "akshita.bhandari@maruti.co.in": "P",
            "robin.jain@maruti.co.in": "A",
        },
        "vendor": {
            "jktech_neha.aswal@maruti.co.in": "P",
            "dtl_ayushkumar.choubey@maruti.co.in": "P",
        }
    }
    allocate_tickets(sample_ticket_info, sample_present, sample_rows)

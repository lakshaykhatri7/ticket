Script 2 — New Tickets Only
========================================================================

Run:
  python main_new_only.py

This is a SEPARATE, standalone project from Script 1 (TM2_SR_project.zip).
It does NOT read or write Script 1's files (uses its own state file:
assignment_state_new_only.json).

What it does:
  1. Fetches ALL tickets from the API (SR_GetServiceRequestList) - same
     as script 1, saves sr_all_raw_*.xlsx (unfiltered, all workgroups).
  2. Filters down to OUR workgroup only (client-side filter, same logic
     as script 1) - saves sr_*.xlsx / sr_summary_*.xlsx (our workgroup only).
  3. Reads attendance from ATTENDANCE.xlsx.
  4. ONLY assigns tickets with Status = "New" to a present person, using
     the Employee/Vendor split ratio from ATTENDANCE.xlsx.
     - Pending, In Progress, Assigned, Resolved, Closed, or any other
       status: COMPLETELY UNTOUCHED. Not even checked for attendance.
       No API call is made for them.
  5. Posts only the New-ticket assignments to the API.

Files:
- config.py                    Shared settings (reused from script 1)
- ATTENDANCE.xlsx              Same attendance file
- step1_fetch_sr.py            Fetch + workgroup filter (identical to script 1)
- step2_attendance.py          Attendance/ratio logic (identical to script 1)
- step3_allocate_new_only.py   NEW-ONLY allocation logic (simplified)
- step4_post_new_only.py       Posts only New ticket assignments
- main_new_only.py              Full flow orchestration

============================================================
IMPORTANT — SAME UNCONFIRMED CAVEAT AS SCRIPT 1
============================================================
step4_post_new_only.py uses the same BEST-GUESS "assign SR" payload as
script 1's step4_post_sr.py (ServiceName: "SR_LogOrUpdateServiceRequest").
This has not been confirmed against a real working payload from your
backend/API team. Once you have a confirmed sample, send it over and both
script 1 and script 2's post files can be corrected together.

# ============================================================
#  step4_post_new_only.py
#  SCRIPT 2 - posts only the New-ticket assignments decided by
#  step3_allocate_new_only.py.
#
#  *** IMPORTANT / UNCONFIRMED (same caveat as script 1) ***
#  No real "assign/update SR" sample payload was provided - only the SR
#  *list* payload. The ServiceName/field names below are a best-guess
#  mirror of the Incident update payload. Verify against a real sample
#  before trusting this in production. See README2.txt for details.
#
#  Output: new_ticket_result_ddmmyy_hhmmss.xlsx
# ============================================================

import requests
import pandas as pd
from datetime import datetime
import json
import os
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP

ASSIGNMENT_STATE_FILE = "assignment_state_new_only.json"


def _load_assignment_state():
    if not os.path.exists(ASSIGNMENT_STATE_FILE):
        return {}
    try:
        with open(ASSIGNMENT_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_successful_assignment(sr_no, email):
    state = _load_assignment_state()
    state[str(sr_no)] = {
        "email": str(email).strip(),
        "workgroup": WORKGROUP,
        "updated_at": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
    }
    with open(ASSIGNMENT_STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=4)


def post_new_ticket_actions(actions):
    """
    Posts only New-ticket assignments.

    Args:
        actions: list of {sr_no, email, reason} from allocate_new_tickets()
    """

    print("\n" + "=" * 70)
    print("  STEP 4 (Script 2) : Posting New Ticket Assignments via API")
    print("=" * 70)

    if not actions:
        print("  No New tickets to assign. Nothing to post.")
        return []

    print(f"\n  Total New tickets to post : {len(actions)}")
    print(f"  {'SR No':<15} {'Email':<45} Reason")
    print(f"  {'-'*90}")
    for item in actions:
        print(f"  {item['sr_no']:<15} {item['email']:<45} {item.get('reason', '')}")

    results = []

    for item in actions:
        sr_no = item["sr_no"]
        email = item["email"]
        reason = item.get("reason", "New ticket auto assignment")

        print(f"\n  Posting SR {sr_no} -> {email} ...")

        # ---- BEST-GUESS payload - see file header note ----
        payload = {
            "ServiceName": "SR_LogOrUpdateServiceRequest",
            "objCommonParameters": {
                "_ProxyDetails": {
                    "AuthType": "APIKEY",
                    "APIKey": API_KEY,
                    "ProxyID": 0,
                    "ReturnType": "JSON",
                    "OrgID": ORG_ID
                },
                "srParamsJSON": {
                    "SRContainerJsonObj": {
                        "Updater": "Executive",
                        "SR": {
                            "IsFromWebService": True,
                            "SR_No": sr_no,
                            "Sup_Function": INSTANCE,
                            "Status": "Assigned",
                            "Assigned_WorkGroup_Name": WORKGROUP,
                            "Medium": "API",
                            "Source": "API Call",
                            "Assigned_Engineer_Email": email,
                            "PageName": "LogSR"
                        },
                        "SRInformation": {
                            "Information": f"{reason}: auto-assigned to {email} via Python"
                        },
                        "CustomFields": []
                    }
                },
                "RequestType": "RemoteCall"
            }
        }

        try:
            resp = requests.post(API_URL, json=payload, timeout=30)
            if resp.status_code == 200:
                print(f"  [OK] Success -- SR {sr_no} assigned to {email}.")
                _save_successful_assignment(sr_no, email)
                result_status = "Success"
            else:
                print(f"  [FAILED] ({resp.status_code}) -- SR {sr_no}")
                result_status = f"Failed_{resp.status_code}"

            results.append({
                "SR_No": sr_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": resp.status_code,
                "Result": result_status,
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })

        except requests.exceptions.ConnectionError:
            print(f"  [ERROR] Connection error -- SR {sr_no}")
            results.append({
                "SR_No": sr_no, "Email": email, "Reason": reason,
                "Status_Code": "N/A", "Result": "Connection Error",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })
        except Exception as e:
            print(f"  [ERROR] {e}")
            results.append({
                "SR_No": sr_no, "Email": email, "Reason": reason,
                "Status_Code": "N/A", "Result": f"Error: {str(e)}",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })

    if results:
        ts = datetime.now().strftime("%d%m%y_%H%M%S")
        result_file = f"new_ticket_result_{ts}.xlsx"
        pd.DataFrame(results).to_excel(result_file, index=False)
        print(f"\n  [OK] Result saved -> {result_file}")

        success = sum(1 for r in results if r["Result"] == "Success")
        print(f"\n  -- POST SUMMARY --------------------------------")
        print(f"  Total Posted : {len(results)}")
        print(f"  Success      : {success}")
        print(f"  Failed       : {len(results) - success}")

    return results


if __name__ == "__main__":
    sample_actions = [
        {"sr_no": "SR003", "email": "Akshita.Bhandari@maruti.co.in", "reason": "New ticket -> Emp"},
    ]
    post_new_ticket_actions(sample_actions)

# ============================================================
#  step2_attendance.py
#  ATTENDANCE.xlsx se attendance padhta hai — 2 sheets:
#    "employee" → Date | <employee name columns, P/A>
#    "vendor"   → Date | <vendor name columns, P/A>
#
#  NOTE: "Solver/Not" column ab nahi hai. Sab Present logon ko
#  solver maana jaata hai (sabko tickets milte hain) — user
#  confirmation ke baad ye decision liya gaya.
# ============================================================

import pandas as pd
from datetime import datetime
from config import EXCEL_FILE


def _read_sheet_status(date, sheet_name):
    """
    Ek sheet (employee/vendor) padhta hai, diye gaye date ki row dhundta hai
    aur har person column ka P/A status dict mein return karta hai.
    Date na milne par ya sheet/file na milne par None return karta hai.
    """
    try:
        df = pd.read_excel(EXCEL_FILE, sheet_name=sheet_name)
    except FileNotFoundError:
        print(f"  ❌ File nahi mili: {EXCEL_FILE}")
        return None
    except ValueError:
        print(f"  ❌ Sheet '{sheet_name}' {EXCEL_FILE} mein nahi mili.")
        return None

    df.columns = df.columns.str.strip()
    df["Date"] = pd.to_datetime(df["Date"]).dt.strftime("%d-%m-%Y")

    row = df[df["Date"] == date]
    if row.empty:
        return None

    row = row.iloc[0]
    person_cols = [c for c in df.columns if c != "Date"]

    return {name: str(row[name]).strip().upper() for name in person_cols}


def check_attendance(date):
    """
    Diye gaye date ke liye attendance check karta hai (employee + vendor sheets).

    Returns:
        present (dict) : { "Emp": [{name, solver}], "Ven": [...] }
        absent  (dict) : { "Emp": [name,...],        "Ven": [...] }
        rows    (dict ya None) : { "employee": {...}, "vendor": {...} } raw status
    """

    print("\n" + "="*55)
    print("  STEP 2 : Attendance Check  (ATTENDANCE.xlsx)")
    print("="*55)

    emp_status = _read_sheet_status(date, "employee")
    ven_status = _read_sheet_status(date, "vendor")

    if emp_status is None and ven_status is None:
        print(f"  ❌ Date '{date}' kisi bhi sheet (employee/vendor) mein nahi mili.")
        return None, None, None

    present = {"Emp": [], "Ven": []}
    absent  = {"Emp": [], "Ven": []}

    # ---- Table Header ----
    print(f"\n  📅 Date : {date}\n")
    print(f"  {'Name':<22} {'Type':<6} Status")
    print(f"  {'-'*40}")

    for role, statuses in [("Emp", emp_status), ("Ven", ven_status)]:
        if not statuses:
            continue
        for name, status in statuses.items():
            if status == "P":
                # Solver/Not column nahi hai — present = solver maan lo
                present[role].append({"name": name, "solver": "Y"})
                icon = "✅ Present"
            else:
                absent[role].append(name)
                icon = "❌ Absent "
            print(f"  {name:<22} {role:<6} {icon}")

    # ---- Summary ----
    print(f"\n  ── SUMMARY ──────────────────────────────────")
    print(f"  Present Employees : {[p['name'] for p in present['Emp']] or 'None'}")
    print(f"  Present Vendors   : {[p['name'] for p in present['Ven']] or 'None'}")
    print(f"  Absent Employees  : {absent['Emp'] or 'None'}")
    print(f"  Absent Vendors    : {absent['Ven'] or 'None'}")

    return present, absent, {"employee": emp_status, "vendor": ven_status}


# ---- Standalone run ----
if __name__ == "__main__":
    # Manual date input hata diya — automatic aaj ki date use hogi
    date = datetime.now().strftime("%d-%m-%Y")
    print(f"  📅 Aaj ki date use ho rahi hai : {date}")
    present, absent, row = check_attendance(date)

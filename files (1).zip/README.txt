============================================================
  TICKET MANAGEMENT SYSTEM — Project Guide
============================================================

── PROJECT FILES ───────────────────────────────────────────

  config.py              → Saari settings yahan badlo
  main.py                → Poora flow chalao (yahi run karo)

  step1_fetch_tickets.py → API se tickets fetch → 2 Excel + JSON save
  step2_attendance.py    → ATTENDANCE.xlsx se Present / Absent
  step3_allocate.py      → 30-70 split, sirf present logon ko tickets
  step4_post_tickets.py  → API se tickets assign karo

  guessno.py              → 4-Digit Guessing Game (bonus!)

── SETUP ───────────────────────────────────────────────────

  1. Python install karo (3.8+)
  2. Libraries install karo:
       pip install requests pandas openpyxl

  3. config.py kholo aur ye fields set karo:
       API_URL       → server ka address
       API_KEY       → tumhara API key
       EXCEL_FILE    → "ATTENDANCE.xlsx"
       TOTAL_TICKETS → kitne tickets hain
       EMP_SPLIT     → 0.30 (Employee 30% | Vendor 70%)
       ASSIGNED_EMAIL→ engineer ka email

── ATTENDANCE FILE FORMAT (ATTENDANCE.xlsx) ────────────────

  2 sheets honi chahiye:

    Sheet "employee":
      Date       | Excel date format
      <Name1>    | P (Present) ya A (Absent)
      <Name2>    | P ya A
      ... (baaki employees aise hi, har naam apna column)

    Sheet "vendor":
      Date       | Excel date format
      <Name1>    | P ya A
      <Name2>    | P ya A
      ... (baaki vendors aise hi)

  NOTE: Solver/Not column ab nahi hai. Jo bhi Present hai,
  use solver maan liya jaata hai — sabko tickets milte hain.

── RUN KARO ────────────────────────────────────────────────

  Poora system ek saath:
    python main.py

  Alag alag step:
    python step1_fetch_tickets.py
    python step2_attendance.py
    python step3_allocate.py
    python step4_post_tickets.py

  Game:
    python guessno.py

  NOTE: Date manual nahi daalni — main.py aur standalone
  step2_attendance.py dono automatically aaj ki date (system date)
  use karte hain.

── OUTPUT FILES ────────────────────────────────────────────

  tickets_ddmmyy_hhmmss.xlsx           → Step 1: poora API data
  tickets_summary_ddmmyy_hhmmss.xlsx   → Step 1: Incident ID, Logged Time,
                                          Status, Symptom, Workgroup Name,
                                          Executive Name, FullCategory,
                                          Assigned by Bot
  output.json                           → Step 1: Raw JSON response
  assignment_result_ddmmyy_hhmmss.xlsx → Step 4: Ticket_No, Engineer,
                                          Status_Code, Result,
                                          Assigned by Bot, Time

── RULES ───────────────────────────────────────────────────

  • Employees  → 30% tickets
  • Vendors    → 70% tickets
  • Sirf Present logon ko tickets milte hain (sab solver maane jaate hain)
  • Remaining tickets equally distribute hote hain
  • Har output Excel mein "Assigned by Bot" column hota hai

============================================================

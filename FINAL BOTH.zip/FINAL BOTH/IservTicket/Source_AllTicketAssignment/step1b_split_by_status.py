# ============================================================
#  step1b_split_by_status.py
#  Splits the fetched SR list into 4 SEPARATE Excel files, one per status:
#     sr_new_ddmmyy_hhmmss.xlsx          -> only New / unassigned tickets
#     sr_assigned_ddmmyy_hhmmss.xlsx     -> only Assigned (or any other
#                                            "already assigned, not New/
#                                            Pending/In Progress") tickets
#     sr_inprogress_ddmmyy_hhmmss.xlsx   -> only In Progress tickets
#     sr_pending_ddmmyy_hhmmss.xlsx      -> only Pending tickets
#
#  IMPORTANT: This uses the EXACT SAME classification helpers
#  (_is_pending / _is_in_progress / _is_new_sr) that step3_allocate_sr.py
#  uses to decide what gets (re)assigned. That means a ticket landing in
#  sr_pending_*.xlsx here is guaranteed to be the same ticket step3 will
#  treat as Pending - the two are always in sync, there is no separate
#  classification logic to keep updated in two places.
#
#  Where this runs in the flow (see main_sr.py):
#     STEP 1  : fetch_service_requests()      -> raw sr_list
#     STEP 1b : split_tickets_by_status()      -> THIS FILE (4 Excel files)
#     STEP 2  : check_attendance()             -> who's present today
#     STEP 3  : allocate_sr_actions()          -> split New/Pending/In
#                Progress by Employee/Vendor ratio across PRESENT people;
#                for already-Assigned tickets, keep as-is if the current
#                assignee is present, or reassign to a present person of
#                the same role if the assignee is absent.
# ============================================================

import os
from datetime import datetime
import pandas as pd

from step3_allocate_sr import (
    _sr_no,
    _state_assignee,
    _load_assignment_state,
    _is_pending,
    _is_in_progress,
    _is_new_sr,
)

# Fallback columns used only if a bucket is empty (so the file still opens
# with sensible headers instead of being a totally blank sheet).
_FALLBACK_COLUMNS = ["SR ID", "Logged Time", "Status", "Workgroup Name", "Executive Name"]

_LABEL_TO_FILEPART = {
    "New": "new",
    "Assigned": "assigned",
    "In Progress": "inprogress",
    "Pending": "pending",
}


def split_tickets_by_status(sr_list, out_dir=""):
    """
    Splits sr_list (raw ticket dicts from step1_fetch_sr.py) into 4 buckets
    by status - New / Assigned / In Progress / Pending - and saves each
    bucket as its own Excel file.

    "Assigned" here means: every ticket that is NOT New, NOT Pending and
    NOT In Progress (so it also catches Resolved/Closed etc. if any slip
    through the fetch filter) - same catch-all bucket step3 calls
    `assigned_bucket`.

    Args:
        sr_list : list of ticket dicts (as returned by fetch_service_requests)
        out_dir : folder to save the 4 Excel files into (defaults to cwd)

    Returns:
        dict of {label: filepath}, e.g.
        {"New": "...sr_new_....xlsx", "Assigned": "...", "In Progress": "...", "Pending": "..."}
    """
    print("\n" + "=" * 55)
    print("  STEP 1b : Splitting tickets into status-wise Excel files")
    print("=" * 55)

    state = _load_assignment_state(out_dir=out_dir)

    buckets = {"New": [], "Pending": [], "In Progress": [], "Assigned": []}

    for sr in sr_list or []:
        sno = _sr_no(sr)
        cached = _state_assignee(sno, state) if sno else ""

        if _is_pending(sr):
            buckets["Pending"].append(sr)
        elif _is_in_progress(sr):
            buckets["In Progress"].append(sr)
        elif _is_new_sr(sr, cached):
            buckets["New"].append(sr)
        else:
            buckets["Assigned"].append(sr)

    ts = datetime.now().strftime("%d%m%y_%H%M%S")
    filenames = {}

    for label, rows_list in buckets.items():
        filepart = _LABEL_TO_FILEPART[label]
        fname = f"sr_{filepart}_{ts}.xlsx"
        fpath = os.path.join(out_dir, fname) if out_dir else fname

        df = pd.DataFrame(rows_list) if rows_list else pd.DataFrame(columns=_FALLBACK_COLUMNS)
        df.to_excel(fpath, index=False)

        filenames[label] = fpath
        print(f"  [OK] {label:<12} : {len(rows_list):<4} ticket(s) -> {fpath}")

    total = sum(len(v) for v in buckets.values())
    if total != len(sr_list or []):
        print(f"  [WARNING] Bucketed {total} of {len(sr_list or [])} fetched tickets "
              f"- check for ticket dicts missing an SR number.")

    return filenames


if __name__ == "__main__":
    sample_sr_list = [
        {"SR ID": "SR001", "Status": "Assigned", "Executive Name": "rahul@maruti.co.in"},
        {"SR ID": "SR002", "Status": "New", "Executive Name": ""},
        {"SR ID": "SR003", "Status": "Pending", "Executive Name": "amit@maruti.co.in"},
        {"SR ID": "SR004", "Status": "In Progress", "Executive Name": "neha@maruti.co.in"},
        {"SR ID": "SR005", "Status": "Resolved", "Executive Name": "rahul@maruti.co.in"},
    ]
    split_tickets_by_status(sample_sr_list)

# ============================================================
#  logger.py
#  Standalone logging helper - saves everything printed to the
#  console (all print() output) into a .txt log file, in ADDITION
#  to still showing it in the console/CMD window as normal.
#
#  Log file name format : DDMMYYYY_HHMMSS.txt
#  Log file location    : same folder as the running .exe
#                          (or same folder as this script, if run
#                          as plain .py instead of a built .exe)
#
#  USAGE (from your main script, at the very top, before anything
#  else prints):
#
#      from logger import start_logging
#      start_logging()
#
#  That's it - every print() from that point on (in this file and
#  any other file/module) is automatically saved to the log too.
# ============================================================

import sys
import os
from datetime import datetime


class _Tee:
    """Writes everything to BOTH the real console and a log file."""

    def __init__(self, real_stream, log_file):
        self._real_stream = real_stream
        self._log_file = log_file

    def write(self, text):
        self._real_stream.write(text)
        try:
            self._log_file.write(text)
        except Exception:
            # Never let a logging failure crash the actual program.
            pass

    def flush(self):
        self._real_stream.flush()
        try:
            self._log_file.flush()
        except Exception:
            pass

    def isatty(self):
        # input() checks this on some platforms; delegate to the real stream
        # so interactive y/n prompts keep working normally in the EXE.
        return self._real_stream.isatty()


def _app_folder():
    """
    Returns the folder the .exe (or .py script) is running from.

    - When bundled as a PyInstaller .exe, sys.executable points at the
      .exe itself, so the log is saved right next to it.
    - When run as a plain .py file, falls back to this script's folder.
    """
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


_log_file_handle = None
_log_file_path = None
_original_stdout = None
_original_stderr = None


def start_logging(out_dir=None):
    """
    Call this ONCE, at the very start of your main script (before any
    print statements you want captured).

    Args:
        out_dir : folder where the log file should be saved.
                  If None, saves next to the .exe / .py script.

    Returns the full path to the log file that was created.
    """
    global _log_file_handle, _log_file_path, _original_stdout, _original_stderr

    if _log_file_handle is not None:
        return _log_file_path

    timestamp = datetime.now().strftime("%d%m%Y_%H%M%S")
    filename = f"{timestamp}.txt"
    folder = out_dir if out_dir else _app_folder()
    os.makedirs(folder, exist_ok=True)
    _log_file_path = os.path.join(folder, filename)

    try:
        _log_file_handle = open(_log_file_path, "w", encoding="utf-8")
    except Exception as e:
        # If the log file can't be created (e.g. read-only folder),
        # don't crash the whole program - just skip logging.
        print(f"[WARNING] Could not create log file ({e}). Continuing without logging.")
        return None

    _original_stdout = sys.stdout
    _original_stderr = sys.stderr

    sys.stdout = _Tee(_original_stdout, _log_file_handle)
    sys.stderr = _Tee(_original_stderr, _log_file_handle)

    print(f"Log file started : {_log_file_path}")
    print(f"Run started at    : {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}")
    print("=" * 70)

    return _log_file_path


def stop_logging():
    """
    Optional: call at the very end of your script to cleanly close the
    log file and restore normal console output. Not strictly required -
    the file is flushed after every write - but good practice.
    """
    global _log_file_handle, _original_stdout, _original_stderr

    if _log_file_handle is None:
        return

    print("=" * 70)
    print(f"Run ended at : {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}")

    try:
        _log_file_handle.close()
    except Exception:
        pass

    if _original_stdout is not None:
        sys.stdout = _original_stdout
    if _original_stderr is not None:
        sys.stderr = _original_stderr

    _log_file_handle = None


# ---- Standalone test ----
if __name__ == "__main__":
    path = start_logging()
    print("This line goes to BOTH the console and the log file.")
    print("So does this one.")
    stop_logging()
    print(f"\n(Test complete - check the log file at: {path})")

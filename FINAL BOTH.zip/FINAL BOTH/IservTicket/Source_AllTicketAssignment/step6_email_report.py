# ============================================================
#  step6_email_report.py
#  Emails the final report Excel to the people listed in
#  api_config.xlsx (TO_EMAIL / CC_EMAIL / BCC_EMAIL).
#
#  Uses the company's internal SMTP relay (no login) by default.
#  If SMTP_USERNAME/SMTP_PASSWORD are filled in api_config.xlsx,
#  it will log in before sending.
#
#  This step never crashes the whole program -- if email settings
#  are missing or sending fails, it just prints a warning and the
#  rest of the tool's work (already done) is unaffected.
# ============================================================

import os
import smtplib
from email.message import EmailMessage
from datetime import datetime

from config import EMAIL_SETTINGS


def send_report_email(report_file, extra_note=""):
    """
    Emails report_file (path to the .xlsx report) to TO_EMAIL,
    with CC_EMAIL / BCC_EMAIL as configured in api_config.xlsx.
    Returns True if sent, False if skipped/failed.
    """
    print("\n" + "=" * 70)
    print("  STEP 6 : Emailing Final Report")
    print("=" * 70)

    settings = EMAIL_SETTINGS

    smtp_host = settings.get("SMTP_HOST", "")
    to_list   = settings.get("TO_EMAIL", [])

    if not smtp_host or not to_list:
        print("  [SKIPPED] SMTP_HOST or TO_EMAIL not set in api_config.xlsx.")
        print("            Report was still created, just not emailed.")
        return False

    if not report_file or not os.path.isfile(report_file):
        print(f"  [SKIPPED] Report file not found: {report_file}")
        return False

    from_email = settings.get("FROM_EMAIL") or "no-reply@localhost"
    cc_list    = settings.get("CC_EMAIL", [])
    bcc_list   = settings.get("BCC_EMAIL", [])
    smtp_port  = settings.get("SMTP_PORT", 25)
    username   = settings.get("SMTP_USERNAME", "")
    password   = settings.get("SMTP_PASSWORD", "")

    msg = EmailMessage()
    msg["Subject"] = f"SR Assignment Report - {datetime.now().strftime('%d-%m-%Y %H:%M')}"
    msg["From"] = from_email
    msg["To"] = ", ".join(to_list)
    if cc_list:
        msg["Cc"] = ", ".join(cc_list)

    body = (
        "Hi,\n\n"
        "Please find attached the latest SR assignment report, generated automatically.\n"
    )
    if extra_note:
        body += f"\n{extra_note}\n"
    body += "\nRegards,\nAutomated Ticketing Bot"
    msg.set_content(body)

    with open(report_file, "rb") as f:
        file_data = f.read()
    file_name = os.path.basename(report_file)
    msg.add_attachment(
        file_data,
        maintype="application",
        subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=file_name,
    )

    all_recipients = to_list + cc_list + bcc_list

    try:
        print(f"  Connecting to SMTP server {smtp_host}:{smtp_port} ...")
        with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
            try:
                server.starttls()
            except Exception:
                # Server may not support/require STARTTLS (plain internal relay) - fine.
                pass
            if username and password:
                server.login(username, password)
            server.send_message(msg, from_addr=from_email, to_addrs=all_recipients)

        print(f"  [OK] Report emailed to: {', '.join(to_list)}")
        if cc_list:
            print(f"       Cc : {', '.join(cc_list)}")
        if bcc_list:
            print(f"       Bcc: {', '.join(bcc_list)}")
        return True

    except Exception as e:
        print(f"  [ERROR] Failed to send email: {e}")
        print("          Report file is still saved on disk, just not emailed.")
        return False

# ============================================================
#  step5_report_sr.py
#  Creates final Service Request assignment decision Excel.
#
#  Output columns:
#    SR Number | Status | Last Assigned | Attendance | Current Assigned
#
#  Meaning (same logic as the Incident report):
#    - Last Assigned    : person already assigned before this run (API/state)
#    - Attendance       : attendance of last assigned person.
#                         For NEW SRs with no last assignee, it shows
#                         attendance of the newly/current assigned person.
#    - Current Assigned : final person after applying the logic
#                         (same person if present, new person if absent/new)
# ============================================================

from datetime import datetime
import pandas as pd

from step3_allocate_sr import (
    _sr_no,
    _status,
    _assignee,
    _state_assignee,
    _load_assignment_state,
    _match_person,
)


def _clean(value):
    return "" if value is None else str(value).strip()


def _all_known_emails(rows):
    details = (rows or {}).get("details", {}) or {}
    return list(details.keys())


def _find_email(person, rows):
    """Return email key from attendance rows for an API name/email if possible."""
    person = _clean(person)
    if not person:
        return ""

    details = (rows or {}).get("details", {}) or {}
    emails = list(details.keys())

    matched = _match_person(person, emails)
    if matched:
        return matched

    names = [info.get("name", "") for info in details.values() if info.get("name")]
    matched_name = _match_person(person, names)
    if matched_name:
        for email, info in details.items():
            if _clean(info.get("name")) == _clean(matched_name):
                return email

    return ""


def _display_person(person, rows):
    """Prefer display name from Excel; fall back to given API/email value."""
    person = _clean(person)
    if not person:
        return ""

    email = _find_email(person, rows)
    if email:
        name = ((rows or {}).get("details", {}) or {}).get(email, {}).get("name", "")
        return _clean(name) or email

    return person


def _attendance(person, rows):
    """Get P/A style attendance from Excel for a name/email."""
    person = _clean(person)
    if not person:
        return ""

    email = _find_email(person, rows)
    if not email:
        return ""

    status = ((rows or {}).get("details", {}) or {}).get(email, {}).get("status", "")
    return _clean(status).lower() if status else ""


def _action_maps(actions):
    by_sr = {}
    for a in actions or []:
        sno = _clean(a.get("sr_no"))
        if sno:
            by_sr[sno] = a
    return by_sr


def _result_maps(post_results):
    by_sr = {}
    for r in post_results or []:
        sno = _clean(r.get("SR_No"))
        if sno:
            by_sr[sno] = r
    return by_sr


def create_sr_assignment_report(sr_list, actions, kept, skipped, rows, post_results=None, out_dir=None):
    """
    Creates final report Excel and returns filename.
    This report includes ALL fetched SRs, not only API-posted SRs.
    Args:
        out_dir: folder where the report Excel is saved.
                 If None, saves in the current working directory.
    """
    import os
    out_dir = out_dir or ""

    print("\n" + "=" * 70)
    print("  STEP 5 : Creating Final Service Request Assignment Report Excel")
    print("=" * 70)

    state = _load_assignment_state(out_dir=out_dir)
    actions_by_sr = _action_maps(actions)
    results_by_sr = _result_maps(post_results)

    report_rows = []

    for sr in sr_list or []:
        sr_no = _sr_no(sr)
        status = _status(sr)
        api_last = _assignee(sr)
        cached_last = _state_assignee(sr_no, state) if sr_no else ""

        last_assigned_raw = api_last or cached_last

        action = actions_by_sr.get(str(sr_no), {})
        planned_current_raw = action.get("email", "")

        if planned_current_raw:
            current_assigned_raw = planned_current_raw
        else:
            current_assigned_raw = last_assigned_raw

        attendance_source = last_assigned_raw or current_assigned_raw

        report_rows.append({
            "SR Number": sr_no,
            "Status": status,
            "Last Assigned": _display_person(last_assigned_raw, rows),
            "Attendance": _attendance(attendance_source, rows),
            "Current Assigned": _display_person(current_assigned_raw, rows),
        })

    ts = datetime.now().strftime("%d%m%y_%H%M%S")
    report_file = os.path.join(out_dir, f"sr_assignment_report_{ts}.xlsx") if out_dir else f"sr_assignment_report_{ts}.xlsx"

    df = pd.DataFrame(report_rows, columns=[
        "SR Number",
        "Status",
        "Last Assigned",
        "Attendance",
        "Current Assigned",
    ])

    with pd.ExcelWriter(report_file, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="SR Report")
        ws = writer.book["SR Report"]

        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

        header_fill = PatternFill("solid", fgColor="D9EAF7")
        header_font = Font(bold=True, color="000000")
        border = Border(
            left=Side(style="thin", color="BFBFBF"),
            right=Side(style="thin", color="BFBFBF"),
            top=Side(style="thin", color="BFBFBF"),
            bottom=Side(style="thin", color="BFBFBF"),
        )

        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = border

        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.border = border

        widths = {
            "A": 18,
            "B": 18,
            "C": 24,
            "D": 15,
            "E": 24,
        }
        for col, width in widths.items():
            ws.column_dimensions[col].width = width

        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions

    print(f"  [OK] Final report saved -> {report_file}")
    return report_file

# ============================================================
#  step3_allocate_sr_v2.py
#  SR allocation logic -- ALL active statuses assigned via split
#  + load balancing after each run.
#
#  RULES:
#
#    1. New, Assigned, Pending, In Progress SRs ALL go through
#       the Employee/Vendor split using the ratio from the
#       attendance Excel. Current assignee is ignored.
#
#    2. Each status group is split independently:
#         New         -> 30% Emp / 70% Ven  (or whatever ratio says)
#         Assigned    -> 30% Emp / 70% Ven
#         Pending     -> 30% Emp / 70% Ven
#         In Progress -> 30% Emp / 70% Ven
#
#    3. Within each role (Emp / Ven), the fair-share picker gives
#       the ticket to whoever currently has the FEWEST total
#       assignments -- so load stays balanced ticket-by-ticket.
#
#    4. LOAD BALANCING after all tickets are assigned this run:
#       If anyone's total (past runs + this run) is higher than
#       the fair share (ceil of total / present count), excess
#       tickets are redistributed to the person with the fewest.
#       This corrects any long-term imbalance.
#
#    5. Resolved and Closed SRs are never touched.
#
#    6. IDEMPOTENCY: once a SR has been assigned by the bot
#       (tracked in assignment_state_sr.json), it is left
#       untouched in future runs unless it shows up again in
#       a different status (Assigned/Pending/In Progress).
# ============================================================

from config import DEFAULT_EMP_SPLIT
import json
import math
import os

ASSIGNMENT_STATE_FILE   = "assignment_state_sr.json"
DISTRIBUTION_STATE_FILE = "distribution_state_sr.json"

SR_ID_KEYS    = ["SR ID", "SR_No", "SR No", "ServiceRequestID", "Service Request ID", "SRNo", "ID"]
ASSIGNEE_KEYS = ["Executive Email", "Assigned_Engineer_Email", "Executive Name", "Assigned Engineer", "Assignee", "Owner"]
STATUS_KEYS   = ["Status", "SR Status", "Ticket Status"]


# ── helpers ──────────────────────────────────────────────────────────────────

def _clean(value):
    return "" if value is None else str(value).strip()

def _norm(value):
    return _clean(value).lower().replace(" ", "")

def _get(sr, keys):
    for key in keys:
        if key in sr and _clean(sr.get(key)):
            return _clean(sr.get(key))
    return ""

def _sr_no(sr):   return _get(sr, SR_ID_KEYS)
def _assignee(sr): return _get(sr, ASSIGNEE_KEYS)
def _status(sr):   return _get(sr, STATUS_KEYS)

def _status_norm(sr):
    return _norm(_status(sr)).replace("-", "")

def _is_new(sr):
    s = _status_norm(sr)
    return s == "new" or s.startswith("new")

def _is_assigned(sr):
    return _status_norm(sr) == "assigned"

def _is_pending(sr):
    s = _status_norm(sr)
    return s == "pending" or s.startswith("pending")

def _is_in_progress(sr):
    return _status_norm(sr) in {"inprogress", "inprogess"}

def _is_active(sr):
    """Any status we assign: New / Assigned / Pending / In Progress."""
    return _is_new(sr) or _is_assigned(sr) or _is_pending(sr) or _is_in_progress(sr)


# ── state helpers ─────────────────────────────────────────────────────────────

def _path(filename, out_dir=""):
    return os.path.join(out_dir, filename) if out_dir else filename

def _load_json(path):
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _save_json(data, path):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"  [WARNING] Could not save {path}: {e}")

def _load_assignment_state(out_dir=""):
    return _load_json(_path(ASSIGNMENT_STATE_FILE, out_dir))

def _load_distribution_state(out_dir=""):
    return _load_json(_path(DISTRIBUTION_STATE_FILE, out_dir))

def _save_distribution_state(counts, out_dir=""):
    _save_json(counts, _path(DISTRIBUTION_STATE_FILE, out_dir))

def _state_assignee(sr_no, state):
    item = (state or {}).get(str(sr_no), {})
    return _clean(item.get("email") if isinstance(item, dict) else item)


# ── person pool ───────────────────────────────────────────────────────────────

def _person_pool(present):
    return {
        "Emp": [p["name"] for p in present.get("Emp", []) if p.get("solver") == "Y"],
        "Ven": [p["name"] for p in present.get("Ven", []) if p.get("solver") == "Y"],
    }


# ── fair-share picker ─────────────────────────────────────────────────────────

def _make_fair_picker(all_candidates, saved_counts=None):
    """
    Picks from a pool giving priority to whoever has the fewest
    total assignments (past runs + this run combined).
    Ties break by original attendance-list order.
    """
    counts = {}
    for person in all_candidates:
        key = _norm(person)
        counts[key] = int((saved_counts or {}).get(key, 0))

    def pick(pool):
        available = [c for c in pool if c]
        if not available:
            return ""
        chosen = min(available, key=lambda c: counts.get(_norm(c), 0))
        counts[_norm(chosen)] = counts.get(_norm(chosen), 0) + 1
        return chosen

    return pick, counts


# ── load balancer ─────────────────────────────────────────────────────────────

def _rebalance(actions, pools, counts):
    """
    After all tickets are allocated, check if any present person
    has more than their fair share. If yes, move excess tickets to
    the person with the fewest -- within the same role (Emp stays
    Emp, Ven stays Ven).

    Fair share per role = ceil(role_total / role_people_count)

    Returns the (possibly modified) actions list and a list of
    rebalance moves made (for terminal display).
    """
    moves = []

    for role, pool in pools.items():
        if len(pool) <= 1:
            continue   # only 1 person in role -- nothing to balance

        # Count tickets assigned to each person in this role THIS run
        run_counts = {_norm(p): 0 for p in pool}
        for a in actions:
            key = _norm(a["email"])
            if key in run_counts:
                run_counts[key] += 1

        # Total tickets for this role this run
        role_total = sum(run_counts.values())
        if role_total == 0:
            continue

        fair_share = math.ceil(role_total / len(pool))

        # Find who has too many and who has too few
        over  = [(p, run_counts[_norm(p)]) for p in pool if run_counts[_norm(p)] > fair_share]
        under = [(p, run_counts[_norm(p)]) for p in pool if run_counts[_norm(p)] < fair_share]

        if not over or not under:
            continue   # already balanced

        print(f"\n  -- LOAD BALANCING ({role}) ----------------------------")
        print(f"  Fair share per person : {fair_share} tickets")
        print(f"  Before: { {p: run_counts[_norm(p)] for p in pool} }")

        for over_person, over_count in over:
            excess = over_count - fair_share
            for _ in range(excess):
                if not under:
                    break
                # Pick the person with the fewest tickets
                under.sort(key=lambda x: x[1])
                to_person, to_count = under[0]

                # Find a ticket assigned to over_person and reassign it
                for a in actions:
                    if _norm(a["email"]) == _norm(over_person):
                        old_email = a["email"]
                        a["email"]  = to_person
                        a["reason"] += f" [rebalanced from {old_email}]"

                        # Update run counts
                        run_counts[_norm(over_person)] -= 1
                        run_counts[_norm(to_person)]   += 1

                        # Update counts dict for distribution state
                        counts[_norm(over_person)]  = max(0, counts.get(_norm(over_person), 0) - 1)
                        counts[_norm(to_person)]     = counts.get(_norm(to_person), 0) + 1

                        moves.append(f"  {old_email} -> {to_person}  (SR {a['sr_no']})")

                        # Refresh under list
                        under = [(p, run_counts[_norm(p)]) for p in pool
                                 if run_counts[_norm(p)] < fair_share]
                        break

        print(f"  After : { {p: run_counts[_norm(p)] for p in pool} }")

    return actions, moves


# ── main function ─────────────────────────────────────────────────────────────

def allocate_sr_actions(sr_list, present, rows, out_dir=""):
    """
    Assigns ALL active SRs (New / Assigned / Pending / In Progress)
    via the Employee/Vendor split, then rebalances so no one has
    significantly more tickets than others.

    Returns:
        actions  : list of {sr_no, email, reason, status} -- to be posted
        kept     : [] (not used in this version)
        skipped  : list of {sr_no, reason}
    """

    print("\n" + "=" * 70)
    print("  STEP 3 : SR Allocation -- All Active Statuses + Load Balancing")
    print("=" * 70)

    state        = _load_assignment_state(out_dir=out_dir)
    pools        = _person_pool(present)
    saved_counts = _load_distribution_state(out_dir=out_dir)
    _pick, _counts = _make_fair_picker(pools["Emp"] + pools["Ven"],
                                       saved_counts=saved_counts)

    def pick_emp(): return _pick(pools["Emp"])
    def pick_ven(): return _pick(pools["Ven"])
    def pick_any(): return _pick(pools["Emp"] + pools["Ven"])

    ratio     = (rows or {}).get("ratio", {})
    emp_split = ratio.get("Emp", DEFAULT_EMP_SPLIT)
    ven_split = ratio.get("Ven", 1 - emp_split)

    # ── Debug: confirm field names match the API response ─────────────────
    if sr_list:
        sample = sr_list[0]
        matched_status   = next((k for k in STATUS_KEYS   if k in sample), None)
        matched_assignee = next((k for k in ASSIGNEE_KEYS if k in sample), None)
        print(f"\n  [DEBUG] Status field matched   : {matched_status!r}")
        print(f"  [DEBUG] Assignee field matched : {matched_assignee!r}")
        if not matched_status or not matched_assignee:
            print(f"  [DEBUG] Available keys on first SR: {list(sample.keys())}")
        raw_statuses = sorted({_status(sr) or "(blank)" for sr in sr_list})
        print(f"  [DEBUG] Status values seen     : {raw_statuses}")

    # ── Sort SRs into status buckets ──────────────────────────────────────
    buckets = {"New": [], "Assigned": [], "Pending": [], "In Progress": [], "Skip": []}

    for sr in sr_list:
        sno = _sr_no(sr)
        if _is_new(sr):
            # Idempotency: if already assigned by bot in a previous run, skip
            if sno and str(sno) in state:
                buckets["Skip"].append(sr)
            else:
                buckets["New"].append(sr)
        elif _is_assigned(sr):
            buckets["Assigned"].append(sr)
        elif _is_pending(sr):
            buckets["Pending"].append(sr)
        elif _is_in_progress(sr):
            buckets["In Progress"].append(sr)
        else:
            buckets["Skip"].append(sr)   # Resolved, Closed, etc.

    # ── Print counts ──────────────────────────────────────────────────────
    print(f"\n  Ratio from Excel : Emp {round(emp_split*100)}% | Ven {round(ven_split*100)}%")
    print(f"  Previous bot assignments in state: {len(state)}")
    print(f"\n  {'Status':<14} {'Count':<6} Split target (Emp / Ven)")
    print(f"  {'-'*55}")
    for label in ["New", "Assigned", "Pending", "In Progress"]:
        n = len(buckets[label])
        emp_t = round(n * emp_split)
        print(f"  {label:<14} {n:<6} Emp {emp_t} / Ven {n - emp_t}")
    print(f"  {'Skipped':<14} {len(buckets['Skip']):<6} (Resolved/Closed or already handled)")
    total_active = sum(len(buckets[s]) for s in ["New", "Assigned", "Pending", "In Progress"])
    print(f"  {'-'*55}")
    print(f"  {'TOTAL ACTIVE':<14} {total_active}")

    # ── Assign each bucket via split ──────────────────────────────────────
    actions  = []
    skipped  = []

    for status_label in ["New", "Assigned", "Pending", "In Progress"]:
        bucket = buckets[status_label]
        if not bucket:
            continue

        target_emp = round(len(bucket) * emp_split)
        emp_done   = 0

        for sr in bucket:
            sr_no = _sr_no(sr)
            if not sr_no:
                skipped.append({"sr_no": "", "reason": f"{status_label}: SR number missing"})
                continue

            if emp_done < target_emp:
                email = pick_emp() or pick_any()
                emp_done += 1
                role = "Emp"
            else:
                email = pick_ven() or pick_any()
                role = "Ven"

            if email:
                actions.append({
                    "sr_no":  sr_no,
                    "email":  email,
                    "reason": f"{status_label} -> split ({role})",
                    "status": status_label,
                })
            else:
                skipped.append({"sr_no": sr_no,
                                "reason": f"{status_label}: no present solver available"})

    # ── Load balancing ────────────────────────────────────────────────────
    print(f"\n  -- PRE-BALANCE ALLOCATION ---------------------------------")
    for a in actions:
        print(f"  {a['sr_no']:<15} -> {a['email']:<45} {a['reason']}")

    actions, moves = _rebalance(actions, pools, _counts)

    if moves:
        print(f"\n  -- REBALANCE MOVES ------------------------------------")
        for m in moves:
            print(m)

    # ── Final summary ─────────────────────────────────────────────────────
    print(f"\n  -- FINAL ALLOCATION ---------------------------------------")
    if actions:
        for a in actions:
            print(f"  {a['sr_no']:<15} -> {a['email']:<45} {a['reason']}")
    else:
        print("  None")

    if skipped:
        print(f"\n  -- SKIPPED ------------------------------------------------")
        for s in skipped:
            print(f"  {s['sr_no'] or 'UNKNOWN':<15} {s['reason']}")

    # ── Per-person totals ─────────────────────────────────────────────────
    print(f"\n  -- ASSIGNMENT TOTALS (this run + all previous runs) -------")
    for person in pools["Emp"] + pools["Ven"]:
        key = _norm(person)
        print(f"  {person:<45} total: {_counts.get(key, 0)}")

    _save_distribution_state(_counts, out_dir=out_dir)

    return actions, [], skipped


# ── standalone test ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    sample_present = {
        "Emp": [{"name": "rahul@maruti.co.in",   "solver": "Y"},
                {"name": "akshita@maruti.co.in",  "solver": "Y"}],
        "Ven": [{"name": "neha@vendor.co.in",    "solver": "Y"},
                {"name": "priya@vendor.co.in",   "solver": "Y"},
                {"name": "rohit@vendor.co.in",   "solver": "Y"}],
    }
    sample_rows = {
        "ratio": {"Emp": 0.30, "Ven": 0.70},
    }
    sample_srs = [
        {"SR ID": "SR001", "Status": "New",         "Executive Name": ""},
        {"SR ID": "SR002", "Status": "New",         "Executive Name": ""},
        {"SR ID": "SR003", "Status": "New",         "Executive Name": ""},
        {"SR ID": "SR004", "Status": "Assigned",    "Executive Name": "rahul@maruti.co.in"},
        {"SR ID": "SR005", "Status": "Assigned",    "Executive Name": "rahul@maruti.co.in"},
        {"SR ID": "SR006", "Status": "Pending",     "Executive Name": "neha@vendor.co.in"},
        {"SR ID": "SR007", "Status": "Pending",     "Executive Name": "neha@vendor.co.in"},
        {"SR ID": "SR008", "Status": "In Progress", "Executive Name": "priya@vendor.co.in"},
        {"SR ID": "SR009", "Status": "In Progress", "Executive Name": "priya@vendor.co.in"},
        {"SR ID": "SR010", "Status": "Resolved",    "Executive Name": "rohit@vendor.co.in"},
    ]

    actions, kept, skipped = allocate_sr_actions(sample_srs, sample_present, sample_rows)
    print()
    print("FINAL actions count:", len(actions))

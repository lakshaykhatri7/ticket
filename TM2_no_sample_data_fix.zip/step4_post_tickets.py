# ============================================================
#  step4_post_tickets.py
#  Assigns allocated tickets to each person's email via the API
#  ("Assigned_Engineer_Email" is filled from the actual email
#   coming from ATTENDANCE.xlsx -- config's fixed ASSIGNED_EMAIL
#   is no longer used)
#  Each assignment's result is shown in Excel + terminal
#  Output: assignment_result_ddmmyy_hhmmss.xlsx
# ============================================================

import requests
import pandas as pd
from datetime import datetime
import json
import os
from config import API_URL, API_KEY, ORG_ID, INSTANCE, WORKGROUP

ASSIGNMENT_STATE_FILE = "assignment_state.json"


def _load_assignment_state():
    if not os.path.exists(ASSIGNMENT_STATE_FILE):
        return {}
    try:
        with open(ASSIGNMENT_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_successful_assignment(ticket_no, email, reason=""):
    state = _load_assignment_state()
    state[str(ticket_no)] = {
        "email": str(email).strip(),
        "workgroup": WORKGROUP,
        "reason": reason,
        "updated_at": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
    }
    with open(ASSIGNMENT_STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=4)


def post_ticket_actions(actions):
    """
    Posts only selected ticket actions returned from step3_allocate.allocate_ticket_actions.

    Args:
        actions: list of {ticket_no, email, reason}
    """

    print("\n" + "="*70)
    print("  STEP 4 : Posting Required Ticket Updates via API")
    print("="*70)

    if not actions:
        print("  No ticket needs API update. Already-assigned present users remain unchanged.")
        return []

    print(f"\n  Total tickets to post : {len(actions)}")
    print(f"  {'Ticket No':<15} {'Email':<45} Reason")
    print(f"  {'-'*90}")
    for item in actions:
        print(f"  {item['ticket_no']:<15} {item['email']:<45} {item.get('reason', '')}")

    results = []

    for item in actions:
        ticket_no = item["ticket_no"]
        email = item["email"]
        reason = item.get("reason", "Auto assignment")

        print(f"\n  Posting Ticket {ticket_no} -> {email} ...")

        payload = {
            "ServiceName": "IM_LogOrUpdateIncident",
            "objCommonParameters": {
                "_ProxyDetails": {
                    "AuthType": "APIKEY",
                    "APIKey": API_KEY,
                    "ProxyID": 0,
                    "ReturnType": "JSON",
                    "OrgID": ORG_ID
                },
                "incidentParamsJSON": {
                    "IncidentContainerJsonObj": {
                        "Updater": "Executive",
                        "Ticket": {
                            "IsFromWebService": True,
                            "Ticket_No": ticket_no,
                            "Sup_Function": INSTANCE,
                            "Status": "Assigned",
                            "Assigned_WorkGroup_Name": WORKGROUP,
                            "Medium": "API",
                            "Source": "API Call",
                            "Assigned_Engineer_Email": email,
                            "PageName": "LogTicket"
                        },
                        "TicketInformation": {
                            "Information": f"{reason}: auto-assigned to {email} via Python"
                        },
                        "CustomFields": []
                    }
                },
                "RequestType": "RemoteCall"
            }
        }

        try:
            resp = requests.post(API_URL, json=payload, timeout=30)
            if resp.status_code == 200:
                print(f"  [OK] Success -- Ticket {ticket_no} assigned to {email}.")
                _save_successful_assignment(ticket_no, email, reason)
                print(f"  [OK] Saved local state so this ticket is not posted again on next run.")
                result_status = "Success"
            else:
                print(f"  [FAILED] ({resp.status_code}) -- Ticket {ticket_no}")
                result_status = f"Failed_{resp.status_code}"

            results.append({
                "Ticket_No": ticket_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": resp.status_code,
                "Result": result_status,
                "Assigned by Bot": "Yes",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })

        except requests.exceptions.ConnectionError:
            print(f"  [ERROR] Connection error -- Ticket {ticket_no}")
            results.append({
                "Ticket_No": ticket_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": "N/A",
                "Result": "Connection Error",
                "Assigned by Bot": "Yes",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })
        except Exception as e:
            print(f"  [ERROR] {e}")
            results.append({
                "Ticket_No": ticket_no,
                "Email": email,
                "Reason": reason,
                "Status_Code": "N/A",
                "Result": f"Error: {str(e)}",
                "Assigned by Bot": "Yes",
                "Time": datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            })

    if results:
        ts = datetime.now().strftime("%d%m%y_%H%M%S")
        result_file = f"assignment_result_{ts}.xlsx"
        pd.DataFrame(results).to_excel(result_file, index=False)
        print(f"\n  [OK] Assignment result saved -> {result_file}")

        success = sum(1 for r in results if r["Result"] == "Success")
        failed = len(results) - success
        print(f"\n  -- POST SUMMARY --------------------------------")
        print(f"  Total Posted : {len(results)}")
        print(f"  Success      : {success}")
        print(f"  Failed       : {failed}")

    return results


def post_tickets(allocation, ticket_numbers):
    """
    Assigns each present solver (now identified by email) their
    allocated tickets via the API.

    Args:
        allocation     (dict): { email : ticket_count }
        ticket_numbers (list): ticket numbers from step1
    """

    print("\n" + "="*70)
    print("  STEP 4 : Posting Tickets via API (by email)")
    print("="*70)

    if not allocation:
        print("  [WARNING] Allocation is empty. Nothing to post.")
        return

    if not ticket_numbers:
        print("  [WARNING] No ticket numbers found. Check Step 1.")
        return

    # ---- Distribute tickets across emails (round-robin style) ----
    ticket_pool  = list(ticket_numbers)
    assign_map   = {}   # { email : [ticket_no, ...] }
    idx = 0

    for email, count in allocation.items():
        chunk = ticket_pool[idx : idx + count]
        assign_map[email] = chunk
        idx += count

        if idx >= len(ticket_pool):
            print(f"  [WARNING] Ticket pool exhausted. Remaining will be skipped.")
            break

    print(f"\n  Assignment Plan:")
    print(f"  {'Email':<38} Tickets")
    print(f"  {'-'*60}")
    for email, tlist in assign_map.items():
        print(f"  {email:<38} {tlist}")

    # ---- API Calls ----
    results = []

    for email, tickets in assign_map.items():
        for ticket_no in tickets:

            print(f"\n  Posting Ticket {ticket_no} -> {email} ...")

            payload = {
                "ServiceName": "IM_LogOrUpdateIncident",
                "objCommonParameters": {
                    "_ProxyDetails": {
                        "AuthType": "APIKEY",
                        "APIKey": API_KEY,
                        "ProxyID": 0,
                        "ReturnType": "JSON",
                        "OrgID": ORG_ID
                    },
                    "incidentParamsJSON": {
                        "IncidentContainerJsonObj": {
                            "Updater": "Executive",
                            "Ticket": {
                                "IsFromWebService": True,
                                "Ticket_No": ticket_no,
                                "Sup_Function": INSTANCE,
                                "Status": "Assigned",
                                "Assigned_WorkGroup_Name": WORKGROUP,
                                "Medium": "API",
                                "Source": "API Call",
                                "Assigned_Engineer_Email": email,
                                "PageName": "LogTicket"
                            },
                            "TicketInformation": {
                                "Information": f"Auto-assigned to {email} via Python"
                            },
                            "CustomFields": []
                        }
                    },
                    "RequestType": "RemoteCall"
                }
            }

            try:
                resp = requests.post(API_URL, json=payload, timeout=30)

                if resp.status_code == 200:
                    print(f"  [OK] Success -- Ticket {ticket_no} assigned to {email}.")
                    _save_successful_assignment(ticket_no, email, reason)
                    print(f"  [OK] Saved local state so this ticket is not posted again on next run.")
                    result_status = "Success"
                else:
                    print(f"  [FAILED] ({resp.status_code}) -- Ticket {ticket_no}")
                    result_status = f"Failed_{resp.status_code}"

                results.append({
                    "Ticket_No"        : ticket_no,
                    "Email"            : email,
                    "Status_Code"      : resp.status_code,
                    "Result"           : result_status,
                    "Assigned by Bot"  : "Yes",
                    "Time"             : datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })

            except requests.exceptions.ConnectionError:
                print(f"  [ERROR] Connection error -- Ticket {ticket_no}")
                results.append({
                    "Ticket_No"        : ticket_no,
                    "Email"            : email,
                    "Status_Code"      : "N/A",
                    "Result"           : "Connection Error",
                    "Assigned by Bot"  : "Yes",
                    "Time"             : datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })

            except Exception as e:
                print(f"  [ERROR] {e}")
                results.append({
                    "Ticket_No"        : ticket_no,
                    "Email"            : email,
                    "Status_Code"      : "N/A",
                    "Result"           : f"Error: {str(e)}",
                    "Assigned by Bot"  : "Yes",
                    "Time"             : datetime.now().strftime("%d-%m-%Y %H:%M:%S")
                })

    # ---- Terminal: show the full result table (without opening Excel) ----
    if results:
        print(f"\n  -- FULL RESULT TABLE (terminal) ------------------------------------")
        print(f"  {'Ticket No':<12} {'Email':<38} {'Result'}")
        print(f"  {'-'*75}")
        for r in results:
            print(f"  {str(r['Ticket_No']):<12} {r['Email']:<38} {r['Result']}")

        # ---- Save result Excel ----
        ts          = datetime.now().strftime("%d%m%y_%H%M%S")
        result_file = f"assignment_result_{ts}.xlsx"
        pd.DataFrame(results).to_excel(result_file, index=False)
        print(f"\n  [OK] Assignment result saved -> {result_file}")

        # ---- Summary print ----
        success = sum(1 for r in results if r["Result"] == "Success")
        failed  = len(results) - success
        print(f"\n  -- POST SUMMARY --------------------------------")
        print(f"  Total Posted : {len(results)}")
        print(f"  Success      : {success}")
        print(f"  Failed       : {failed}")

